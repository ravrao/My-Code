<?php /* Template Name: FrontPage Template */
get_header(); ?> 
    
    <!-- BANNER SLIDER START -->  
            
        <section class="banner-slider">
            <div class="owl-carousel owl-theme owlOne"> 
                
            <?php
                query_posts( array(
                'post_type' => 'banner', 
                )); 
               
                if( have_posts() ): while ( have_posts() ) : the_post(); 
                $feat_image = wp_get_attachment_url( get_post_thumbnail_id($post->ID) );

            ?>     
                
                <div class="item">
                    <img src="<?php echo $feat_image;?>" />
                    <div class="caption">
                        <div class="container">
                            <h1><?php the_title();?></h1>
                        <?php the_content();?>
                        <a href="<?php echo get_post_meta($post->ID, 'banner_url', true); ?>" class="btn">Become an annual member</a>
                        </div>
                    </div>                         
                </div>
                
             <?php
               
               endwhile;
               endif; ?>    
                
              </div>
        </section> 
    <div class="clearfix"></div>     
    <!-- BANNER SLIDER END -->  
    
    <!-- ABOUT SECTION START -->
    
    <?php $the_query = new WP_Query( 'page_id=13' ); ?>
    <?php while ($the_query -> have_posts()) : $the_query -> the_post();  
    $content = get_the_content();
    $about_feat_image = wp_get_attachment_url( get_post_thumbnail_id($post->ID) ); 
    ?>
    <div class="container">
        <div class="row about-section">
            <div class="col-sm-6 col-xs-12">
                <img src="<?php echo $about_feat_image;?>" class="img-responsive" />
            </div>
            <div class="col-sm-6 col-xs-12">
                <div class="about-box">
                    <h2><?php echo get_post_meta($post->ID, 'ikmf_title', true); ?></h2>
                    <?php the_field('ikmf_content'); ?>
                    <h2><?php echo get_post_meta($post->ID, 'about_krav_maga_title', true); ?></h2>
                    <?php the_content();?>
                </div>
            </div>
        </div>
    </div>
    <?php endwhile;?> 
    <!-- ABOUT SECTION END -->  
    
    <!-- OUR COURSES SECTION START -->
    <section class="courses-section">
        <div class="container">
            <div class="row">
                <div class="col-sm-12 col-xs-12">
                    <div class="title"><span><?php echo get_post_meta(10, 'our_courses_title', true); ?></span></div>
                </div>
                <div class="col-sm-12 col-xs-12">
                    <div class="course-slider">
                        <div class="owl-carousel owl-theme owlTwo"> 
                            
                           
                    <?php
                   
                    $course=get_categories(array('taxonomy' => 'courses','hide_empty'=>0));
                   foreach($course as $value)
                   {
                   ?> 

                            
                            <div class="item">
                                <div class="img-box">
                                  
                                    <img src="<?php echo z_taxonomy_image_url($value->term_id); ?>" alt="" class="img-responsive">
                                </div>
                                <div class="info">
                                    <div class="heading"><?php echo $value->name;?></div>
                                    <?php echo $value->description;?>
                                </div>                         
                            </div>
                           
                   <?php }?> 
                            </div>
                        <a class="btn" href="<?php echo get_page_link(17); ?>#common">View All</a>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- OUR COURSES SECTION END -->
    
    <!-- FIND CITY SECTION START -->
  <section class="find-section">
        <div class="map-cont">
             <div id="map"></div>
            <!-- <iframe src="https://j.map.baidu.com/9F7iP" width="600" height="450" frameborder="0" style="border:0" allowfullscreen></iframe> -->

<script src="http://api.map.baidu.com/api?v=2.0&ak=DBa5badfc49c1ce0148b174ae3bdf0ea&callback=initMap"></script>

   
        </div>
        <div class="map-right">
            <h2>Find a gym in your city</h2>
            <div class="serach-location">
                <div class="serchFrm">
                    <div class="searInp">
                        <input type="text" name="" placeholder="Search location..." class="searhLocation">
                        <input type="submit">
                    </div>
                    <ul class="autoPopulate">
                        
                       <?php
                        query_posts( array(
                        'post_type' => 'gymlocation',
                        'posts_per_page'  => '5'  
                        )); 

                        if( have_posts() ): while ( have_posts() ) : the_post(); 
                        $feat_image = wp_get_attachment_url( get_post_thumbnail_id($post->ID) );

                    ?>     
    <li style="cursor:pointer" data-field="<?php echo get_post_meta($post->ID, 'gim-location', true); ?>"> 
                           
                                <img src="<?php echo $feat_image;?>" alt="">
                                <h3><?php the_title();?></h3>
                                <?php //the_content();?>
                                <?php echo get_post_meta($post->ID, 'gim-location', true); ?>
                            
                        </li>
                        
                    <?php endwhile;            endif;?>    
                    </ul>
                </div>
            </div>
        </div>
    </section>
    <!-- FIND CITY SECTION END -->
    
    <!-- EVENTS SECTION START -->
    <section class="events-section">
        <div class="container">
            <div class="row">
                <div class="col-sm-12 col-xs-12">
                    <div class="title"><span>events</span></div>
                </div>
                <div class="col-sm-12 col-xs-12">
                    <a class="btn view-all" href="#">View All</a>
                     <?php //dynamic_sidebar('sidebar-4');?>
                    <div class="event-slider">
                         
                        <?php //echo do_shortcode('[events_list scope="future" limit=5 pagination=1]'); ?>
                        
                        <div class="owl-carousel owl-theme owlThree"> 
                            
<?php echo do_shortcode('[events_list scope="future"]<div class="item"><div class="img-box">#_EVENTIMAGE</div><div class="info"><div class="date-info"><span>#d</span>#F</div><div class="heading">#_EVENTNAME</div><ul><li><span><i class="fa fa-calendar"></i></span>#_EVENTDATES <br/><strong> #_EVENTTIMES</strong></li><li><span><i class="fa fa-map-marker"></i></span>#_LOCATIONADDRESS</li></ul></div>#_EVENTEXCERPT<a class="btn" href="#">Register</a></div>[/events_list]'); ?>                                   
                            
                
                            </div>
                      
                    </div>
                </div>
            </div>
        </div>
    </section>
    <div class="clearfix"></div>
    <!-- EVENTS SECTION END -->
    
    <!-- VIDEO SECTION START -->
    <div class="container">
        <div class="row video-section">
            <div class="col-sm-6 col-xs-12">
                <div class="video-cont">
                    <img src="<?php echo get_post_meta(10, 'video_url', true); ?>" />
                    <div class="overlay">
                        <span><img src="<?php echo get_template_directory_uri(); ?>/images/video-icon.png" /></span>
                    </div>
                </div>
            </div>
            <div class="col-sm-6 col-xs-12">
                <div class="news-cont">
                    <div class="news-heading">
                        <div class="title"><?php echo get_post_meta(10, 'lates_news_title', true); ?></div>
                        <a class="btn" href="#">view all</a>
                    </div>
                    
                     <?php
                query_posts( array(
                'post_type' => 'post',
                'posts_per_page'   => 2,
                'orderby'          => 'post_date',
                'order'            => 'DESC',
                'post_status'      => 'publish',
                )); 
               
                if( have_posts() ): while ( have_posts() ) : the_post(); 
                $post_feat_image = wp_get_attachment_url( get_post_thumbnail_id($post->ID) );

            ?>   
                    <div class="news-box">
                        <div class="news-img">
                            
                            <?php echo get_the_post_thumbnail($post->ID,'home-news',array('class' => 'img-responsive')); ?>
                        </div>
                        <h4><?php the_title();?></h4>
                        <?php the_excerpt();?>
                        <div class="info-desc">
                            <div class="date"><?php the_modified_date('d M. Y'); ?></div>
                            <a class="reply" href="<?php the_permalink()?>"><span><i class="fa fa-reply"></i></span>Reply</a>
                        </div>
                    </div>
                  <?php endwhile;    endif;?> 
                   
                </div>
            </div>
        </div>
       
    </div>  
    <!-- VIDEO SECTION END-->
     <div class="clearfix"></div>
     
   <style>
      /* Always set the map height explicitly to define the size of the div
       * element that contains the map. */
      #map {
        height: 710px;
        width:100%;
      }
      /* Optional: Makes the sample page fill the window. */
      html, body {
        height: 100%;
        margin: 0;
        padding: 0;
      }


     
    </style>  



    
<?php get_footer(); ?>
