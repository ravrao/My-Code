<?php /* Template Name: Instructors Template */

get_header(); ?> 
<?php   $page_lang = ICL_LANGUAGE_CODE;?>  
<div id="common" class="container inner-cont Instructors-page">
  
	  	<div class="ins-top-sec">
                    <?php
                            $args= array(
                            'post_type' => 'our_team', 
                            'posts_per_page'   => 1,
                            'orderby'          => 'post_date',
                            'order'            => 'DESC',
                            'post_status'      => 'publish',
                            'meta_query'  => array(
                            array(
                                'key' => 'owner',
                                'value' => 'yes'
                            )
                        )
                            );
                        
                           $query=new WP_Query($args); 
                            if( $query->have_posts() ): while ( $query->have_posts() ) : $query->the_post(); 
                             $feat_image = wp_get_attachment_url( get_post_thumbnail_id($post->ID) );
                              $state = get_the_terms( $post->ID, 'state');  //var_dump($categories);
                              $sname= $state[0]->name;
                              $gettitle = get_the_title();
                   
                    ?> 
	  		<div class="Instructor-des">
                            <a href="<?php the_permalink(); ?>"><img src="<?php echo $feat_image;?>" alt="" class="img-responsive ins-img"></a>
                            <a href="<?php the_permalink(); ?>"><h3><?php echo mb_substr($gettitle, 0, 30);?></h3></a>
	  			<h5><?php the_excerpt();?></h5>
	  			<div class="ins-contact">
	  				<a href="tel: <?php echo get_post_meta($post->ID, 'phone', true); ?>"><span><i class="fa fa-phone" aria-hidden="true"></i></span><?php echo get_post_meta($post->ID, 'phone', true); ?></a>
	  				<a href="mailto: <?php echo get_post_meta($post->ID, 'email', true); ?>"><span><i class="fa fa-envelope"></i></span><?php echo get_post_meta($post->ID, 'email', true); ?></a>
	  			</div>
	  		</div>
                    <?php endwhile; endif;?>
	  			
                    <form name="frm1" method="post" action=""  id="frm1">
	  		<div class="level-search">	  			
				<label>		
					<select name="category"  required id="category" class="em-events-search-category">
                                            <?php if($page_lang=='en') { ?> 
                                            <option value="" selected="selected">Level</option>
                                            <?php } else { ?>
                                             <option value="" selected="selected">级别</option> 
                                            <?php } ?>
                                            <?php   
                                            $level=get_categories(array('taxonomy' => 'level', 'orderby' => 'ID', 'order' => 'ASC','hide_empty'=>1));
                                            $sorted_cats = array();
                                            foreach($level as $cat){
                                              $ordr = get_field('custom_order', 'level' . '_' . $cat->term_id); //var_dump($ordr);
                                              $sorted_cats[$ordr] = $cat;
                                            }
                                            ksort($sorted_cats); //var_dump($sorted_cats);
                                            foreach($sorted_cats as $lvalue)
                                               {
                                            ?> 
                                             <option value="<?php echo $lvalue->term_id;?>"  <?php if($_REQUEST['category']== $lvalue->term_id ) { ?>selected="true"<?php } ?>><?php echo $lvalue->name;?></option>
                                               <?php } ?>    
					</select>
				</label>
                            <input type="submit" name="submit" value="<?php if($page_lang=='en') { ?>Search<?php } else { ?>搜索<?php } ?>" class="ins-submit btn">
                            <a href="<?php echo get_page_link(1126); ?>" class="show-all-btn"><?php if($page_lang=='en') { ?>Show All<?php } else {?> 显示所有<?php } ?></a>
                                
	  		</div>
                    </form>
	  		<div class="clearfix"></div>
	  	</div>

 		<div class="clearfix"></div>
                
                <?php
                if (isset($_REQUEST['submit'])) {
                $taxID=$_REQUEST['category'];    
                ?> 
                 
              
 		<div class="instructor-div">
 			<div class="ins-head">
                                <h4><span> <?php if($page_lang=='en') { ?>Level<?php } else { ?>级别<?php } ?></span> : <?php $taxno = get_term_by('id', $taxID, 'level');  echo $taxno->name;?></h4>
                               
                                <?php if($page_lang=='en') { ?>
                                <a href="<?php echo get_option('home'); ?>/level/<?php echo $taxno->slug;?>/?lang=en#common">View All</a>
                                <?php } else {?>
                                <a href="<?php echo get_option('home'); ?>/level/<?php echo $taxno->slug;?>/#common"> 查看全部 </a>
                                <?php } ?>
                                
 			</div>
 			<ul class="ins-ul">
                       
                            <?php
                            $args= array(
                            'post_type' => 'our_team', 
                            'posts_per_page'   => 5,
                            'orderby'          => 'post_date',
                            'order'            => 'DESC',
                            'post_status'      => 'publish',
                            'tax_query' => array(
                                array(
                                   'taxonomy' => 'level',
                                   'field' => 'term_id',
                                   'terms' =>  $taxID,
                                   'include_children' => false 

                                )
                            )
                            );
                        
                           $query=new WP_Query($args); 
                            if( $query->have_posts() ): while ( $query->have_posts() ) : $query->the_post(); 
                             $feat_image = wp_get_attachment_url( get_post_thumbnail_id($post->ID) );
                              $state = get_the_terms( $post->ID, 'state');  //var_dump($categories);
                              $sname= $state[0]->name;
                              
                              $city = get_the_terms( $post->ID, 'city');  //var_dump($categories);
                              $scity= $city[0]->name;
                             $gettitle = get_the_title();
                   
                    ?> 
                            <li>
                                <div class="inst-inr-div">
                                    <a href="<?php the_permalink(); ?>">
                                        <?php if($feat_image!='') {?>
                                        <img src="<?php echo $feat_image;?>" alt="" class="img-responsive ins-img">
                                        <?php } else {?>
                                        <img src="<?php bloginfo('template_url')?>/images/men.jpeg" alt="" class="img-responsive ins-img">
                                        <?php } ?>
                                    </a>
                                   <a href="<?php the_permalink(); ?>"><h5 class="name"><?php echo mb_substr($gettitle, 0, 30);?></h5></a>
                                        <h6 class="add"><?php echo $sname;?>, <span><?php echo $scity ; //echo get_post_meta($post->ID, 'position', true); ?></span></h6>
                                </div>
                            </li>
                            <?php endwhile; endif;?> 
 				
 			</ul>
 		</div>
                <div class="clearfix"></div>
                  

                <?php } 
                else 
                {     
                  $level=get_categories(array('taxonomy' => 'level', 'orderby' => 'ID', 'order' => 'ASC', 'hide_empty'=>1));
                  //var_dump($level);
                  $sorted_cats = array();
                  foreach($level as $cat){
	            $ordr = get_field('custom_order', 'level' . '_' . $cat->term_id); //var_dump($ordr);
		    $sorted_cats[$ordr] = $cat;
                  }
		  ksort($sorted_cats); //var_dump($sorted_cats);
                
                  //foreach($level as $lvalue)
		  foreach($sorted_cats as $lvalue)
                  {
                ?> 
              
 		<div class="instructor-div">
 			<div class="ins-head">
 				<h4><span><?php if($page_lang=='en') { ?>Level<?php } else { ?>级别<?php } ?></span> : <?php echo $lvalue->name;?></h4>
 				<?php if($page_lang=='en') { ?>
                                <a href="<?php echo get_option('home'); ?>/level/<?php echo $lvalue->slug;?>/?lang=en#common">View All</a>
                                <?php } else {?>
                                <a href="<?php echo get_option('home'); ?>/level/<?php echo $lvalue->slug;?>?lang=zh-hans/#common">查看全部 </a>
                                <?php } ?>
 			</div>
 			<ul class="ins-ul">
                       
                            <?php
                            $args= array(
                            'post_type' => 'our_team', 
                            'posts_per_page'   => 5,
                            'orderby'          => 'post_date',
                            'order'            => 'DESC',
                            'post_status'      => 'publish',
                            'tax_query' => array(
                                array(
                                   'taxonomy' => 'level',
                                   'field' => 'term_id',
                                   'terms' =>  $lvalue->term_id,
                                   'include_children' => false 

                                )
                            )
                            );
                        
                           $query=new WP_Query($args); 
                            if( $query->have_posts() ): while ( $query->have_posts() ) : $query->the_post(); 
                             $feat_image = wp_get_attachment_url( get_post_thumbnail_id($post->ID) );
                              $state = get_the_terms( $post->ID, 'state');  //var_dump($categories);
                              $sname= $state[0]->name;
                              $city = get_the_terms( $post->ID, 'city');  //var_dump($categories);
                              $scity= $city[0]->name;
                              $gettitle = get_the_title();
                              
                    ?> 
                            <li>
                                <div class="inst-inr-div">
                                    <a href="<?php the_permalink(); ?>"> 
                                        <?php if($feat_image!='') {?>
                                        <img src="<?php echo $feat_image;?>" alt="" class="img-responsive ins-img">
                                        <?php } else {?>
                                        <img src="<?php bloginfo('template_url')?>/images/men.jpeg" alt="" class="img-responsive ins-img">
                                        <?php } ?>
                                    </a>
                                    <a href="<?php the_permalink(); ?>"><h5 class="name"><?php echo mb_substr($gettitle, 0, 30);?></h5></a>
                                        <h6 class="add"><?php echo $sname;?>, <span><?php echo $scity; //echo get_post_meta($post->ID, 'position', true); ?></span></h6>
                                </div>
                            </li>
                            <?php endwhile; endif;?> 
 				
 			</ul>
 		</div>
                <div class="clearfix"></div>
                   <?php };
                }   
                ?>

 		

 		


    </div>




    
<?php get_footer(); ?>
