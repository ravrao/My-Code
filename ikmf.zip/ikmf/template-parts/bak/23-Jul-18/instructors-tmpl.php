<?php /* Template Name: Instructors Template */

get_header(); ?> 
    
<div id="common" class="container inner-cont Instructors-page">
  
	  	<div class="ins-top-sec">
                    <?php
                            $args= array(
                            'post_type' => 'our_team', 
                            'posts_per_page'   => 1,
                            'orderby'          => 'post_date',
                            'order'            => 'DESC',
                            'post_status'      => 'publish',
                            'meta_query'  => array(
                            array(
                                'key' => 'owner',
                                'value' => 'yes'
                            )
                        )
                            );
                        
                           $query=new WP_Query($args); 
                            if( $query->have_posts() ): while ( $query->have_posts() ) : $query->the_post(); 
                             $feat_image = wp_get_attachment_url( get_post_thumbnail_id($post->ID) );
                              $state = get_the_terms( $post->ID, 'state');  //var_dump($categories);
                              $sname= $state[0]->name;
                   
                    ?> 
	  		<div class="Instructor-des">
                            <a href="<?php the_permalink(); ?>"><img src="<?php echo $feat_image;?>" alt="" class="img-responsive ins-img"></a>
                            <a href="<?php the_permalink(); ?>"><h3><?php the_title();?></h3></a>
	  			<h5><?php the_excerpt();?></h5>
	  			<div class="ins-contact">
	  				<a href="tel: <?php echo get_post_meta($post->ID, 'phone', true); ?>"><span><i class="fa fa-phone" aria-hidden="true"></i></span><?php echo get_post_meta($post->ID, 'phone', true); ?></a>
	  				<a href="mailto: <?php echo get_post_meta($post->ID, 'email', true); ?>"><span><i class="fa fa-envelope"></i></span><?php echo get_post_meta($post->ID, 'email', true); ?></a>
	  			</div>
	  		</div>
                    <?php endwhile; endif;?>
	  			
                    <form name="frm1" method="post" action=""  id="frm1">
	  		<div class="level-search">	  			
				<label>		
					<select name="category"  required id="category" class="em-events-search-category">
                                             <option value="" selected="selected">Level</option>
                                            <?php   
                                            $level=get_categories(array('taxonomy' => 'level', 'orderby' => 'ID', 'order' => 'ASC','hide_empty'=>0));
                                            $sorted_cats = array();
                                            foreach($level as $cat){
                                              $ordr = get_field('custom_order', 'level' . '_' . $cat->term_id); //var_dump($ordr);
                                              $sorted_cats[$ordr] = $cat;
                                            }
                                            ksort($sorted_cats); //var_dump($sorted_cats);
                                            foreach($sorted_cats as $lvalue)
                                               {
                                            ?> 
                                             <option value="<?php echo $lvalue->term_id;?>"  <?php if($_REQUEST['category']== $lvalue->term_id ) { ?>selected="true"<?php } ?>><?php echo $lvalue->name;?></option>
                                               <?php } ?>    
					</select>
				</label>
                            <input type="submit" name="submit" value="Search" class="ins-submit btn">
                            <a href="<?php echo get_page_link(1126); ?>" class="show-all-btn">Show All</a>
                                
	  		</div>
                    </form>
	  		<div class="clearfix"></div>
	  	</div>

 		<div class="clearfix"></div>
                
                <?php
                if (isset($_REQUEST['submit'])) {
                $taxID=$_REQUEST['category'];    
                ?> 
                 
              
 		<div class="instructor-div">
 			<div class="ins-head">
 				<h4><span>Level</span> : <?php $taxno = get_term_by('id', $taxID, 'level');  echo $taxno->name;?></h4>
 				<a href="<?php echo get_option('home'); ?>/level/<?php echo $taxno->slug;?>/#common">View All</a>
 			</div>
 			<ul class="ins-ul">
                       
                            <?php
                            $args= array(
                            'post_type' => 'our_team', 
                            'posts_per_page'   => 5,
                            'orderby'          => 'post_date',
                            'order'            => 'DESC',
                            'post_status'      => 'publish',
                            'tax_query' => array(
                                array(
                                   'taxonomy' => 'level',
                                   'field' => 'term_id',
                                   'terms' =>  $taxID,
                                   'include_children' => false 

                                )
                            )
                            );
                        
                           $query=new WP_Query($args); 
                            if( $query->have_posts() ): while ( $query->have_posts() ) : $query->the_post(); 
                             $feat_image = wp_get_attachment_url( get_post_thumbnail_id($post->ID) );
                              $state = get_the_terms( $post->ID, 'state');  //var_dump($categories);
                              $sname= $state[0]->name;
                              
                              $city = get_the_terms( $post->ID, 'city');  //var_dump($categories);
                              $scity= $city[0]->name;
                   
                    ?> 
                            <li>
                                <div class="inst-inr-div">
                                    <a href="<?php the_permalink(); ?>"><img src="<?php echo $feat_image;?>" alt="" class="img-responsive ins-img"></a>
                                   <a href="<?php the_permalink(); ?>"><h5 class="name"><?php the_title();?></h5></a>
                                        <h6 class="add"><?php echo $sname;?>, <span><?php echo $scity ; //echo get_post_meta($post->ID, 'position', true); ?></span></h6>
                                </div>
                            </li>
                            <?php endwhile; endif;?> 
 				
 			</ul>
 		</div>
                <div class="clearfix"></div>
                  

                <?php } 
                else 
                {     
                  $level=get_categories(array('taxonomy' => 'level', 'orderby' => 'ID', 'order' => 'ASC', 'hide_empty'=>0));
                  //var_dump($level);
                  $sorted_cats = array();
                  foreach($level as $cat){
	            $ordr = get_field('custom_order', 'level' . '_' . $cat->term_id); //var_dump($ordr);
		    $sorted_cats[$ordr] = $cat;
                  }
		  ksort($sorted_cats); //var_dump($sorted_cats);
                
                  //foreach($level as $lvalue)
		  foreach($sorted_cats as $lvalue)
                  {
                ?> 
              
 		<div class="instructor-div">
 			<div class="ins-head">
 				<h4><span>Level</span> : <?php echo $lvalue->name;?></h4>
 				<a href="<?php echo get_option('home'); ?>/level/<?php echo $lvalue->slug;?>#common">View All</a>
 			</div>
 			<ul class="ins-ul">
                       
                            <?php
                            $args= array(
                            'post_type' => 'our_team', 
                            'posts_per_page'   => 5,
                            'orderby'          => 'post_date',
                            'order'            => 'DESC',
                            'post_status'      => 'publish',
                            'tax_query' => array(
                                array(
                                   'taxonomy' => 'level',
                                   'field' => 'term_id',
                                   'terms' =>  $lvalue->term_id,
                                   'include_children' => false 

                                )
                            )
                            );
                        
                           $query=new WP_Query($args); 
                            if( $query->have_posts() ): while ( $query->have_posts() ) : $query->the_post(); 
                             $feat_image = wp_get_attachment_url( get_post_thumbnail_id($post->ID) );
                              $state = get_the_terms( $post->ID, 'state');  //var_dump($categories);
                              $sname= $state[0]->name;
                              $city = get_the_terms( $post->ID, 'city');  //var_dump($categories);
                              $scity= $city[0]->name;
                    ?> 
                            <li>
                                <div class="inst-inr-div">
                                    <a href="<?php the_permalink(); ?>"> <img src="<?php echo $feat_image;?>" alt="" class="img-responsive ins-img"></a>
                                    <a href="<?php the_permalink(); ?>"><h5 class="name"><?php the_title();?></h5></a>
                                        <h6 class="add"><?php echo $sname;?>, <span><?php echo $scity; //echo get_post_meta($post->ID, 'position', true); ?></span></h6>
                                </div>
                            </li>
                            <?php endwhile; endif;?> 
 				
 			</ul>
 		</div>
                <div class="clearfix"></div>
                   <?php };
                }   
                ?>

 		

 		


    </div>




    
<?php get_footer(); ?>
