<?php /* Template Name: Supervision Template */
get_header(); ?> 
 <?php   $page_lang = ICL_LANGUAGE_CODE;?>    
 <div class="container inner-cont" id="common">
     <div class="row">
        <div class="col-sm-12 col-xs-12">
            <div class="title ins-detail"><span><?php the_title();?></span></div>
        </div>
    </div>
     
     <?php
     while ( have_posts() ) : the_post();
     ?>
     <div class="content"><?php the_content();?></div>
     <?php endwhile;?>
    <div class="row">
        <div class="col-sm-12 col-xs-12 contact-form">
            <?php if($page_lang=='en') { ?>
            <?php echo do_shortcode('[contact-form-7 id="640" title="Supervision"]')?>
            <?php } else {?>
            <?php echo do_shortcode(' [contact-form-7 id="1451" title="Supervision_chinese"]')?>
            <?php } ?>
           
        </div>
        
    </div>

    </div>





<?php get_footer(); ?>
