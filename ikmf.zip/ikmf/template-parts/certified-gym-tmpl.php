<?php /* Template Name: Certified-gym Template */
get_header(); ?> 
<?php   $page_lang = ICL_LANGUAGE_CODE;?>

<script src="<?php echo get_template_directory_uri(); ?>/js/jquery.min.js"></script>

<div id="common" class="container inner-cont">
     
  <div class="row">
        <div class="col-sm-12 col-xs-12">
            <div class="title ins-detail"><?php the_title();?></div>
        </div>
    </div>

    
    
 
<section class="find-section">
 <div class="ins-top-sec">   
<form name="frm1" method="post" action="<?php echo $_SERVER['REQUEST_URI']; ?>#common" id="frm1">
    <div class="level-search">	  			
        <label>		
                    <select name="category" required id="category" class="em-events-search-category">
                         <option value="" selected="selected"><?php if($page_lang=='en') { ?>Select To Search<?php } else {?>选择省份<?php } ?></option>
                        <?php   
                        $level=get_categories(array('taxonomy' => 'province', 'orderby'=> 'title', 'order' => 'ASC', 'hide_empty'=>1));
                        $sorted_cats = array();
                        foreach($level as $cat){
                        $ordr = get_field('order', 'province' . '_' . $cat->term_id); //var_dump($ordr);
                        $sorted_cats[$ordr] = $cat;
                      }
                        ksort($sorted_cats); //var_dump($sorted_cats);
                        foreach($sorted_cats as $lvalue)
                        {
                        ?> 
                         <option value="<?php echo $lvalue->term_id;?>"  <?php if($_REQUEST['category']== $lvalue->term_id ) { ?>selected="true"<?php } ?>><?php echo $lvalue->name;?></option>
                           <?php } ?>    
                    </select>
            </label>
        <input type="submit" name="submit" value="<?php if($page_lang=='en') { ?>Search<?php } else {?>搜索<?php } ?>" class="ins-submit btn">
        <div class="viewmore"><a href="<?php echo get_page_link(1075); ?>" class="ins-submit btn"><?php if($page_lang=='en') { ?>View All Gym<?php } else {?>查看所有场馆<?php } ?></a></div>
    </div>
</form>
     
 </div>

        
    </section>


<?php
if (isset($_POST['submit'])) { ?> 
<div class="contact_map">
        <div style="width:100%;height:700px;border:#ccc solid 1px;float:left;" id="dituContent1"></div>
 
</div>

<script type="text/javascript" src="http://api.map.baidu.com/api?v=2.0&ak=DBa5badfc49c1ce0148b174ae3bdf0ea"></script>


<?php
$provname= $_REQUEST['category']; 

$args= array(
'post_type' => 'gymlocation', 
'posts_per_page'   => -1,
'orderby'          => 'post_date',
'order'            => 'DESC',
'post_status'      => 'publish',
'tax_query' => array(
                         array(
                            'taxonomy' => 'province',
                            'field' => 'term_id',
                            'terms' =>  $provname,
                            'include_children' => false 

                         )
                     )
);


$query=new WP_Query($args); 
if( $query->have_posts() ): while ( $query->have_posts() ) : $query->the_post(); 

?> 
<?php $addresspr[]=get_post_meta($post->ID, 'gim-location', true); 
$featimage[]= wp_get_attachment_url( get_post_thumbnail_id($post->ID) );
$title[]= get_the_title() ;
$post_slug[]=$post->post_name;
?>        
<?php endwhile; endif;?>

<?php
//foreach($addresspr as $key => $value){
//	echo '<br/>'.$value;
//}
?>

<script type="text/javascript">
$(document).ready(function(){
  var map = new BMap.Map("dituContent1");
  <?php foreach($addresspr as $key => $value){ ?>
  var locaddress="<?php echo $addresspr[$key]; ?>";
  var featimg="<?php echo $featimage[$key]; ?>";
  var titleg="<?php echo $title[$key]; ?>";
  var postslug="<?php echo $post_slug[$key]; ?>";
  createMapMarker(locaddress, map, featimg, titleg, postslug);
  <?php } ?>
});

function createMapMarker(address, map, fimage, titgym, posttslug){
  var geocoder = new BMap.Geocoder();
  geocoder.getPoint(address, function(res){ console.log(res); //console.log(res.lat);
    //alert(address);
    //alert(posttslug);
    var lng=res.lng; var lat=res.lat; //alert(res.lng +','+ res.lat);
    var point = new BMap.Point(lng,lat);
    var sContent = "<h4 style='margin:0 0 5px 0;padding:0.2em 0'></h4>" +
                "<p style='margin:0;line-height:1.5;font-size:13px;text-indent:2em; font-weight:bold;'>"+titgym+"</p>" +
                '<p style="margin:0;line-height:1.5;font-size:13px;text-indent:2em"><img width="139" height="104" id="imgDemo" src="'+fimage+'" /></p>' +
		"<p style='margin:0;line-height:1.5;font-size:13px;text-indent:2em'>"+address+"</p>" +
                "<a href='http://lab-1.sketchdemos.com/P1091_IKMF/gymlocation/"+posttslug+"' class='ins-submit btn viewmoreb'>View More</a></div>";
    var icon = new BMap.Icon('<?php echo get_option('home'); ?>/wp-content/themes/ikmf/images/map-marker.png', new BMap.Size(50, 62), {
		anchor: new BMap.Size(10, 30),
		infoWindowAnchor: new BMap.Size(10, 0)
    });
    var marker = new BMap.Marker(point, { icon: icon, title: address }); 
    //alert(sContent);									
    
    //var marker = new BMap.Marker(point);
    var infoWindow = new BMap.InfoWindow(sContent);
    map.addControl(new BMap.NavigationControl());
    map.centerAndZoom(point, 9);
    map.enableScrollWheelZoom(); 
    map.addOverlay(marker);
    
    marker.addEventListener("click", function(){
	this.openInfoWindow(infoWindow);
	document.getElementById('imgDemo').onload = function (){ infoWindow.redraw(); }
    });
    
  });
}
</script>
<?php
}
else {
?> 

<div class="clearfix"></div>
<section class="find-section">
    <div class="location-cont" <?php if($page_lang=='en') { ?>style="background-image: url(<?php echo get_field('map_image', 293);?>"<?php } else {?>style="background-image: url(<?php echo get_field('map_image', 612);?>"<?php } ?>> 
        <?php if($page_lang=='en') { ?>
            <div class="loc-box boxOne">
                <a href="#" title=""><span><i class="fa fa-map-marker"></i></span>Beijing</a>
            </div>
            <div class="loc-box boxTwo">
                <a href="#" title=""><span><i class="fa fa-map-marker"></i></span>GuangDong</a>
            </div>
            <div class="loc-box boxThree">
                <a href="#" title=""><span><i class="fa fa-map-marker"></i></span>Shanghai</a>
            </div>
            <div class="loc-box boxFour">
                <a href="#" title=""><span><i class="fa fa-map-marker"></i></span>Gansu</a>
            </div>
            <div class="loc-box boxFive">
                <a href="#" title=""><span><i class="fa fa-map-marker"></i></span>Guangxi</a>
            </div>
            <div class="loc-box boxSix">
                <a href="#" title=""><span><i class="fa fa-map-marker"></i></span>Heilongjiang</a>
            </div>
            <div class="loc-box boxSeven">
                <a href="#" title=""><span><i class="fa fa-map-marker"></i></span>Henan</a>
            </div>
            <div class="loc-box boxEight">
                <a href="#" title=""><span><i class="fa fa-map-marker"></i></span>Hubei</a>
            </div>
            <div class="loc-box boxNine">
                <a href="#" title=""><span><i class="fa fa-map-marker"></i></span>Hunan</a>
            </div>
            <div class="loc-box boxTen">
                <a href="#" title=""><span><i class="fa fa-map-marker"></i></span>Jiangsu</a>
            </div>
            <div class="loc-box boxEleven">
                <a href="#" title=""><span><i class="fa fa-map-marker"></i></span>Jilin</a>
            </div>
            <div class="loc-box boxTwelve">
                <a href="#" title=""><span><i class="fa fa-map-marker"></i></span>Liaoning</a>
            </div>
            <div class="loc-box boxThirteen">
                <a href="#" title=""><span><i class="fa fa-map-marker"></i></span>Shaanxi</a>
            </div>
            <div class="loc-box boxFourteen">
                <a href="#" title=""><span><i class="fa fa-map-marker"></i></span>Shandong</a>
            </div>
            <div class="loc-box boxFifteen">
                <a href="#" title=""><span><i class="fa fa-map-marker"></i></span>Shanxi</a>
            </div>
            <div class="loc-box boxSixteen">
                <a href="#" title=""><span><i class="fa fa-map-marker"></i></span>Sichuan</a>
            </div>
            <div class="loc-box boxSeventeen">
                <a href="#" title=""><span><i class="fa fa-map-marker"></i></span>Tianjin</a>
            </div>
            <div class="loc-box boxEighteen">
                <a href="#" title=""><span><i class="fa fa-map-marker"></i></span>Yunnan</a>
            </div>
            <div class="loc-box boxNineteen">
                <a href="#" title=""><span><i class="fa fa-map-marker"></i></span>Zhejiang</a>
            </div>
        
        <?php } else { ?>
        
        <div class="loc-box boxOne">
                <a href="#" title=""><span><i class="fa fa-map-marker"></i></span>北京</a>
            </div>
            <div class="loc-box boxTwo">
                <a href="#" title=""><span><i class="fa fa-map-marker"></i></span>广东</a>
            </div>
            <div class="loc-box boxThree">
                <a href="#" title=""><span><i class="fa fa-map-marker"></i></span>上海</a>
            </div>
            <div class="loc-box boxFour">
                <a href="#" title=""><span><i class="fa fa-map-marker"></i></span>甘肃</a>
            </div>
            <div class="loc-box boxFive">
                <a href="#" title=""><span><i class="fa fa-map-marker"></i></span>广西</a>
            </div>
            <div class="loc-box boxSix">
                <a href="#" title=""><span><i class="fa fa-map-marker"></i></span>黑龙江</a>
            </div>
            <div class="loc-box boxSeven">
                <a href="#" title=""><span><i class="fa fa-map-marker"></i></span>河南</a>
            </div>
            <div class="loc-box boxEight">
                <a href="#" title=""><span><i class="fa fa-map-marker"></i></span>湖北</a>
            </div>
            <div class="loc-box boxNine">
                <a href="#" title=""><span><i class="fa fa-map-marker"></i></span>湖南</a>
            </div>
            <div class="loc-box boxTen">
                <a href="#" title=""><span><i class="fa fa-map-marker"></i></span>江苏</a>
            </div>
            <div class="loc-box boxEleven">
                <a href="#" title=""><span><i class="fa fa-map-marker"></i></span>吉林</a>
            </div>
            <div class="loc-box boxTwelve">
                <a href="#" title=""><span><i class="fa fa-map-marker"></i></span>辽宁</a>
            </div>
            <div class="loc-box boxThirteen">
                <a href="#" title=""><span><i class="fa fa-map-marker"></i></span>陕西</a>
            </div>
            <div class="loc-box boxFourteen">
                <a href="#" title=""><span><i class="fa fa-map-marker"></i></span>山东</a>
            </div>
            <div class="loc-box boxFifteen">
                <a href="#" title=""><span><i class="fa fa-map-marker"></i></span>山西</a>
            </div>
            <div class="loc-box boxSixteen">
                <a href="#" title=""><span><i class="fa fa-map-marker"></i></span>四川</a>
            </div>
            <div class="loc-box boxSeventeen">
                <a href="#" title=""><span><i class="fa fa-map-marker"></i></span>天津</a>
            </div>
            <div class="loc-box boxEighteen">
                <a href="#" title=""><span><i class="fa fa-map-marker"></i></span>云南</a>
            </div>
            <div class="loc-box boxNineteen">
                <a href="#" title=""><span><i class="fa fa-map-marker"></i></span>浙江</a>
            </div>
        <?php } ?>
    </div>

        
</section>

<script>
$('.loc-box a').click(function(){  
 var selText = $(this).text(); //alert(selText);
 $('#category option').each(function(){ $(this).removeAttr('selected'); });
 $('#category option').each(function(){ 
  var optText = $(this).text(); //alert(optText);
  if( selText == optText ){ //alert('match');
    $(this).attr('selected', 'selected');	
  }
 });
 $('.ins-submit').trigger('click');
});
</script>
<?php } ?>

</div>
<?php get_footer(); ?>
