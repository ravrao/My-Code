<?php /* Template Name: Courses Template */
get_header(); ?> 
    
    <div id="common" class="container inner-cont">
   <?php $the_query = new WP_Query( 'page_id=17' ); ?>
    <?php while ($the_query -> have_posts()) : $the_query -> the_post();  
       ?>     
  <div class="row">
        <div class="col-sm-12 col-xs-12">
            <div class="title"><?php echo get_post_meta($post->ID, 'big_title', true); ?></div>
        </div>
    </div>
 <?php endwhile;?> 
 
<section class="faq-section">
    <div class="container">
        <div class="row">
        <div class="col-md-12 col-sm-12 col-xs-12 courseTab">
        <div class="panel-group" id="accordion" role="tablist" aria-multiselectable="true">
          <div class="row">
        <?php
        
           $paged = get_query_var('paged') ? get_query_var('paged') : 1;
            
                      $type = 'our_course';
                      $args=array(
                      'post_type' => $type,
                      'post_status' => 'publish',
                      'paged' => $paged,
                      'posts_per_page' => 9,
                      
                      'orderby' => 'post_date',
                      'order' => 'DESC'    

                      );
                      $loop = new WP_Query( $args );
                      while ( $loop->have_posts() ) : $loop->the_post();
            $testi_feat_image = wp_get_attachment_url( get_post_thumbnail_id($post->ID) ); 
            $categories = get_the_terms( $post->ID, 'courses');
            $content = get_the_title();
            $contenttit = strip_tags($content);
             $getexcerpt = get_the_excerpt();
            $excerp = strip_tags($getexcerpt);
        ?> 
        
            <div class="item col-md-4">
                 <a href="<?php the_permalink(); ?>"><div class="img-box">

                    <img src="<?php echo get_field('small_image', $post->ID);?>" alt="" class="img-responsive">
                    <div class="event-overlay"></div>
                     </div></a>
                <div class="info text-left">
                    <a href="<?php the_permalink(); ?>"><div class="heading"><?php echo mb_substr($content, 0, 15);?></div></a>
                    <!--<a href="#"><div class="catname">Category: <?php echo $categories[0]->name;?></div></a>-->
                    <a href="<?php the_permalink(); ?>"><?php echo mb_substr($excerp, 0, 100).' [...]';?></a>                              
                </div>                         
            </div>
           
        <?php
      
           endwhile; ?>
               <?php wp_pagenavi( array( 'query' => $loop ) ); ?>
             </div>
          
            
        </div>
        </div>
        </div>
        
      
    </div>
</section>

    

    </div>




    
<?php get_footer(); ?>
