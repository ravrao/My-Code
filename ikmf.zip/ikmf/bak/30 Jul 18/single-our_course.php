<?php
/**
 * The template for displaying all single posts and attachments
 *
 * @package WordPress
 * @subpackage Twenty_Sixteen
 * @since Twenty Sixteen 1.0
 */

get_header(); ?>
<?php  $rs=$post->ID;?>
<?php

  $terms = get_the_terms( get_the_ID(), 'courses' );

  $catname = $terms[0]->name;
?>
 <div class="container inner-cont">

		<?php
		// Start the loop.
		while ( have_posts() ) : the_post(); ?>
    <div class="row">
        <div class="col-sm-12 col-xs-12">
            <div class="title ins-detail"><?php the_title();?></div>
        </div>
    </div>
     <!--<div class="catname"><h3>Courses Name: <?php //echo $catname;?></h3></div>-->
<?php		
        the_content();

    endwhile;
    ?>

<?php  $page_lang = ICL_LANGUAGE_CODE;?>
  
<?php $posts = $ids = get_field('our_team_listing', false, false);  ?>
<div id="common">
    <?php   $page_lang = ICL_LANGUAGE_CODE;?>
   <?php if($page_lang=='en') { ?>
    <h3>Our Team</h3>
   <?php } else {?>
    <h3>执教教官</h3>
   <?php } ?>     
  

<?php //$posts = $ids = get_field('our_team_listing', false, false); ?>
<?php $posts = get_field('our_team_listing',$post->ID, false, false); //var_dump($posts); ?>
<?php $course_instructors = array(); ?>
<?php foreach($posts as $instrId){ 
	$instrLevel = get_the_terms($instrId, 'level'); //var_dump($instrLevel);
	if(!array_key_exists($instrLevel[0]->name, $course_instructors)){
            $course_instructors[$instrLevel[0]->name] = $instrId;
        } else {
	    $values = $course_instructors[$instrLevel[0]->name]; 
	    $values .= ','.$instrId;
	    $course_instructors[$instrLevel[0]->name] = $values;
        }} ?>

<ul class="inner-ul gym-locate">
<?php foreach($course_instructors as $key => $values){ ?>
 <h4 class="sub-heading"><span><?php echo 'Level: '. $key; ?></span></h4>
 <?php $valArr = explode(',',$values);
 foreach($valArr as $valId){ $instrpost = get_post($valId); ?>
 <li><a href="<?php echo $instrpost->guid;?>"><?php echo $instrpost->post_title;?></a></li>
 <?php } ?>
<?php } ?>
</ul>


    </div>  

 
     
</div>





<?php get_footer(); ?>
