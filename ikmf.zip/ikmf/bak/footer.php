

<!--    FOOTER START-->

<!--    FOOTER END-->






  
    
    
    
   

<!-- jQuery -->
    <script src="<?php echo get_template_directory_uri(); ?>/js/jquery.min.js"></script>    <!-- Bootstrap Core JavaScript -->
    <script src="<?php echo get_template_directory_uri(); ?>/js/bootstrap.min.js"></script>    
   
<!--    <script src='js/slim.min.js'></script>-->


        <!-- FOR GALLERY -->

     
    <script src="<?php echo get_template_directory_uri(); ?>/js/owl.carousel.js"></script>
    <script src="<?php echo get_template_directory_uri(); ?>/js/wow.js"></script>
    
  
   
    <script>
         $('.owlOne').owlCarousel({
            loop:true,
            margin:20,
            autoplay: true,
             dots: false,
            nav:true,
            navText : ['<i class="fa fa-chevron-left" aria-hidden="true"></i>','<i class="fa fa-chevron-right" aria-hidden="true"></i>'], 
            responsive:{
                0:{
                    items:1
                },
                600:{
                    items:1
                },
                1000:{
                    items:1
                }
            }
        });
        
        $('.owlTwo').owlCarousel({
            loop:true,
            margin:20,
            autoplay: true,
             dots: false,
            nav:true,
            navText : ['<i class="fa fa-chevron-left" aria-hidden="true"></i>','<i class="fa fa-chevron-right" aria-hidden="true"></i>'], 
            responsive:{
                0:{
                    items:1
                },
                600:{
                    items:2
                },
                1000:{
                    items:3
                }
            }
        });
        $('.owlThree').owlCarousel({
            loop:true,
            margin:20,
            autoplay: true,
             dots: false,
            nav:true,
            navText : ['<i class="fa fa-chevron-left" aria-hidden="true"></i>','<i class="fa fa-chevron-right" aria-hidden="true"></i>'], 
            responsive:{
                0:{
                    items:1
                },
                600:{
                    items:2
                },
                1000:{
                    items:3
                }
            }
        });
    </script>
    
    
    
    
       
   

<?php wp_footer(); ?>
</body>
</html>
