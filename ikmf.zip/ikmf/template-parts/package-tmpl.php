<?php /* Template Name: Package Template */
get_header(); ?> 
    
    <div class="container inner-cont">
  <div class="row">
        <div class="col-sm-12 col-xs-12">
            <div class="title ins-detail"><span><?php the_title();?></span></div>
        </div>
    </div>

 
<section class="package-section">
    
        <div class="row">
            
            <?php
                query_posts( array(
                'post_type' => 'packag',
                'posts_per_page'  => '4'  
                )); 

                if( have_posts() ): while ( have_posts() ) : the_post(); 
               $gettit=get_the_title();
            ?>
            <div class="col-md-4 col-sm-6 col-xs-12 pack-container">
                <div class="package-div">
                    <ul>
                        <li class="p-heading"><h3><?php the_title();?></h3></li>
                        <li class="p-price"><h4>$ <?php echo get_post_meta($post->ID, 'amount', true); ?> / year</h4></li>
                        <li class="p-text"><?php the_content();?></li>
                         <?php if($gettit!='Free') { ?> 
                        <li class="p-btn"><a href="#" class="btn disabled">Buy Now</a></li>
                         <?php } else {?>
                         <li class="p-btn"><a href="#" data-toggle="modal" data-target="#LoginModel" class="btn">Buy Now</a></li>
                         <?php } ?>
                    </ul>
                </div>
            </div>
            <?php endwhile; 
           endif;?>
            
        </div>
     
</section>



    </div>





    
<?php get_footer(); ?>
