<?php
/**
 * The template for displaying all single posts and attachments
 *
 * @package WordPress
 * @subpackage Twenty_Sixteen
 * @since Twenty Sixteen 1.0
 */

get_header(); ?>

<?php   $page_lang = ICL_LANGUAGE_CODE;?>
<?php $rs=$post->ID;?>
 <div class="container inner-cont instructor-detail">

		<?php
		// Start the loop.
		while ( have_posts() ) : the_post();
                $feat_image = wp_get_attachment_url( get_post_thumbnail_id($post->ID) ); 
                ?>
    <div class="row">
        <div class="col-sm-12 col-xs-12">
            <div class="title ins-detail"><?php the_title();?>
            <?php
            $state = get_the_terms( $post->ID, 'state');  //var_dump($categories);
            $sname= $state[0]->name;    
            ?>
            
            </div>
        </div>
    </div>

<div class="row">
  <div class="col-md-3 col-sm-5 col-xs-12">
     <div class="Instructor-des innerteam">
         
            
              <?php if($feat_image!='') {?>
            <img src="<?php echo $feat_image;?>" alt="" class="img-responsive ins-img">
            <?php } else {?>
            <img src="<?php bloginfo('template_url')?>/images/men.jpeg" alt="" class="img-responsive ins-img">
            <?php } ?>
            <h4 class="text-center"><?php echo $sname;?>: <?php echo get_post_meta($post->ID, 'position', true); ?></h4>

                <div class="ins-head">
                    <?php $categories = get_the_terms( $post->ID, 'level'); ?>
                    <?php if($categories[0]->name!='') {?><h4><?php if($page_lang=='en'){?><span>Level</span><?php } else {?><span>级别</span><?php } ?> :  <?php  echo $taxnam = $categories[0]->name; ?></h4><?php } ?>
                </div>
            <?php 
            $impodate=get_post_meta($post->ID, 'sensitive_data(email,phone)_show', true); 
            if($impodate=='yes')
            {
            ?>
            <div class="ins-contact text-center">
            <a href="tel: <?php echo get_post_meta($post->ID, 'phone', true); ?>"><span><i class="fa fa-phone" aria-hidden="true"></i></span><?php echo get_post_meta($post->ID, 'phone', true); ?></a>
            <a href="mailto: <?php echo get_post_meta($post->ID, 'email', true); ?>"><span><i class="fa fa-envelope"></i></span><?php echo get_post_meta($post->ID, 'email', true); ?></a>
            </div>
            <?php } ?>
    </div><?php endwhile; wp_reset_postdata();?>
      <div class="myteamlist"> 
   
   <?php if($page_lang=='en') { ?>    
  <h3>COURSES TAUGHT</h3>
   <?php } else {?>
  <h3>执教课程</h3>
  <?php } ?>
      <ul class="inner-ul">
      <?php
           query_posts( array(
           'post_type' => 'our_course', 
           'posts_per_page' => -1,   
           )); 
          
           if( have_posts() ): while ( have_posts() ) : the_post(); 
            $testi_feat_image = wp_get_attachment_url( get_post_thumbnail_id($post->ID) ); 
            $categories = get_the_terms( $post->ID, 'courses');
        ?>      
     
     
     <?php $posts = get_field('our_team_listing', false, false);  ?>
      
    <?php 
    //echo $posts;
    //var_dump($posts);
    if($posts!='') { ?> <?php
    foreach($posts as $value) {
        
       
       
        if($rs==$value)
        {
        ?>
          <li><a href="<?php the_permalink();?>"><?php the_title();?></a></li>
    
    <?php } 
    } ?> <?php }?>
     <?php
      
           endwhile; wp_reset_postdata(); ?>
           <?php endif; 
        ?> 
        </ul> 
   </div>
  </div>

  <div class="col-md-9 col-sm-7 col-xs-12">
    <?php
     //echo $rs;
     
    $my_postid = $rs;//This is page id or post id
$content_post = get_post($my_postid);
$content = $content_post->post_content;
$content = apply_filters('the_content', $content);
$content = str_replace(']]>', ']]&gt;', $content);
echo $content;

   //while ( have_posts() ) : the_post();
  
     //the_content();

    //endwhile; wp_reset_postdata();
    ?>
    
 </div>
   
</div>
     

</div>

<?php get_footer(); ?>
