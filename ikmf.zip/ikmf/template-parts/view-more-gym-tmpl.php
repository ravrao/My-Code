<?php /* Template Name: View More Gym Template */
get_header(); ?> 
  <?php   $page_lang = ICL_LANGUAGE_CODE;?>  
 <div class="container inner-cont" id="common">
     <div class="row">
        <div class="col-sm-12 col-xs-12">
            <div class="title ins-detail"><span><?php the_title();?></span></div>
        </div>
    </div>
     
    <div class="ViewGym">
           
            <div class="serach-location">
                <div class="serchFrmviewmore">
                    
                    <ul class="autoPopulate">
                  
                     <div class="catname heading"><?php echo $lvalue->name;?></div>    
                    <?php    
                       
                        query_posts( array(
                        'post_type' => 'gymlocation',
                        'posts_per_page'  => '-1',
                            
                         'meta_query' => array(
                                array(
                                  'key'     => 'main_gym',
                                  'value'   => 'yes',

                                )
                            )   
                        )); 

                        while ( have_posts() ) : the_post(); 
                        $feat_image = wp_get_attachment_url( get_post_thumbnail_id($post->ID) );
                        $city = get_the_terms( $post->ID, 'city');  //var_dump($categories);
                        $scity= $city[0]->name;
                        $province = get_the_terms( $post->ID, 'province');  //var_dump($categories);
                        $sprovince= $province[0]->name;
                       ?> 
                     <div class="catname heading"><?php echo $sprovince;?></div>
                       <li  data-field="<?php echo get_post_meta($post->ID, 'gim-location', true); ?>"> 
                           <?php if($feat_image!='') {?>
                                <a href="<?php the_permalink(); ?>"> <img src="<?php echo $feat_image;?>" alt=""/></a>
                           <?php } else { ?>
                                 <a href="<?php the_permalink(); ?>"><img src="<?php echo get_option('home'); ?>/wp-content/themes/ikmf/images/gym.jpg" alt=""/></a>
                           <?php } ?>
                                <a href="<?php the_permalink(); ?>"> <h3><?php the_title();?></h3></a>

                                <?php if($page_lang=='en') { ?>
                                
                                <?php if(get_post_meta($post->ID, 'gim-location', true)) {?>
                                <div class="catname"><p><strong>Address</strong><span>:</span> <?php echo get_post_meta($post->ID, 'gim-location', true); ?></p></div>
                                <?php } 
                                if(get_post_meta($post->ID, 'phone', true)); {
                                 ?> 
                                <div class="catname"><p><strong>Phone</strong><span>:</span><?php echo get_post_meta($post->ID, 'phone', true); ?></p></div>
                                <?php } 
                                if(get_post_meta($post->ID, 'e-mail', true)){ ?>
                                <div class="catname"><p><strong>Email</strong><span>:</span><a href="mailto:<?php echo get_post_meta($post->ID, 'e-mail', true); ?>"><?php echo get_post_meta($post->ID, 'e-mail', true); ?></a></p></div>
                                <?php } ?>
                                <div class="catname"><p><strong>Province</strong><span>:</span><?php echo $sprovince;?></p></div>
                                <div class="catname"><p><strong>City</strong><span>:</span><?php echo $scity;?></p></div>
                                <?php } else {?>
                                <?php if(get_post_meta($post->ID, 'gim-location', true)) {?>
                                <div class="catname"><p><strong>地址</strong><span>:</span> <?php echo get_post_meta($post->ID, 'gim-location', true); ?></p></div>
                                <?php } 
                                if(get_post_meta($post->ID, 'phone', true)); {
                                ?>   
                                 <div class="catname"><p><strong>电话</strong><span>:</span><?php echo get_post_meta($post->ID, 'phone', true); ?></p></div>
                                <?php } 
                                if(get_post_meta($post->ID, 'e-mail', true)){ ?>
                                <div class="catname"><p><strong>邮箱</strong><span>:</span><a href="mailto:<?php echo get_post_meta($post->ID, 'e-mail', true); ?>"><?php echo get_post_meta($post->ID, 'e-mail', true); ?></a></p></div>
                                <?php } ?>
                                <div class="catname"><p><strong>省份</strong><span>:</span><?php echo $sprovince;?></p></div>
                                <div class="catname"><p><strong>城市</strong><span>:</span><?php echo $scity;?></p></div>
                                <?php } ?>
                            
                            </li>
                        
                    <?php endwhile;    wp_reset_query();          
                    ?> 
                   
                    </ul>
                    
                   
                    <ul class="autoPopulate">
                   <?php     
                    $level=get_categories(array('taxonomy' => 'province', 'orderby' => 'title', 'order' => 'ASC','hide_empty'=>1));
                     $sorted_cats = array();
                        foreach($level as $cat){
                        $ordr = get_field('order', 'province' . '_' . $cat->term_id); //var_dump($ordr);
                        $sorted_cats[$ordr] = $cat;
                      }
                      ksort($sorted_cats); //var_dump($sorted_cats);
                    
                    foreach($sorted_cats as $lvalue)
                    { 
                    ?> 
                    <div class="catname heading"><?php if($lvalue->name!='云南' && $lvalue->name!='广东'){ echo $lvalue->name; }?></div>    
                    <?php    
                       
                        query_posts( array(
                        'post_type' => 'gymlocation',
                        'posts_per_page'  => '-1',
                            
                         'tax_query' => array(
                                array(
                                   'taxonomy' => 'province',
                                   'field' => 'term_id',
                                   'terms' =>  $lvalue->term_id,
                                   'include_children' => false 

                                )
                            ),
                         'meta_query' => array(
                                array(
                                  'key'     => 'main_gym',
                                  'value'   => 'no',

                                )
                            )    
                        )); 

                        if( have_posts() ): while ( have_posts() ) : the_post(); 
                        $feat_image = wp_get_attachment_url( get_post_thumbnail_id($post->ID) );
                        $city = get_the_terms( $post->ID, 'city');  //var_dump($categories);
                        $scity= $city[0]->name;
                        
                        $province = get_the_terms( $post->ID, 'province');  //var_dump($categories);
                        $sprovince= $province[0]->name;
                        

                    ?>    
                       <li  data-field="<?php echo get_post_meta($post->ID, 'gim-location', true); ?>"> 
                           <?php if($feat_image!='') {?>
                                <a href="<?php the_permalink(); ?>"> <?php echo get_the_post_thumbnail($post->ID,'showgymimage',array('class' => 'img-responsive')); ?>
 </a>
                           <?php } else { ?>
                                 <a href="<?php the_permalink(); ?>"><img src="<?php echo get_option('home'); ?>/wp-content/themes/ikmf/images/gym.jpg" alt=""/></a>
                           <?php } ?>
                                <a href="<?php the_permalink(); ?>"> <h3><?php the_title();?></h3></a>

                                <?php if($page_lang=='en') { ?>
                                
                                <?php if(get_post_meta($post->ID, 'gim-location', true)) {?>
                                <div class="catname"><p><strong>Address</strong><span>:</span> <?php echo get_post_meta($post->ID, 'gim-location', true); ?></p></div>
                                <?php } 
                                if(get_post_meta($post->ID, 'phone', true)); {
                                 ?> 
                                <div class="catname"><p><strong>Phone</strong><span>:</span><?php echo get_post_meta($post->ID, 'phone', true); ?></p></div>
                                <?php } 
                                if(get_post_meta($post->ID, 'e-mail', true)){ ?>
                                <div class="catname"><p><strong>Email</strong><span>:</span><a href="mailto:<?php echo get_post_meta($post->ID, 'e-mail', true); ?>"><?php echo get_post_meta($post->ID, 'e-mail', true); ?></a></p></div>
                                <?php } ?>
                                <div class="catname"><p><strong>Province</strong><span>:</span><?php echo $sprovince;?></p></div>
                                <div class="catname"><p><strong>City</strong><span>:</span><?php echo $scity;?></p></div>
                                <?php } else {?>
                                <?php if(get_post_meta($post->ID, 'gim-location', true)) {?>
                                <div class="catname"><p><strong>地址</strong><span>:</span> <?php echo get_post_meta($post->ID, 'gim-location', true); ?></p></div>
                                <?php } 
                                if(get_post_meta($post->ID, 'phone', true)); {
                                 ?>   
                                 <div class="catname"><p><strong>电话</strong><span>:</span><?php echo get_post_meta($post->ID, 'phone', true); ?></p></div>
                                <?php } 
                                if(get_post_meta($post->ID, 'e-mail', true)){ ?>
                                <div class="catname"><p><strong>邮箱</strong><span>:</span><a href="mailto:<?php echo get_post_meta($post->ID, 'e-mail', true); ?>"><?php echo get_post_meta($post->ID, 'e-mail', true); ?></a></p></div>
                                <?php } ?>
                                <div class="catname"><p><strong>省份</strong><span>:</span><?php echo $sprovince;?></p></div>
                                <div class="catname"><p><strong>城市</strong><span>:</span><?php echo $scity;?></p></div>
                                <?php } ?>
                            
                            </li>
                        
                    <?php endwhile;            endif; 
                    
                }?>    
                    </ul>
                </div>
            </div>
        </div>

    </div>





<?php get_footer(); ?>
