<?php
/**
 * The template for displaying all single posts and attachments
 *
 * @package WordPress
 * @subpackage Twenty_Sixteen
 * @since Twenty Sixteen 1.0
 */

get_header(); ?>
<?php   $page_lang = ICL_LANGUAGE_CODE;?>
<?php $rs=$post->ID;?>
<?php

  $terms = get_the_terms( get_the_ID(), 'courses' );

   $catname = $terms[0]->name;
   $city = get_the_terms( $post->ID, 'city');  //var_dump($categories);
    $scity= $city[0]->name;

    $province = get_the_terms( $post->ID, 'province');  //var_dump($categories);
    $sprovince= $province[0]->name;
?>
 <div class="container inner-cont">

		<?php
		// Start the loop.
		while ( have_posts() ) : the_post(); ?>
    <div class="row">
        <div class="col-sm-12 col-xs-12">
            <div class="title ins-detail"><?php the_title();?></div>
        </div>
    </div>
     <?php if($page_lang=='en') { ?>
     <div class="catname"><p><strong>Address</strong><span>:</span> <?php echo get_post_meta($post->ID, 'gim-location', true); ?></p></div>
     <div class="catname"><p><strong>Phone</strong><span>:</span><?php echo get_post_meta($post->ID, 'phone', true); ?></p></div>
     <div class="catname"><p><strong>Email</strong><span>:</span><a href="mailto:<?php echo get_post_meta($post->ID, 'e-mail', true); ?>"><?php echo get_post_meta($post->ID, 'e-mail', true); ?></a></p></div>
     <div class="catname"><p><strong>Province</strong><span>:</span><?php echo $sprovince;?></p></div>
     <div class="catname"><p><strong>City</strong><span>:</span><?php echo $scity;?></p></div>
     <?php } else {?>
     <div class="catname"><p><strong>地址</strong><span>:</span> <?php echo get_post_meta($post->ID, 'gim-location', true); ?></p></div>
     <div class="catname"><p><strong>电话</strong><span>:</span><?php echo get_post_meta($post->ID, 'phone', true); ?></p></div>
     <div class="catname"><p><strong>邮箱</strong><span>:</span><a href="mailto:<?php echo get_post_meta($post->ID, 'e-mail', true); ?>"><?php echo get_post_meta($post->ID, 'e-mail', true); ?></a></p></div>
     <div class="catname"><p><strong>省份</strong><span>:</span><?php echo $sprovince;?></p></div>
     <div class="catname"><p><strong>城市</strong><span>:</span><?php echo $scity;?></p></div>
     <?php } ?>
<?php		
        the_content();

    endwhile;
    ?>
     
     
     <div class="gallery-section" >
         <h3>Our Gallery</h3>    
         <div class="owl-carousel owl-theme owlFour" id="lightgallery">
     <?php     
     if( class_exists('Dynamic_Featured_Image') ) {
     global $dynamic_featured_image;
     
     $featured_images = $dynamic_featured_image->get_featured_images( $rs ); 
     $i=1;
    foreach($featured_images as $value)
    { //echo 'value'; var_dump($value);
       
     ?>
             
             <div class="item" onclick="openModal();currentSlide(<?php echo $i ;?>)" class="hover-shadow cursor">
                 <h5><?php echo $description = $dynamic_featured_image->get_image_description($value['full']); ?></h5>
                 <img src="<?php echo $value['full']?>"/>
             
             </div>
<?php
$i++;
    //You can now loop through the image to display them as required
    } } 
       ?>     
            
            

          </div>
        <!-- modal -->
         <div id="myModal" class="modal lightbox-modal">
  <span class="close cursor" onclick="closeModal()">&times;</span>
  <div class="modal-content">
      <?php     
         if( class_exists('Dynamic_Featured_Image') ) {
     global $dynamic_featured_image;
     
     $featured_images = $dynamic_featured_image->get_featured_images( $rs ); 
    foreach($featured_images as $value)
    { //echo 'value'; var_dump($value);
       
     ?>
    <div class="mySlides">
      <div class="numbertext"> <p><?php echo $description = $dynamic_featured_image->get_image_description($value['full']); ?></div>
      <img src="<?php echo $value['full']?>" class="img-responsive"/>
    </div>  

    <?php
    //You can now loop through the image to display them as required
    } } 
       ?>     
    
    <a class="prev" onclick="plusSlides(-1)">&#10094;</a>
    <a class="next" onclick="plusSlides(1)">&#10095;</a>

  


   
  </div>
</div>
         
     </div>
     
 
<div id="common">
    <h3>Our Instructors</h3>    
  

<?php $posts = $ids = get_field('our_team_listing', false, false);  ?>
   
 <ul class="inner-ul gym-locate">
      
     <?php
        
           $args= array(
            'post_type' => 'our_team', 
            'posts_per_page'   => -1,
            'orderby'          => 'post_date',
            'order'            => 'DESC',
            'post_status'      => 'publish',
              
            'tax_query' => array(
                
                array(
                   'taxonomy' => 'city',
                   'field' => 'term_id',
                   'terms' =>  $city[0]->term_id,
                   'include_children' => false 

                ),
                
            ),
           
            );
          
            $query=new WP_Query($args); $flag=array();
            if( $query->have_posts() ): while ( $query->have_posts() ) : $query->the_post();  
             $rcmeta=get_post_meta($post->ID, 'owner', true); 
             if($rcmeta=='yes') { continue; }
            $inscity = get_the_terms( $post->ID, 'city');  //var_dump($categories);
            $insscity= $inscity[0]->name;
             
            $specil = get_the_terms( $post->ID, 'level');  //var_dump($categories);
            $slevel= $specil[0]->name;
            
            if(!in_array($slevel,$flag)){ array_push($flag, $slevel); //var_dump($flag); ?> 
           
             <h4 class="sub-heading"><span><?php echo 'Level: '. $slevel; ?></span></h4>
            
            <?php } ?>
            
     <li><a href="<?php the_permalink();?>"><?php the_title();?></a></li>
    
   
     <?php
      
           endwhile; ?>
           <?php endif; 
    //}
        ?> 
        </ul>    
    
    




    </div>   
     
     
     

     
</div>





<?php get_footer('location'); ?>
