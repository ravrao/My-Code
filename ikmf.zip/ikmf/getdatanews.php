<?php
$POST_ID =  $_REQUEST['allmediasel'];
//echo $_SERVER['HTTPS'];
require_once ("../../../wp-config.php");

$catslug=get_cat_slug($POST_ID); ?>
 <?php $page_lang = $_REQUEST['lang'];?> 

<?php $category_link = get_category_link( $POST_ID ); ?>
<div class="row">

 <?php
    query_posts( array(
    'post_type' => 'post',
    'cat'       => $POST_ID,    
    'posts_per_page'   => 6,
    'orderby'          => 'post_date',
    'order'            => 'DESC',
    'post_status'      => 'publish',
    )); 

    if( have_posts() ): while ( have_posts() ) : the_post(); 
    $post_feat_image = wp_get_attachment_url( get_post_thumbnail_id($post->ID) );
    $title_t = get_the_title();
    $titshort = strip_tags($title_t);
    $getexcerpt = get_the_excerpt();
    $excerp = strip_tags($getexcerpt);


?>       
<div class="col-md-4 col-sm-6 col-xs-12">
    <div class="media-box">
        <a href="<?php the_permalink()?>"> 
            <div class="img-box">
                <?php echo get_the_post_thumbnail($post->ID,'photo_album',array('class' => 'img-responsive')); ?>
                <div class="event-overlay"></div>                
            </div></a>
        <a href="<?php the_permalink()?>"> <h4><?php echo mb_substr($titshort, 0, 22);?></h4></a>
        <a class="newstextalign" href="<?php the_permalink()?>"><?php echo mb_substr($excerp, 0, 100).' [...]';?></a>
    </div>
</div>
<?php endwhile; endif;?>

</div>

<div class="view-btn"><a class="btn" href="<?php echo $category_link;?>/#common">查看全部</a></div> 



