<?php
/**
 * The template for displaying all single posts and attachments
 *
 * @package WordPress
 * @subpackage Twenty_Sixteen
 * @since Twenty Sixteen 1.0
 */

get_header(); ?>

 <?php   $page_lang = ICL_LANGUAGE_CODE;?> 

 <div class="container inner-cont">

    <?php
    // Start the loop.
    while ( have_posts() ) : the_post(); ?>
    <div class="row">
        <div class="col-sm-12 col-xs-12">
            <div class="title ins-detail"><?php the_title();?></div>
        </div>
    </div>
    <?php		
        the_content();
    endwhile;
    ?>

     
     
<div class="gallery-section" >
    <?php
    $categories = get_the_category();
     $category_id = $categories[0]->cat_ID;
     if($category_id==34) {
?>
     <h3>Photo Album</h3>   <?php } ?> 
         <div class="owl-carousel owl-theme owlFour" id="lightgallery">
     <?php     
     if( class_exists('Dynamic_Featured_Image') ) {
     global $dynamic_featured_image;
     
     $featured_images = $dynamic_featured_image->get_featured_images( $rs ); 
     $i=1;
    foreach($featured_images as $value)
    { //echo 'value'; var_dump($value);
       
     ?>
             
             <div class="item" onclick="openModal();currentSlide(<?php echo $i ;?>)" class="hover-shadow cursor">
                 <h5><?php echo $description = $dynamic_featured_image->get_image_description($value['full']); ?></h5>
                 <img src="<?php echo $value['full']?>"/>
             
             </div>
<?php
$i++;
    //You can now loop through the image to display them as required
    } } 
       ?>     
            
            

          </div>
        <!-- modal -->
         <div id="myModal" class="modal lightbox-modal">
  <span class="close cursor" onclick="closeModal()">&times;</span>
  <div class="modal-content">
      <?php     
         if( class_exists('Dynamic_Featured_Image') ) {
     global $dynamic_featured_image;
     
     $featured_images = $dynamic_featured_image->get_featured_images( $rs ); 
    foreach($featured_images as $value)
    { //echo 'value'; var_dump($value);
       
     ?>
    <div class="mySlides">
      <div class="numbertext"> <p><?php echo $description = $dynamic_featured_image->get_image_description($value['full']); ?></div>
      <img src="<?php echo $value['full']?>" class="img-responsive"/>
    </div>  

    <?php
    //You can now loop through the image to display them as required
    } } 
       ?>     
    
    <a class="prev" onclick="plusSlides(-1)">&#10094;</a>
    <a class="next" onclick="plusSlides(1)">&#10095;</a>

  


   
  </div>
</div>
         
     </div>     

<?php $shotcode_video=get_post_meta($post->ID, 'enter_video_embed_code', true);
if($shotcode_video!=''){
?>

<?php if($page_lang=='en') {?>     
<h3>Video</h3>
<?php } else {?>
<h3>视频</h3> <?php } ?>
<!--<iframe src="http://player.youku.com/embed/XNzU3NzU0OTEy" width="640" height="420" frameborder="0" allowfullscreen="allowfullscreen"></iframe>-->
<!--<iframe src="<?php echo $shotcode_video;?>" width="640" height="420" frameborder="0" allowfullscreen="allowfullscreen"></iframe>-->
<iframe frameborder="0" width="100%" height="530" src="https://v.qq.com/txp/iframe/player.html?vid=<?php echo $shotcode_video;?>" allowFullScreen="true"></iframe>
<?php } ?>     
</div>

<?php get_footer('location'); ?>
