<?php /* Template Name: FrontPage Template */
get_header(); ?> 
<?php   $page_lang = ICL_LANGUAGE_CODE;?>
    
    <!-- BANNER SLIDER START -->  
            
        <section class="banner-slider">
            <div class="owl-carousel owl-theme owlOne"> 
                
            <?php
                query_posts( array(
                'post_type' => 'banner', 
                )); 
               
                if( have_posts() ): while ( have_posts() ) : the_post(); 
                $feat_image = wp_get_attachment_url( get_post_thumbnail_id($post->ID) );
                
                $contittle = get_the_title();
                $content_tit = strip_tags($contittle);
                
                $conticon = get_the_content();
                $content_con = strip_tags($conticon);

            ?>     
                
                <div class="item">
                    <a target="_blank" href="<?php echo get_post_meta($post->ID, 'banner_url', true); ?>"><img src="<?php echo $feat_image;?>" /></a>
                    <div class="caption">
                        <div class="container">
                           <a target="_blank" href="<?php echo get_post_meta($post->ID, 'banner_url', true); ?>"> <h1><?php echo $contittle;?></h1>
                               <p><?php echo $content_con;?></p></a>
                        <!--<a href="<?php echo get_post_meta($post->ID, 'banner_url', true); ?>" class="btn">Become an annual member</a>-->
                        </div>
                    </div>                         
                </div>
                
             <?php
               
               endwhile;
               endif; ?>    
                
              </div>
        </section> 
    <div class="clearfix"></div>     
    <!-- BANNER SLIDER END -->  
    
    <!-- ABOUT SECTION START -->
    
   
    <div class="container">
        <div class="row about-section">
             <?php $the_query = new WP_Query( 'page_id=579' ); ?>
            <?php while ($the_query -> have_posts()) : $the_query -> the_post();  
            $about_feat_image = wp_get_attachment_url( get_post_thumbnail_id($post->ID) ); 
            ?>
            <div class="col-sm-6 col-xs-12">
                <img src="<?php echo $about_feat_image;?>" class="img-responsive" />
            </div>
            <?php endwhile;?>
            <div class="col-sm-6 col-xs-12">
            <div class="about-box">
            <?php 
            $the_query = new WP_Query( 'page_id=588' ); ?>
            <?php while ($the_query -> have_posts()) : $the_query -> the_post();  ?>
           
                   <a href="<?php echo get_page_link($post->ID); ?>#common"><h2><?php echo get_post_meta($post->ID, 'home_title_ikmf', true); ?></h2></a>
                   <?php //the_field('home_ikmf_content'); 
                   if($page_lang=='en')
                   {
                       $smcontent_1 =  get_field('home_ikmf_content',$post->ID);
                   }
                   else
                   {
                      $smcontent_1 =  get_field('home_ikmf_content_chines',$post->ID); 
                   }
                   
                    $sme_content_1 = strip_tags($smcontent_1); ?>
                    <p> <?php //echo $sme_content_1;?><?php echo mb_substr($sme_content_1, 0, 260);?></p>
                  
            <?php endwhile;?>
            <?php //} ?>       
             <?php $the_query = new WP_Query( 'page_id=593' ); ?>
            <?php while ($the_query -> have_posts()) : $the_query -> the_post();  ?> 
                   
                    <a href="<?php echo get_page_link($post->ID); ?>#common"><h2><?php the_title();?></h2></a>
                    <?php 
                    $smcontent =  get_field('small_content_for_home_page');
                    $sme_content = strip_tags($smcontent); ?>
                    <p> <?php //echo $sme_content;?><?php //echo substr($sme_content, 0, 422); ?><?php echo mb_substr($sme_content, 0, 122);?></p>
                   
                    
            <?php endwhile;?>
            </div>
            </div>
        </div>
    </div>
     
    <!-- ABOUT SECTION END -->  
    
    <!-- OUR COURSES SECTION START -->
    <section class="courses-section">
        <div class="container">
            <div class="row">
                <div class="col-sm-12 col-xs-12">
                     <?php if($page_lang=='en') { ?>
                    <div class="title"><?php echo get_post_meta(10, 'our_courses_title', true); ?></div>
                     <?php } else { ?>
                     <div class="title"><?php echo get_post_meta(579, 'our_courses_title', true); ?></div>
                     <?php } ?>
                </div>
                <div class="col-sm-12 col-xs-12">
                    <a class="btn view-all" href="<?php echo get_page_link(17); ?>#common">
                        <?php if($page_lang=='en') { ?>
                        View All <?php } else { ?>查看全部 <?php } ?></a>
                    <div class="course-slider">
                        <div class="owl-carousel owl-theme owlTwo"> 
                            
                           
                    <?php
                   $type = 'our_course';
                      $args=array(
                      'post_type' => $type,
                      'post_status' => 'publish',
                      'paged' => $paged,
                      'posts_per_page' => -1,
                      
                      'orderby' => 'post_date',
                      'order' => 'DESC'    

                      );
                      $loop = new WP_Query( $args );
                      while ( $loop->have_posts() ) : $loop->the_post();
                        $testi_feat_image = wp_get_attachment_url( get_post_thumbnail_id($post->ID) ); 
                        $categories = get_the_terms( $post->ID, 'courses');
                        $content = get_the_title();
                        $contenttit = strip_tags($content);
                        
                        $getexcerpt = get_the_excerpt();
                        $excerp = strip_tags($getexcerpt);
                      
                        //echo $post->ID;
                         //echo 'developer'.get_field('small_image', $post->ID);
                    ?> 
                     <div class="item">
                                <a href="<?php the_permalink(); ?>">
                                <div class="img-box">
                                  
                                <img src="<?php echo get_field('small_image', $post->ID);?>" alt="" class="img-responsive">
                                <div class="event-overlay"></div>
                                </div>
                                    </a>
                                <div class="info">
                                    <a href="<?php the_permalink(); ?>"><div class="heading"><?php echo mb_substr($contenttit, 0, 10);?></div></a>
                                    
                                    <a href="<?php the_permalink(); ?>"> <?php echo mb_substr($excerp, 0, 50);?>[....]</a>
                                </div>                         
                            </div>
                           
                   <?php
      
                    endwhile; ?> 
                            </div>
                        
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- OUR COURSES SECTION END -->
    
    <!-- FIND CITY SECTION START -->
    
<?php if($page_lang=='en') {?>
  <section class="find-section">
        <div class="map-cont">
             <div id="map"></div>
            <!-- <iframe src="https://j.map.baidu.com/9F7iP" width="600" height="450" frameborder="0" style="border:0" allowfullscreen></iframe> -->

<script src="http://api.map.baidu.com/api?v=2.0&ak=DBa5badfc49c1ce0148b174ae3bdf0ea&callback=initMap"></script>

   
        </div>
        <div class="map-right">
            <h2>Find a gym in your city</h2>
            <div class="serach-location">
                <div class="serchFrm">
                    <div class="searInp">
                       <!-- <input type="text" name="" placeholder="Search location..." class="searhLocation">
                        <input type="submit">-->
                        
                        <select style="width:100%; height: 100%;" name="category" required id="provincserch" class="em-events-search-category searhLocation">
                         <option value="" selected="selected">Select To Province</option>
                        <?php   
                        $level=get_categories(array('taxonomy' => 'province', 'orderby'=> 'title', 'order' => 'ASC', 'hide_empty'=>1));
                        $sorted_cats = array();
                        foreach($level as $cat){
                        $ordr = get_field('order', 'province' . '_' . $cat->term_id); //var_dump($ordr);
                        $sorted_cats[$ordr] = $cat;
                      }
                        ksort($sorted_cats); //var_dump($sorted_cats);
                        foreach($sorted_cats as $lvalue)
                        {
                        ?> 
                         <option value="<?php echo $lvalue->term_id;?>"  <?php if($_REQUEST['category']== $lvalue->term_id ) { ?>selected="true"<?php } ?>><?php echo $lvalue->name;?></option>
                           <?php } ?>    
                    </select>
                    </div>
                    <ul class="autoPopulate" id="1stload">
                        
                       <?php
                        query_posts( array(
                        'post_type' => 'gymlocation',
                        'posts_per_page'  => '-1'  
                        )); 

                        if( have_posts() ): while ( have_posts() ) : the_post(); 
                        $feat_image = wp_get_attachment_url( get_post_thumbnail_id($post->ID) );

                    ?>     
                        <li style="cursor:pointer" data-field="<?php echo get_post_meta($post->ID, 'gim-location', true); ?>"> 
                            <?php if($feat_image!='') { ?>
                                <img src="<?php echo $feat_image;?>" alt="">
                            <?php } else {?>
                                <img src="<?php echo get_option('home'); ?>/wp-content/themes/ikmf/images/gym.jpg" alt=""/>
                            <?php } ?>    
                                <h3><?php the_title();?></h3>
                                <?php //the_content();?>
                                <input type="hidden" name="phoneno" id="phoneno" value="<?php echo get_post_meta($post->ID, 'phone', true); ?>"/>
                                <?php echo get_post_meta($post->ID, 'gim-location', true); ?>
                             <p>Phone No.: <?php echo get_post_meta($post->ID, 'phone', true); ?></p>
                        </li>
                        
                    <?php endwhile;            endif;?> 
                        
                        
                    </ul>
                    
                    <div id="resultgetgym"></div>
                </div>
            </div>
        </div>
    </section>
    <?php } else {?>
    
    <section class="find-section">
        <div class="map-cont">
             <div id="map"></div>
            <!-- <iframe src="https://j.map.baidu.com/9F7iP" width="600" height="450" frameborder="0" style="border:0" allowfullscreen></iframe> -->

<script src="http://api.map.baidu.com/api?v=2.0&ak=DBa5badfc49c1ce0148b174ae3bdf0ea&callback=initMap"></script>

   
        </div>
        <div class="map-right">
            <h2>查找你城市所在的场馆</h2>
            <div class="serach-location">
                <div class="serchFrm">
                    <div class="searInp">
                        <!--<input type="text" name="" placeholder="搜索场馆..." class="searhLocation">
                        <input type="submit">-->
                        <select style="border:#fda304 3px solid;width:100%; height: 100%;" name="category" required id="provincserch" class="em-events-search-category searhLocation">
                         <option value="" selected="selected">选择省份</option>
                        <?php   
                        $level=get_categories(array('taxonomy' => 'province', 'orderby'=> 'title', 'order' => 'ASC', 'hide_empty'=>1));
                        $sorted_cats = array();
                        foreach($level as $cat){
                        $ordr = get_field('order', 'province' . '_' . $cat->term_id); //var_dump($ordr);
                        $sorted_cats[$ordr] = $cat;
                      }
                        ksort($sorted_cats); //var_dump($sorted_cats);
                        foreach($sorted_cats as $lvalue)
                        {
                        ?> 
                         <option value="<?php echo $lvalue->term_id;?>"  <?php if($_REQUEST['category']== $lvalue->term_id ) { ?>selected="true"<?php } ?>><?php echo $lvalue->name;?></option>
                           <?php } ?>    
                    </select>
                    </div>
                    <ul class="autoPopulate" id="1stload">
                     <?php
                        query_posts( array(
                        'post_type' => 'gymlocation',
                        'posts_per_page'  => '-1'  
                        )); 

                        if( have_posts() ): while ( have_posts() ) : the_post(); 
                        $feat_image = wp_get_attachment_url( get_post_thumbnail_id($post->ID) );

                    ?>     
    <li style="cursor:pointer" data-field="<?php echo get_post_meta($post->ID, 'gim-location', true); ?>"> 
                           
            <?php if($feat_image!='') { ?>
                <img src="<?php echo $feat_image;?>" alt="">
            <?php } else {?>
                <img src="<?php bloginfo('url')?>/wp-content/themes/ikmf/images/gym.jpg" alt=""/>
            <?php } ?> 
            <h3><?php the_title();?></h3>
            <input type="hidden" name="phoneno" id="phoneno" value="<?php echo get_post_meta($post->ID, 'phone', true); ?>"/>
            <?php //the_content();?>
            <?php echo get_post_meta($post->ID, 'gim-location', true); ?>
            <p>电话: <?php echo get_post_meta($post->ID, 'phone', true); ?></p>

    </li>

<?php endwhile;            endif;?>    
</ul><div id="resultgetgym"></div>
                </div>
            </div>
        </div>
    </section>
    <?php } ?>    
    <!-- FIND CITY SECTION END -->
    
    <!-- EVENTS SECTION START -->
    <section class="events-section">
        <div class="container">
            <div class="row">
                <div class="col-sm-12 col-xs-12">
                     <?php if($page_lang=='en') { ?>
                    <div class="title">events</div>
                     <?php } else {?>
                    <div class="title">活动</div>
                     <?php } ?>
                </div>
                <div class="col-sm-12 col-xs-12">
                     <?php if($page_lang=='en') { ?>
                    <a class="btn view-all" href="<?php echo get_page_link(5); ?>/#common">View All</a>
                     <?php } else {?>
                     <a class="btn view-all" href="<?php echo get_page_link(5); ?>/#common">查看全部</a>
                     <?php } ?>
                     <?php //dynamic_sidebar('sidebar-4');?>
                    <div class="event-slider">
                         
                        <?php //echo do_shortcode('[events_list scope="future" limit=5 pagination=1]'); ?>
                        
                        <div class="owl-carousel owl-theme owlThree"> 
                            
<?php
if($page_lang=='en') { 
//echo do_shortcode('[events_list scope="future"]<div class="item"><a href="#_EVENTURL"><div class="img-box">#_EVENTIMAGE<div class="event-overlay"></div></a></div><div class="info evn-dtls"><div class="date-info"><span>#d</span>#F</div><a href="#_EVENTURL"><div class="heading">#_EVENTNAME</div></a><ul><li class="eve-dt"><span><i class="fa fa-calendar"></i></span>#_EVENTDATES </li><li class="ev-adr"><span><i class="fa fa-map-marker"></i></span#_LOCATIONNAME</li></ul></div><div class="info evn-desc"><a class="mmyevent" href="#_EVENTURL">#_EVENTEXCERPTCUT</a></div><a class="btn" href="#_EVENTURL">Register</a></div>[/events_list]'); 
  echo do_shortcode('[events_list scope="future"]<div class="item"><a href="#_EVENTURL"><div class="img-box">#_EVENTIMAGE<div class="event-overlay"></div></a></div><div class="info evn-dtls"><div class="date-info"><span>#d</span>#F</div><a href="#_EVENTURL"><div class="heading">#_EVENTNAME</div></a><ul><li class="eve-dt"><span><i class="fa fa-calendar"></i></span>#_EVENTDATES </li><li class="ev-adr"><span><i class="fa fa-map-marker"></i></span>#_LOCATIONTOWN</li></ul></div><div class="info evn-desc"><a class="mmyevent" href="#_EVENTURL">#_EVENTEXCERPTCUT</a></div><a class="btn" href="#_EVENTURL">Register</a></div>[/events_list]'); 
    
}else{
    $rs="my developer";
echo do_shortcode('[events_list scope="future"]<div class="item"><a href="#_EVENTURL"><div class="img-box">#_EVENTIMAGE<div class="event-overlay"></div></a></div><div class="info evn-dtls"><div class="date-info"><span>#d</span>#F</div><a href="#_EVENTURL"><div class="heading">#_EVENTNAME</div></a><ul><li class="eve-dt"><span><i class="fa fa-calendar"></i></span>#_EVENTDATES </li><li class="ev-adr"><span><i class="fa fa-map-marker"></i></span>#_LOCATIONTOWN</li></ul></div><div class="info evn-desc"><a class="mmyevent" href="#_EVENTURL">#_EVENTEXCERPTCUT</a></div><a class="btn" href="#_EVENTURL">报名</a></div>[/events_list]'); 
}
?>                                   
                            
                
                            </div>
                      
                    </div>
                </div>
            </div>
        </div>
    </section>
    <div class="clearfix"></div>
    <!-- EVENTS SECTION END -->
    
    <!-- VIDEO SECTION START -->
    <div class="container">
        <div class="row video-section">
            <div class="col-md-6 col-sm-12 col-xs-12">
                <div class="video-cont">
                    <?php //echo get_post_meta(10, 'video_url', true); ?>
           <iframe frameborder="0" width="100%" height="530" src="https://v.qq.com/txp/iframe/player.html?vid=<?php echo get_post_meta(10, 'video_url', true); ?>" allowFullScreen="true"></iframe>
                    <!--<div class="overlay">
                        <span><img src="<?php echo get_template_directory_uri(); ?>/images/video-icon.png" /></span>
                    </div>-->
                </div>
            </div>
            <div class="col-md-6 col-sm-12 col-xs-12">
                <div class="recentArticles">
                    <div class="news-cont">
                        <div class="news-heading">
                            <?php if($page_lang=='en') { ?>
                            <div class="title"><?php echo get_post_meta(10, 'lates_news_title', true); ?></div>
                            <a class="btn" href="<?php bloginfo('url')?>/category/news/#common">view all</a>
                            <?php } else { $my_home_url = apply_filters( 'wpml_home_url', get_option( 'home' ) );?>
                            <div class="title"><?php echo get_post_meta(579, 'lates_news_title', true); ?></div>
                            <a class="btn" href="<?php echo get_option('home'); ?>/category/新闻/?lang=zh-hans">查看全部</a>
                            <?php } ?>
                        </div>
                    
                
                <section class="vertical slider">
                 
                 <?php
                 if($page_lang=='en') 
                 { 
                    query_posts( array(
                    'post_type' => 'post',
                     'cat'       => 4,     
                    'posts_per_page'   =>8,
                    'orderby'          => 'post_date',
                    'order'            => 'DESC',
                    'post_status'      => 'publish',
                    ));
                 }
                 else
                 {
                   query_posts( array(
                    'post_type' => 'post',
                     'cat'       => 73,     
                    'posts_per_page'   =>8,
                    'orderby'          => 'post_date',
                    'order'            => 'DESC',
                    'post_status'      => 'publish',
                    ));  
                 }
               
                if( have_posts() ): while ( have_posts() ) : the_post(); 
                $post_feat_image = wp_get_attachment_url( get_post_thumbnail_id($post->ID) );
                $title_t = get_the_title();
                $titshort = strip_tags($title_t);
                $getexcerpt = get_the_excerpt();
                $excerp = strip_tags($getexcerpt);

                ?>     
                   <div class="news-box">
                            <div class="news-img">                            
                                <a href="<?php the_permalink()?>"> <?php echo get_the_post_thumbnail($post->ID,'home-news',array('class' => 'img-responsive')); ?></a>
                            </div>
                            <a href="<?php the_permalink()?>"><h4><?php echo mb_substr($titshort, 0, 18);?></h4></a>
                            <a href="<?php the_permalink()?>"> <?php echo mb_substr($excerp, 0, 60).'[...]';?></a>
                            <div class="info-desc">
                                <div class="date"><?php the_modified_date('Y-m-d'); ?></div>
                                <a class="reply" href="<?php the_permalink()?>"><span></span> <?php if($page_lang=='en'){?> Read more<?php } else {?>查看详情<?php } ?></a>
                            </div>
                        </div> 
                <?php endwhile;    endif;?>  
                </section>


                </div>  
                
                </div>
            </div>
        </div>
       
    </div>  
    <!-- VIDEO SECTION END-->
     <div class="clearfix"></div>
     
   <style>
      /* Always set the map height explicitly to define the size of the div
       * element that contains the map. */
      #map {
        height: 710px;
        width:100%;
      }
      /* Optional: Makes the sample page fill the window. */
      html, body {
        height: 100%;
        margin: 0;
        padding: 0;
      }


     
    </style>  



    
<?php get_footer(); ?>
