<?php
/**
 * The template for displaying all single posts and attachments
 *
 * @package WordPress
 * @subpackage Twenty_Sixteen
 * @since Twenty Sixteen 1.0
 */

get_header(); ?>

<?php

  $terms = get_the_terms( get_the_ID(), 'courses' );

   $catname = $terms[0]->name;
?>
 <div class="container inner-cont">

		<?php
		// Start the loop.
		while ( have_posts() ) : the_post(); ?>
    <div class="row">
        <div class="col-sm-12 col-xs-12">
            <div class="title ins-detail"><?php the_title();?></div>
        </div>
    </div>
     <div class="catname"><h3>Courses Name: <?php echo $catname;?></h3></div>
<?php		
        the_content();

    endwhile;
    ?>

 
     
<div id="common">
    <?php   $page_lang = ICL_LANGUAGE_CODE;?>
   <?php if($page_lang=='en') { ?>
    <h3>Our Team</h3>
   <?php } else {?>
    <h3>执教教官</h3>
   <?php } ?>    
  

<?php $posts = $ids = get_field('our_team_listing', false, false);  ?>
    
 <ul class="inner-ul">
      <?php
            query_posts( array(
           'post_type' => 'our_team', 
           'posts_per_page' => -1,
           'post__in'   => $posts,
           ));
          
           if( have_posts() ): while ( have_posts() ) : the_post(); 
            $testi_feat_image = wp_get_attachment_url( get_post_thumbnail_id($post->ID) ); 
            $categories = get_the_terms( $post->ID, 'courses');
             
        ?>      
     
     
     <?php //$posts = $ids = get_field('our_team_listing', false, false);  ?>
    
     <li><a href="<?php the_permalink();?>"><?php the_title();?></a></li>
   
     <?php
      
           endwhile; ?>
           <?php endif; 
        ?> 
        </ul>     
    
    




    </div>     
     
</div>





<?php get_footer(); ?>
