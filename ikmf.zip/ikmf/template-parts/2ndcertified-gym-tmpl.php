<?php /* Template Name: 2ndCertified Template */
get_header(); ?> 

<script src="<?php echo get_template_directory_uri(); ?>/js/jquery.min.js"></script>

<div id="common" class="container inner-cont">
     
  <div class="row">
        <div class="col-sm-12 col-xs-12">
            <div class="title ins-detail"><?php the_title();?></div>
        </div>
    </div>

    
    
 
<section class="find-section">
 <div class="ins-top-sec">   
<form name="frm1" method="post" action="<?php echo $_SERVER['REQUEST_URI']; ?>#common" id="frm1">
    <div class="level-search">	  			
            <label>		
                    <select name="category" required id="category" class="em-events-search-category">
                         <option value="" selected="selected">Select Province</option>
                        <?php   
                        $level=get_categories(array('taxonomy' => 'province', 'orderby' => 'ID', 'order' => 'ASC','hide_empty'=>0));
                        foreach($level as $lvalue)
                        {
                        ?> 
                         <option value="<?php echo $lvalue->term_id;?>"  <?php if($_REQUEST['category']== $lvalue->term_id ) { ?>selected="true"<?php } ?>><?php echo $lvalue->name;?></option>
                           <?php } ?>    
                    </select>
            </label>
        <input type="submit" name="submit" value="Search" class="ins-submit btn">
        <div class="viewmore"><a href="<?php echo get_page_link(1075); ?>" class="ins-submit btn">View All Gym</a></div>
    </div>
</form>
     
 </div>

        
    </section>


<?php
if (isset($_POST['submit'])) { ?> 
<div class="contact_map">
        <div style="width:100%;height:700px;border:#ccc solid 1px;float:left;" id="dituContent1"></div>
 
</div>

<script type="text/javascript" src="http://api.map.baidu.com/api?v=2.0&ak=DBa5badfc49c1ce0148b174ae3bdf0ea"></script>


<?php
$provname= $_REQUEST['category']; 

$args= array(
'post_type' => 'gymlocation', 
'posts_per_page'   => -1,
'orderby'          => 'post_date',
'order'            => 'DESC',
'post_status'      => 'publish',
'tax_query' => array(
                         array(
                            'taxonomy' => 'province',
                            'field' => 'term_id',
                            'terms' =>  $provname,
                            'include_children' => false 

                         )
                     )
);



$query=new WP_Query($args); 
if( $query->have_posts() ): while ( $query->have_posts() ) : $query->the_post(); 
?> 
<?php $addresspr[]=get_post_meta($post->ID, 'gim-location', true); 
$featimage[]= wp_get_attachment_url( get_post_thumbnail_id($post->ID) );
$title[]= get_the_title() ;
?>        
<?php endwhile; endif;?>

<?php
//foreach($addresspr as $key => $value){
//	echo '<br/>'.$value;
//}
?>

<!--<script type="text/javascript">
$(document).ready(function(){
  var map = new BMap.Map("dituContent1");
  <?php foreach($addresspr as $key => $value){ ?>
  var locaddress="<?php echo $addresspr[$key]; ?>";
  var featimg="<?php echo $featimage[$key]; ?>";
  var titleg="<?php echo $title[$key]; ?>"
  createMapMarker(locaddress, map, featimg, titleg);
  <?php } ?>
});

function createMapMarker(address, map, fimage, titgym){
  var geocoder = new BMap.Geocoder();
  geocoder.getPoint(address, function(res){ console.log(res); //console.log(res.lat);
    //alert(address);
    var lng=res.lng; var lat=res.lat; //alert(res.lng +','+ res.lat);
    var point = new BMap.Point(lng,lat);
    var sContent = "<h4 style='margin:0 0 5px 0;padding:0.2em 0'></h4>" +
                "<p style='margin:0;line-height:1.5;font-size:13px;text-indent:2em; font-weight:bold;'>"+titgym+"</p>" +
                '<p style="margin:0;line-height:1.5;font-size:13px;text-indent:2em"><img width="139" height="104" id="imgDemo" src="'+fimage+'" /></p>' +
		"<p style='margin:0;line-height:1.5;font-size:13px;text-indent:2em'>"+address+"</p></div>";
    var icon = new BMap.Icon('<?php bloginfo('url')?>/wp-content/themes/ikmf/images/map-marker.png', new BMap.Size(50, 62), {
		anchor: new BMap.Size(10, 30),
		infoWindowAnchor: new BMap.Size(10, 0)
    });
    var marker = new BMap.Marker(point, { icon: icon, title: address }); 
    //alert(sContent);									
    
    //var marker = new BMap.Marker(point);
    var infoWindow = new BMap.InfoWindow(sContent);
    map.addControl(new BMap.NavigationControl());
    map.centerAndZoom(point, 11);
    map.enableScrollWheelZoom(); 
    map.addOverlay(marker);
    
    marker.addEventListener("click", function(){
	this.openInfoWindow(infoWindow);
	document.getElementById('imgDemo').onload = function (){ infoWindow.redraw(); }
    });
    
  });
}
</script>-->

<script type="text/javascript">
	// 百度地图API功能
	var map = new BMap.Map("allmap");
	var point = new BMap.Point(116.404, 39.915);
	map.centerAndZoom(point, 15);
	// 编写自定义函数,创建标注
	function addMarker(point){
	  var marker = new BMap.Marker(point);
	  map.addOverlay(marker);
	}
	// 随机向地图添加25个标注
	var bounds = map.getBounds();
	var sw = bounds.getSouthWest();
	var ne = bounds.getNorthEast();
	var lngSpan = Math.abs(sw.lng - ne.lng);
	var latSpan = Math.abs(ne.lat - sw.lat);
	for (var i = 0; i < 25; i ++) {
		var point = new BMap.Point(sw.lng + lngSpan * (Math.random() * 0.7), ne.lat - latSpan * (Math.random() * 0.7));
		addMarker(point);
	}
</script>

<?php
}
else {
?> 

<div class="clearfix"></div>
<section class="find-section">
    <div class="location-cont" style="background-image: url(<?php echo get_field('map_image', 293);?>">   
            <div class="loc-box boxOne">
                <a href="#" title=""><span><i class="fa fa-map-marker"></i></span>Beijing</a>
            </div>
            <div class="loc-box boxTwo">
                <a href="#" title=""><span><i class="fa fa-map-marker"></i></span>Guangzhou</a>
            </div>
            <div class="loc-box boxThree">
                <a href="#" title=""><span><i class="fa fa-map-marker"></i></span>Shanghai</a>
            </div>
        </div>

        
</section>

<script>
$('.loc-box a').click(function(){  
 var selText = $(this).text(); //alert(selText);
 $('#category option').each(function(){ $(this).removeAttr('selected'); });
 $('#category option').each(function(){ 
  var optText = $(this).text(); //alert(optText);
  if( selText == optText ){ //alert('match');
    $(this).attr('selected', 'selected');	
  }
 });
 $('.ins-submit').trigger('click');
});
</script>
<?php } ?>

</div>
<?php get_footer(); ?>
