<?php /* Template Name: Register Template */
get_header();
?> 

<div id="common" class="container inner-cont">

    <div class="row">
        <div class="col-sm-12 col-xs-12">
            <div class="title ins-detail"><?php the_title(); ?></div>
        </div>
    </div>


<section class="find-section">

<div class="container">
<!-- Gallery Side Panel -->
            <?php $msg=$_GET['msg'];
                    if($msg) {	
            ?>
            <div class="alert alert-danger">
                     <?php echo $msg; ?>
            </div>
            <?php } ?>
<div class="row">
<?php if($_GET['mes']=='instruct') {?>    
<p class="alert" id="wppb_form_success_message">Before you can access your account, you need to confirm your email address. Please check your inbox and click the activation link.</p>
<?php }
else if($_GET['activation_key']!='')
{ 

$user_info = get_userdata($_GET['activation_key']);
$useremail = $user_info->user_email;
$userlogin = $user_info->user_login;
?>
  <p class="wppb-success">Your email was successfully confirmed.</p>  
<?php 
$updatestatus=1;
update_user_meta($_GET['activation_key'],'wp-approve-user',$updatestatus);
 $to  = $useremail;
$subject = 'Your new account information';

$message = '<!DOCTYPE HTML>
<html>

<head>
   <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
   <title>Your new account information</title>
</head>

<style>
   @import url("https://fonts.googleapis.com/css?family=Roboto:400,500,700");
</style>

<body style="padding: 0;margin: 0;">

   <div style="width: 800px; margin: 0 auto; border-top: 2px solid #aa0008; border-bottom:2px solid #aa0008; border-left: 1px solid #eaeaea; border-right: 1px solid #eaeaea; overflow: hidden;">

       <div style="margin: 0 auto; text-align: center; width: 100%; padding: 30px 0;">
           <img src="http://lab-1.sketchdemos.com/P1091_IKMF_New/wp-content/themes/ikmf/images/logo.png" alt="">
       </div>

       <div style="background: #aa0008; color: #fff; text-align: center; padding: 28px; font-size: 26px; text-transform: uppercase;">
           New User Registration 
       </div>

       <div style="background: url(http://lab-1.sketchdemos.com/P1091_IKMF_New/wp-content/themes/ikmf/images/grilled.png) repeat; float: left; width: 100%; padding: 30px 0; font-size: 18px; line-height: 32px; color: #605e5e; padding: 20px;">
           <p>
             Welcome to IKMF China!</p>
             
                <p>Your username is: '.$userlogin.' and password: Your selected password at signup</p>   
                
           </div>


   </div>

</body>


</html>';


// Always set content-type when sending HTML email
$headers = "MIME-Version: 1.0" . "\r\n";
$headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";
$headers .= 'From: <ikmf@lab-1.sketchdemos.com>';
@mail($to, $subject, $message, $headers);


}
else { ?>    
<form action="#" method="post" id="material_form" class="wppb-user-forms wppb-register-user wppb-user-logged-out material_form">
    <ul>
        <!--<li class="wppb-form-field wppb-default-name-heading" id="wppb-form-element-1">
            <h4>Name</h4><span class="wppb-description-delimiter"></span>
        </li>-->
        <li class="wppb-form-field wppb-default-username">
            <label for="username">Username<span class="wppb-required" title="This field is required">*</span></label>
            <input class="text-input default_field_username" name="username"  id="username" value="" required="" type="text">
            <span class="wppb-description-delimiter">Usernames cannot be changed.</span>
        </li>
        
        <li class="wppb-form-field wppb-default-first-name" >
            <label for="first_name">First Name<span class="wppb-required" title="This field is required">*</span></label>
            <input class="text-input default_field_firstname" name="first_name"  id="first_name" value="" type="text">
        </li>
        
        <li class="wppb-form-field wppb-default-last-name" >
            <label for="last_name">Last Name</label>
            <input class="text-input default_field_lastname" name="last_name"  id="last_name" value="" type="text">
        </li>
        
         <li class="wppb-form-field wppb-default-e-mail">
            <label for="email">E-mail<span class="wppb-required" title="This field is required">*</span></label>
            <input class="text-input default_field_email" name="confemail" id="confemail" value="" required="" type="email">
        </li>
        
         <li class="wppb-form-field wppb-default-password" id="wppb-form-element-15">
            <label for="passw1">Password<span class="wppb-required" title="This field is required">*</span></label>
            <input class="text-input" name="passw1"  id="passw1" value="" autocomplete="off" required="" type="password">
            <span class="wppb-description-delimiter">Type your password. </span>
        </li>
        
        <li class="wppb-form-field wppb-default-repeat-password" >
            <label for="passw2">Repeat Password<span class="wppb-required" title="This field is required">*</span></label>
            <input class="text-input" name="passw2"  id="passw2" value="" autocomplete="off" required="" type="password">
            <span class="wppb-description-delimiter">Type your password again. </span>
        </li>
       
        <li class="wppb-form-field wppb-input">
            <label for="phone_number">Phone Number<span class="wppb-required" title="This field is required">*</span></label>
            <input class="extra_field_input " name="phone_number"  id="phone_number" value="" required="" type="text">
        </li>
        
        <li class="wppb-form-field wppb-input" >
            <label for="city">City<span class="wppb-required" title="This field is required">*</span></label>
            <!--<input class="extra_field_input " name="city"  id="city" value="" required="" type="text">-->
            <select name="city" id="city">
                <option value="">Please Choose</option>
                 <?php   
                    $level=get_categories(array('taxonomy' => 'city', 'orderby'=> 'title', 'order' => 'ASC', 'hide_empty'=>0));
                    
                    foreach($level as $lvalue)
                    {
                  
                ?> 
                <option value="<?php echo $lvalue->name;?>"><?php echo $lvalue->name;?></option>
                <?php } ?>
            </select>
        </li>
        
         <li class="wppb-form-field wppb-input" >
            <label for="province">Province<span class="wppb-required" title="This field is required">*</span></label>
            <!--<input class="extra_field_input " name="province"  id="province" value="" required="" type="text">-->
            <select name="province" id="province">
                <option value="">Please Choose</option>
                 <?php   
                    $level=get_categories(array('taxonomy' => 'province', 'orderby'=> 'title', 'order' => 'ASC', 'hide_empty'=>0));
                    
                    foreach($level as $lvalue)
                    {
                  
                ?> 
                <option value="<?php echo $lvalue->term_id;?> <?php echo the_field('province_code', 'province' . '_' . $lvalue->term_id);?>"><?php echo $lvalue->name;?></option>
                <?php } ?>
            </select>
        </li>
       
        <li class="wppb-form-field wppb-select-cpt">
        <label for="gymchoose_location">Gym Location</label>
        <select name="gymchoose_location" id="gymchoose_location" class="custom_field_cpt_select ">
            <option value="">Please Choose</option>
            <?php
                query_posts( array(
                'post_type' => 'gymlocation',
                'posts_per_page'  => '-1'  
                )); 

                if( have_posts() ): while ( have_posts() ) : the_post(); 
               
            ?>     
             <option value="<?php echo $post->ID; ?>"><?php the_title();?></option>
           <?php endwhile; 
           endif;?>
        </select>
        </li>
       
        
        
        <li class="wppb-form-field wppb-select-cpt" >
        <label for="gymchoose_position">Position</label>
        <input class="extra_field_input " name="position"  id="position" value="" type="text">
        </li>
        
        <li class="wppb-form-field wppb-select" id="wppb-form-element-19">
            <label for="select_type_user">Type</label>
            <select name="select_type_user" id="select_type_user" class="custom_field_select">
                <option value="choose an option" class="custom_field_select_option " selected="">Choose an option</option>
                <option value="student" class="custom_field_select_option ">Student</option>
                <option value="instructor" class="custom_field_select_option ">Instructor</option>
            </select>
        </li>
        
        <li class="wppb-form-field wppb-select-cpt" id="label_select" style="display:none;">
        <label for="gymchoose_level">Level</label>
        <select name="gymchoose_level" id="gymchoose_level" class="custom_field_cpt_select">
            <option value="">...Choose</option>
            <?php   
            $level=get_categories(array('taxonomy' => 'level', 'orderby' => 'ID', 'order' => 'ASC','hide_empty'=>0));
            foreach($level as $lvalue)
            { ?>
                
              <option value="<?php echo $lvalue->term_id; ?>"><?php echo $lvalue->name; ?></option>  
            <?php }
            ?>
        </select>
        </li>
        
        
        
    </ul>
    			
    <p class="form-submit">
        <?php wp_nonce_field( 'create_new_user_registration', 'admin5678qsdfrs' ); ?>
        <input name="register" id="register" class="submit button" value="Register" type="submit">
        
    </p><!-- .form-submit -->

</form>
<?php } ?>
</div>
</div>

</section>



</div>

<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-validate/1.16.0/jquery.validate.min.js"></script>
<script type="text/javascript">

    jQuery(document).ready(function($) {


     $(".material_form").validate({
        rules: {
            
            'username': {
                required: true
               
            },
            'first_name': {
            	required: true
            },
            'confemail': {
    			required: true,
    			email: true
    		},
            'passw1': {
		     required: true,
		   
		},
            'passw2': {
      		equalTo: "#passw1"
    		},
            'phone_number': {
		     required: true,
                     number: true
		   
		},
            'city': {
		     required: true,
		   
		},
            'province': {
		     required: true,
		   
		},    
                

           
        },
        messages: {
            
            'username': "Username cannot be blank",
            'first_name': {
                required: "First Name cannot be blank"
                
            },
            'confemail': {
    			required: 'Email id cannot be blank',
    			email: 'Please enter a valid email'
    		},
            'passw1': {

            	required: "Password field cannot be blank"
            	
            },

            'phone_number': {

            	required: "Phone Number field cannot be blank",
            	number: "Please enter numeric value"
            	
            },
           
           'city' :  {

            	required: "City field cannot be blank"
            	
            },

            'province': {

           	required: 'Province field cannot be blank'

           }

           
        }
    });
    
    $("#select_type_user").change(function () {
        
        if ($(this).val() == "instructor") {
            $("#label_select").show();
        } else {
            $("#label_select").hide();
        }
    });
    
});





</script>
<style type="text/css">  
.error {
    border: 1px dotted red;
    margin-left: 30%;
    margin-top: 5px;
    color: red !important;
    font-size: 12px !important;
}    
</style>
<?php get_footer(); ?>
