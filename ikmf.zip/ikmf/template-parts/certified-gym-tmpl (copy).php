<?php /* Template Name: Certified-gym Template */
get_header(); ?> 
    
    <div id="common" class="container inner-cont">
     
  <div class="row">
        <div class="col-sm-12 col-xs-12">
            <div class="title ins-detail"><?php the_title();?></div>
        </div>
    </div>

 
<section class="find-section">
 <div class="ins-top-sec">   
<form name="frm1" method="post" action=""  id="frm1">
    <div class="level-search">	  			
            <label>		
                    <select name="category"  required id="category" class="em-events-search-category">
                         <option value="" selected="selected">Select Province</option>
                        <?php   
                        $level=get_categories(array('taxonomy' => 'province', 'orderby' => 'ID', 'order' => 'ASC','hide_empty'=>0));
                        foreach($level as $lvalue)
                           {
                        ?> 
                         <option value="<?php echo $lvalue->term_id;?>"  <?php if($_REQUEST['category']== $lvalue->term_id ) { ?>selected="true"<?php } ?>><?php echo $lvalue->name;?></option>
                           <?php } ?>    
                    </select>
            </label>
        <input type="submit" name="submit" value="Search" class="ins-submit btn">
    </div>
</form> 
 </div>

        
    </section>

    

    </div>


<div class="contact_map">
        <div style="width:100%;height:600px;border:#ccc solid 1px;float:left;" id="dituContent1"></div>
 
</div>

<script type="text/javascript" src="http://api.map.baidu.com/api?v=2.0&ak=DBa5badfc49c1ce0148b174ae3bdf0ea"></script>
<script src="<?php echo get_template_directory_uri(); ?>/js/jquery.min.js"></script>

<?php
$args= array(
'post_type' => 'gymlocation', 
'posts_per_page'   => -1,
'orderby'          => 'post_date',
'order'            => 'DESC',
'post_status'      => 'publish',
);
$query=new WP_Query($args); 
if( $query->have_posts() ): while ( $query->have_posts() ) : $query->the_post(); 
?> 
<?php $addresspr[]=get_post_meta($post->ID, 'gim-location', true); ?>
<?php endwhile; endif;?>

<?php
foreach($addresspr as $key => $value){
	echo '<br/>'.$value;
}
?>

<script type="text/javascript">
$(document).ready(function(){
        var map = new BMap.Map("dituContent1");
	geocoder = new BMap.Geocoder();
        <?php
        foreach($addresspr as $key => $value){
        ?>
	var address="<?php echo $addresspr[$key]; ?>";
	geocoder.getPoint(address, function(res){ console.log(res); //console.log(res.lat);
             alert(address);
		var lng=res.lng; 
		var lat=res.lat; //alert(res.lng +','+ res.lat);
		var point = new BMap.Point(lng,lat);
                
		var sContent =
			"<h4 style='margin:0 0 5px 0;padding:0.2em 0'></h4>" +
			"<p style='margin:0;line-height:1.5;font-size:13px;text-indent:2em'>"+address+"</p></div>";
		var icon = new BMap.Icon('http://www.swisschamofcommerce.com/wp-content/uploads/2017/02/map-marker.png', new BMap.Size(30, 42), {
				anchor: new BMap.Size(10, 30),
				infoWindowAnchor: new BMap.Size(10, 0)
		});
		var marker = new BMap.Marker(point, {
				icon: icon,
				title: address
		}); 
		alert(sContent);									
		//var marker = new BMap.Marker(point);
		var infoWindow = new BMap.InfoWindow(sContent);
                 map.addControl(new BMap.NavigationControl());
		map.centerAndZoom(point, 19);
                map.enableScrollWheelZoom(); 
		map.addOverlay(marker);
		marker.addEventListener("click", function(){
		this.openInfoWindow(infoWindow);
		document.getElementById('imgDemo').onload = function (){
		infoWindow.redraw();
		}
		});
	}); 
        <?php } ?>

  });
</script>

   
<?php get_footer(); ?>
