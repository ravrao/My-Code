<?php
/**
 * The template for displaying all single posts and attachments
 *
 * @package WordPress
 * @subpackage Twenty_Sixteen
 * @since Twenty Sixteen 1.0
 */

get_header(); ?>
<?php   $page_lang = ICL_LANGUAGE_CODE;?>
<?php
if($email!='')
{
$udetails=get_user_by_email($email);
$uname=$udetails->user_login;
$pass=$udetails->user_pass;
//$wp_hasher = new PasswordHash(8, true);
echo 'test'.$password = wp_hash_password($pass);

    $creds = array(); 
    $creds['user_login'] = $uname; 
    $creds['user_password'] = $pass; 
    $creds['remember'] = true; 
    $user = wp_signon( $creds, false ); 
    if ( is_wp_error($user) )
    {
     echo $user->get_error_message();
    }
}
?>
 <div class="container inner-cont">
     
    <div class="title ins-detail"><?php the_title();?></div>   
    <div class="event-detail-div">
        <div class="event-box" data-equalizer-watch="event_box_align">
            <ul class="fa-ul no-bullet event_list_details">
                <li>
                    <p><span class="event_list_icon"><i class="fa fa-calendar" aria-hidden="true"></i></span> 
                        <span class="event_list_name">TIME</span>
                        <?php echo do_shortcode('[event]#_EVENTDATES <br/><strong> #_EVENTTIMES</strong>[/event]'); ?>
                          
                    </p>
                </li>
                <li>
                    <p><span class="event_list_icon"><i class="fa fa-building" aria-hidden="true"></i></span><span class="event_list_name">Venue</span>
                        <?php echo do_shortcode('[event]#_LOCATIONNAME[/event]'); ?>
                    </p>
                </li>
                <li>
                    <p><span class="event_list_icon"><i class="fa fa-map-marker" aria-hidden="true"></i></span> <span class="event_list_name">ADDRESS</span>
                        <?php echo do_shortcode('[event]#_LOCATIONADDRESS, #_LOCATIONTOWN, #_LOCATIONCOUNTRY[/event]'); ?>
                    </p>
                </li>
                <li>
                    <p><span class="event_list_icon"><i class="fa fa-money" aria-hidden="true"></i></span> <span class="event_list_name">Member Price:</span>
                       <?php $minprice= do_shortcode('[event]#_EVENTPRICEMIN[/event]'); 
                            $minexploded=explode(".",$minprice); echo $minexploded[0];
                       ?> | Non Members Price: <?php $maxprice= do_shortcode('[event]#_EVENTPRICEMAX[/event]');
                            $maxexploded=explode(".",$maxprice); echo $maxexploded[0];
                                                 ?>
                    </p>
                </li>
               

            </ul>
            <?php 
            $ctadte     =   date('d F Y');
            $crdate     =   strtotime($ctadte); 
            $eventdate  =   do_shortcode('[event]#d #F #Y[/event]');
            $stredate   =   strtotime($eventdate); 
            ?>
            
            <div class="event-detail-btn">
            <?php if($crdate<=$stredate){ 
                if($_REQUEST['exi']=='exiuser') { ?>
                <a href="#" data-toggle="modal" data-target="#bookingModal" class="btn">Confirm Booking</a>
            <?php }
               if($_REQUEST['exi']!='exiuser') { ?>
                 <a href="#" data-toggle="modal" data-target="#bookingModal" class="btn poupopen"><?php if($page_lang=='en') { ?>Book Now<?php } else { ?>立即报名<?php } ?></a>
               <?php } 
            }   
               else { ?>
                <a href="#" data-toggle="modal" data-target="#bookingModal" class="btn disabled"><?php if($page_lang=='en') { ?>Book Now<?php } else { ?>立即报名<?php } ?></a>
            <?php } ?>
            </div>
        </div>

    <div class="clear-fix"></div>
    
        <div class="event-detail-tab">

          <ul class="nav nav-tabs">
            <li class="active"><a data-toggle="tab" href="#home"><?php if($page_lang=='en') { ?>EVENT INFO<?php }else { ?>活动详情<?php } ?></a></li>
            <li><a data-toggle="tab" href="#menu1"><?php if($page_lang=='en') { ?>AGENDA<?php }else { ?>活动日程<?php } ?></a></li>
            <li><a data-toggle="tab" href="#menu2"><?php if($page_lang=='en') { ?>LOCATION<?php }else { ?>活动地点<?php } ?></a></li>
            <li><a data-toggle="tab" href="#menu3"><?php if($page_lang=='en') { ?>CONTACT<?php }else { ?>联系方式<?php } ?></a></li>
          </ul>

          <div class="tab-content">
            <div id="home" class="tab-pane fade in active">
             <?php if( have_posts() ); ?>

                <?php 
                while( have_posts() ) : the_post(); 
                $content = get_the_content(); ?>
                <p><?php echo $content; ?></p>
                <?php endwhile; ?>
            </div>
              
            <div id="menu1" class="tab-pane fade">
                <p><?php the_field('agenda'); ?></p>
            </div>
              
            <div id="menu2" class="tab-pane fade">
                <div class="contact_map">
                <div style="width:100%;height:450px;border:#ccc solid 1px;float:left;" id="dituContent1"></div>
         
                </div>
              <script type="text/javascript" src="http://api.map.baidu.com/api?v=2.0&ak=DBa5badfc49c1ce0148b174ae3bdf0ea"></script>
                <script src="<?php echo get_template_directory_uri(); ?>/js/jquery.min.js"></script>
                <script type="text/javascript">
        	$(document).ready(function(){
        	
        	var address="<?php echo get_post_meta($fetchtid, 'enter_chinese_location', true); ?>";
        	
        	var map = new BMap.Map("dituContent1");
        	geocoder = new BMap.Geocoder(); 
        	
        	geocoder.getPoint(address, function(res){
        		console.log(res)
        		//console.log(res)
        	console.log(res.lat)
        		var lng=res.lng;
        		var lat=res.lat;
                       
        		var point = new BMap.Point(lng,lat);
        		//log(res.lat)
        		var sContent =
        			"<h4 style='margin:0 0 5px 0;padding:0.2em 0'></h4>" +
        			"<p style='margin:0;line-height:1.5;font-size:13px;text-indent:2em'>"+address+"</p></div>";
        		var icon = new BMap.Icon('http://www.swisschamofcommerce.com/wp-content/uploads/2017/02/map-marker.png', new BMap.Size(30, 42), {
        				anchor: new BMap.Size(10, 30),
        				infoWindowAnchor: new BMap.Size(10, 0)
        		});
        		var marker = new BMap.Marker(point, {
        				icon: icon,
        				title: address
        		}); 

        		
        													
        		//var marker = new BMap.Marker(point);
        		var infoWindow = new BMap.InfoWindow(sContent);
                         //map.addControl(new BMap.NavigationControl());
        		map.centerAndZoom(point, 19);
                        //map.enableScrollWheelZoom(); 
        		map.addOverlay(marker);
        		marker.addEventListener("click", function(){
        		this.openInfoWindow(infoWindow);
        		document.getElementById('imgDemo').onload = function (){
        		infoWindow.redraw();
        		}
        		});
        	}) 

          });
        </script>
            </div>
            <div id="menu3" class="tab-pane fade">
             <div class="contactperson-details">
                <ul>                                
               <li class="contact-head"><span><i class="fa fa-user" aria-hidden="true"></i></span><h3><?php echo get_post_meta($fetchtid, 'contact_name', true); ?></h3></li>            
               
               <li><span><span><i class="fa fa-briefcase" aria-hidden="true"></i></span></span><?php echo get_post_meta($fetchtid, 'designations', true); ?></li>
                <li><span><i class="fa fa-envelope" aria-hidden="true"></i></span> <a href="mailto:<?php echo get_post_meta($fetchtid, 'contact_email', true); ?>"><?php echo get_post_meta($fetchtid, 'contact_email', true); ?></a></li>
                <li><span><i class="fa fa-phone-square" aria-hidden="true"></i></span><?php echo get_post_meta($fetchtid, 'contact_phone', true); ?></li>
                
            </ul>

            </div>
            </div>
          </div>
      </div>

    <!-- Event Booking Model -->

<div class="modal fade" id="bookingModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document" style="width:1100px;">
    <div class="modal-content">
      <?php if ( !is_user_logged_in() ) { ?>   
     <h1>Please fill up the information to register</h1>
      <?php } else { ?>
     <h1>Please fill the infomartion for a booking</h1>
      <?php } ?>
      <div class="modal-body">
        <?php echo do_shortcode('[event]#_BOOKINGFORM[/event]'); ?>
      </div>
      
    </div>
  </div>
</div>
<!-- Booking Model End -->
</div>

</body>
</div>

<?php get_footer(); ?>
