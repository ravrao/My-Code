<?php /* Template Name: DownloadPDF Template */
//get_header(); ?> 
    
 
   <embed src="http://lab-1.sketchdemos.com/P1091_IKMF_New/wp-content/uploads/2018/07/how-to-learn-kung-fu-at-home-1.pdf#toolbar=0&navpanes=0" style="width:100%; height:100%;">




<?php //get_footer(); ?>
