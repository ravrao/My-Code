 <!-- FOOTER SECTION START-->
    <footer>
        <div class="container">
            <div class="row">
                <?php  $page_lang = ICL_LANGUAGE_CODE;?>
                 <?php $the_query = new WP_Query( 'page_id=588' ); ?>
                <?php while ($the_query -> have_posts()) : $the_query -> the_post();  
                $content = get_the_content();
                $about_feat_image = wp_get_attachment_url( get_post_thumbnail_id($post->ID) ); 
                ?>
                <div class="col-sm-3 col-xs-12">
                    <a href="<?php echo get_page_link(588); ?>#common"><h4> <?php echo get_post_meta($post->ID, 'footer_title', true); ?></h4></a>
                    <p> <?php echo get_post_meta($post->ID, 'footer_content', true); ?></p>
                </div>
                <?php endwhile; ?>
                <div class="col-sm-3 col-xs-12">
                    <a href="<?php echo get_page_link(27); ?>#common"><h4>  <?php if($page_lang=='en') { ?>Contact us<?php } else { ?> 联系我们 <?php } ?></h4></a>
                    <?php if($page_lang=='en'){ ?>
                    <p><?php echo get_option('jetbuzz_desc');?></p>
                    <?php } else {?>
                    <p><?php echo get_option('jetbuzz_desc_ch');?></p>
                    <?php } ?>
                    <ul>
                        <li><span><i class="fa fa-comments"></i></span><a href="#"><?php echo get_option('jetbuzz_wechat_text');?></a></li>
                        <li><span><i class="fa fa-envelope"></i></span><a href="mailto:<<?php echo get_option('jetbuzz_footemail');?>"><?php echo get_option('jetbuzz_footemail');?></a></li>
                        <li><span><i class="fa fa-mobile"></i></span><a href="tel:<?php echo get_option('jetbuzz_phone1');?>"><?php echo get_option('jetbuzz_phone1');?></a></li>
                        <li><span><i class="fa fa-mobile"></i></span><a href="tel:<?php echo get_option('jetbuzz_phone2');?>"><?php echo get_option('jetbuzz_phone2');?></a></li>                    
                    </ul>
                </div>
                <div class="col-sm-3 col-xs-12">
                    <?php if($page_lang=='en') { ?>
                    <h4>Wechat QR code</h4>
                    <?php } else {?>
                    <h4>微信二维码</h4>
                    <?php } ?>
                    <div class="qr-code">
                        <img src="<?php echo get_option('jetbuzz_weimage');?>" />
                    </div>
                    <p><a href="https://ikmfchina.world.taobao.com/" target="_blank;"><img src="<?php echo get_template_directory_uri(); ?>/images/game-logo.png" class="game-logo" /></a>
                    <?php if($page_lang=='en'){ ?>
                        <?php echo get_option('jetbuzz_wedesc');?>
                    <?php } else {?>
                    <?php echo get_option('jetbuzz_wedesc_ch');?>
                    <?php } ?></p>
                </div>
                
                 <div class="col-sm-3 col-xs-12">
                     <?php if($page_lang=='en') { ?>
                    <h4>Get in Touch</h4>
                    <div class="get-form">
                        <?php echo do_shortcode('[contact-form-7 id="96" title="Get in Touch"]')?>
                    </div>
                     <?php } 
                     else { ?>
                    <h4>保持联系</h4>
                    <div class="get-form">
                        <?php echo do_shortcode('[contact-form-7 id="1446" title="Get in Touch"]')?>
                    </div>
                      <?php } ?>
                </div>
            </div>
        </div>
    </footer>
    <!-- FOOTER SECTION END-->
    
    <!-- BOTTOM SECTION END-->
    <section class="bottom-section text-center">
        <div class="container">
            <div class="row">
                <div class="col-sm-12 col-xs-12">
                   
                    <?php
                $Footer = array(
                'theme_location'  => '',
                'menu'            => 'Footer',
                'container'       => '',
                'container_class' => '',
                'container_id'    => '',
                'menu_class'      => '',
                'menu_id'         => '',
                'echo'            => true,
                'fallback_cb'     => 'wp_page_menu',
                'before'          => '',
                 'after'           => '',
                'link_before'     => '',
                'link_after'      => '',
                'items_wrap'      => '<ul class="">%3$s</ul>',
                'depth'           => 0,
                'walker'          => ''
                );

                wp_nav_menu( $Footer );
                ?>
                </div>
                <div class="col-sm-12 col-xs-12">
                    <?php if($page_lang=='en'){ ?>
                    <p><?php echo get_option('jetbuzz_copyright');?></p>
                    <p><?php echo get_option('jetbuzz_fotdesc');?></p>
                    <?php } else {?>
                    <p><?php echo get_option('jetbuzz_copyright_ch');?></p>
                    <p><?php echo get_option('jetbuzz_fotdesc_ch');?></p>
                    <?php } ?>
                </div>
                <div class="col-sm-12 col-xs-12">
                    <div class="browser-section">
                        <a href="<?php echo get_option('jetbuzz_weibo');?>" target="_blank;"><img src="<?php echo get_template_directory_uri(); ?>/images/browse-logo1.png" alt=""></a>
                        <a href="<?php echo get_option('jetbuzz_iconlink1');?>" target="_blank;"><img src="<?php echo get_template_directory_uri(); ?>/images/browse-logo2.png" alt=""></a>
                        <a href="<?php echo get_option('jetbuzz_iconlink2');?>" target="_blank;"><img src="<?php echo get_template_directory_uri(); ?>/images/browse-logo3.png" alt=""></a>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- BOTTOM SECTION END-->
<!-- jQuery -->
    <script src="<?php echo get_template_directory_uri(); ?>/js/jquery.min.js"></script>    <!-- Bootstrap Core JavaScript -->
    <script src="<?php echo get_template_directory_uri(); ?>/js/bootstrap.min.js"></script>    
   
<!--    <script src='js/slim.min.js'></script>-->


        <!-- FOR GALLERY -->

     
    <script src="<?php echo get_template_directory_uri(); ?>/js/owl.carousel.js"></script>
    <script src="<?php echo get_template_directory_uri(); ?>/js/wow.js"></script>
    <script src="<?php echo get_template_directory_uri(); ?>/js/main.js"></script>
    <script src="<?php echo get_template_directory_uri(); ?>/js/jQuery.verticalCarousel.js"></script>
  
<!--Lateste news slider -->
<script>
    $(".recentArticles").verticalCarousel({
        currentItem: 1,
        showItems: 2,
    });

    window.setInterval(function(){
    if ( $('.vc_goDown').hasClass('isDisabled') ) {
         $('.vc_goUp').trigger('click');
    } else {
         $('.vc_goDown').trigger('click');
    }
     }, 3000);


</script>   
    <script>

 admin_ajax="<?php echo admin_url( 'admin-ajax.php' ); ?>";
 
         $('.owlOne').owlCarousel({
            loop:true,
            margin:20,
            autoplay: true,
             dots: false,
            nav:true,
            navText : ['<i class="fa fa-chevron-left" aria-hidden="true"></i>','<i class="fa fa-chevron-right" aria-hidden="true"></i>'], 
            responsive:{
                0:{
                    items:1
                },
                600:{
                    items:1
                },
                1000:{
                    items:1
                }
            }
        });
        
        $('.owlTwo').owlCarousel({
            loop:true,
            margin:20,
            autoplay: true,
             dots: false,
            nav:true,
            navText : ['<i class="fa fa-chevron-left" aria-hidden="true"></i>','<i class="fa fa-chevron-right" aria-hidden="true"></i>'], 
            responsive:{
                0:{
                    items:1
                },
                600:{
                    items:2
                },
                1000:{
                    items:3
                }
            }
        });
        $('.owlThree').owlCarousel({
            loop:true,
            margin:20,
            autoplay: true,
             dots: false,
            nav:true,
            navText : ['<i class="fa fa-chevron-left" aria-hidden="true"></i>','<i class="fa fa-chevron-right" aria-hidden="true"></i>'], 
            responsive:{
                0:{
                    items:1
                },
                600:{
                    items:2
                },
                1000:{
                    items:3
                }
            }
        });
        
        $('.owlFour').owlCarousel({
            loop:true,
            margin:20,
            autoplay: true,
             dots: false,
            nav:true,
            navText : ['<i class="fa fa-chevron-left" aria-hidden="true"></i>','<i class="fa fa-chevron-right" aria-hidden="true"></i>'], 
            responsive:{
                0:{
                    items:1
                },
                600:{
                    items:2
                },
                1000:{
                    items:3
                }
            }
        });
        
        $('html, body').hide();

                if (window.location.hash) {
                    setTimeout(function() {
                        $('html, body').scrollTop(0).show();
                        $('html, body').animate({
                            scrollTop: $(window.location.hash).offset().top - hdheight
                            }, 1000)
                    }, 0);
                }
                else {
                    $('html, body').show();
                }
        
        var hdheight = $('.top-section').height();
 
                var common = $('#common');
                if(common.length){
                   
                    $(".top-section a").on('click', function(event) {
                         //if (this.hash !== "") {
                        var toppos = common.offset().top - hdheight;
                        $('html,body').animate({
                            scrollTop:toppos
                        },'slow');
                        //}
                    });
       
                }
    </script>


    
<script>
function openModal() {
  document.getElementById('myModal').style.display = "block";
}

function closeModal() {
  document.getElementById('myModal').style.display = "none";
}

var slideIndex = 1;
showSlides(slideIndex);

function plusSlides(n) {
  showSlides(slideIndex += n);
}

function currentSlide(n) {
  showSlides(slideIndex = n);
}

function showSlides(n) {
  var i;
  var slides = document.getElementsByClassName("mySlides");
  var dots = document.getElementsByClassName("demo");
  var captionText = document.getElementById("caption");
  if (n > slides.length) {slideIndex = 1}
  if (n < 1) {slideIndex = slides.length}
  for (i = 0; i < slides.length; i++) {
      slides[i].style.display = "none";
  }
  for (i = 0; i < dots.length; i++) {
      dots[i].className = dots[i].className.replace(" active", "");
  }
  slides[slideIndex-1].style.display = "block";
  dots[slideIndex-1].className += " active";
  captionText.innerHTML = dots[slideIndex-1].alt;
}
</script>


   

<?php wp_footer(); ?>
</body>
</html>
