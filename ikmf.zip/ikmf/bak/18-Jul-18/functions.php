<?php
/**
 * Twenty Sixteen functions and definitions
 *
 * Set up the theme and provides some helper functions, which are used in the
 * theme as custom template tags. Others are attached to action and filter
 * hooks in WordPress to change core functionality.
 *
 * When using a child theme you can override certain functions (those wrapped
 * in a function_exists() call) by defining them first in your child theme's
 * functions.php file. The child theme's functions.php file is included before
 * the parent theme's file, so the child theme functions would be used.
 *
 * @link https://codex.wordpress.org/Theme_Development
 * @link https://codex.wordpress.org/Child_Themes
 *
 * Functions that are not pluggable (not wrapped in function_exists()) are
 * instead attached to a filter or action hook.
 *
 * For more information on hooks, actions, and filters,
 * {@link https://codex.wordpress.org/Plugin_API}
 *
 * @package WordPress
 * @subpackage Twenty_Sixteen
 * @since Twenty Sixteen 1.0
 */

/**
 * Twenty Sixteen only works in WordPress 4.4 or later.
 */
if ( version_compare( $GLOBALS['wp_version'], '4.4-alpha', '<' ) ) {
	require get_template_directory() . '/inc/back-compat.php';
}

if ( ! function_exists( 'twentysixteen_setup' ) ) :
/**
 * Sets up theme defaults and registers support for various WordPress features.
 *
 * Note that this function is hooked into the after_setup_theme hook, which
 * runs before the init hook. The init hook is too late for some features, such
 * as indicating support for post thumbnails.
 *
 * Create your own twentysixteen_setup() function to override in a child theme.
 *
 * @since Twenty Sixteen 1.0
 */
function twentysixteen_setup() {
	/*
	 * Make theme available for translation.
	 * Translations can be filed at WordPress.org. See: https://translate.wordpress.org/projects/wp-themes/twentysixteen
	 * If you're building a theme based on Twenty Sixteen, use a find and replace
	 * to change 'twentysixteen' to the name of your theme in all the template files
	 */
	load_theme_textdomain( 'twentysixteen' );

	// Add default posts and comments RSS feed links to head.
	add_theme_support( 'automatic-feed-links' );

	/*
	 * Let WordPress manage the document title.
	 * By adding theme support, we declare that this theme does not use a
	 * hard-coded <title> tag in the document head, and expect WordPress to
	 * provide it for us.
	 */
	add_theme_support( 'title-tag' );

	/*
	 * Enable support for custom logo.
	 *
	 *  @since Twenty Sixteen 1.2
	 */
	add_theme_support( 'custom-logo', array(
		'height'      => 240,
		'width'       => 240,
		'flex-height' => true,
	) );

	/*
	 * Enable support for Post Thumbnails on posts and pages.
	 *
	 * @link https://codex.wordpress.org/Function_Reference/add_theme_support#Post_Thumbnails
	 */
	add_theme_support( 'post-thumbnails' );
	set_post_thumbnail_size( 1200, 9999 );

	// This theme uses wp_nav_menu() in two locations.
	register_nav_menus( array(
		'primary' => __( 'Primary Menu', 'twentysixteen' ),
		'social'  => __( 'Social Links Menu', 'twentysixteen' ),
	) );

	/*
	 * Switch default core markup for search form, comment form, and comments
	 * to output valid HTML5.
	 */
	add_theme_support( 'html5', array(
		'search-form',
		'comment-form',
		'comment-list',
		'gallery',
		'caption',
	) );

	/*
	 * Enable support for Post Formats.
	 *
	 * See: https://codex.wordpress.org/Post_Formats
	 */
	add_theme_support( 'post-formats', array(
		'aside',
		'image',
		'video',
		'quote',
		'link',
		'gallery',
		'status',
		'audio',
		'chat',
	) );

	/*
	 * This theme styles the visual editor to resemble the theme style,
	 * specifically font, colors, icons, and column width.
	 */
	add_editor_style( array( 'css/editor-style.css', twentysixteen_fonts_url() ) );

	// Indicate widget sidebars can use selective refresh in the Customizer.
	add_theme_support( 'customize-selective-refresh-widgets' );
}
endif; // twentysixteen_setup
add_action( 'after_setup_theme', 'twentysixteen_setup' );

/**
 * Sets the content width in pixels, based on the theme's design and stylesheet.
 *
 * Priority 0 to make it available to lower priority callbacks.
 *
 * @global int $content_width
 *
 * @since Twenty Sixteen 1.0
 */
function twentysixteen_content_width() {
	$GLOBALS['content_width'] = apply_filters( 'twentysixteen_content_width', 840 );
}
add_action( 'after_setup_theme', 'twentysixteen_content_width', 0 );

/**
 * Registers a widget area.
 *
 * @link https://developer.wordpress.org/reference/functions/register_sidebar/
 *
 * @since Twenty Sixteen 1.0
 */
function twentysixteen_widgets_init() {
	register_sidebar( array(
		'name'          => __( 'Sidebar', 'twentysixteen' ),
		'id'            => 'sidebar-1',
		'description'   => __( 'Add widgets here to appear in your sidebar.', 'twentysixteen' ),
		'before_widget' => '<section id="%1$s" class="widget %2$s">',
		'after_widget'  => '</section>',
		'before_title'  => '<h2 class="widget-title">',
		'after_title'   => '</h2>',
	) );

	register_sidebar( array(
		'name'          => __( 'Content Bottom 1', 'twentysixteen' ),
		'id'            => 'sidebar-2',
		'description'   => __( 'Appears at the bottom of the content on posts and pages.', 'twentysixteen' ),
		'before_widget' => '<section id="%1$s" class="widget %2$s">',
		'after_widget'  => '</section>',
		'before_title'  => '<h2 class="widget-title">',
		'after_title'   => '</h2>',
	) );

	register_sidebar( array(
		'name'          => __( 'Content Bottom 2', 'twentysixteen' ),
		'id'            => 'sidebar-3',
		'description'   => __( 'Appears at the bottom of the content on posts and pages.', 'twentysixteen' ),
		'before_widget' => '<section id="%1$s" class="widget %2$s">',
		'after_widget'  => '</section>',
		'before_title'  => '<h2 class="widget-title">',
		'after_title'   => '</h2>',
	) );
        
        register_sidebar( array(
		'name'          => __( 'Upcoming Events', 'twentysixteen' ),
		'id'            => 'sidebar-4',
		'description'   => __( 'Appears at the bottom of the content on posts and pages.', 'twentysixteen' ),
		'before_widget' => '<section id="%1$s" class="widget %2$s">',
		'after_widget'  => '</section>',
		'before_title'  => '<h2 class="widget-title">',
		'after_title'   => '</h2>',
	) );
}
add_action( 'widgets_init', 'twentysixteen_widgets_init' );

if ( ! function_exists( 'twentysixteen_fonts_url' ) ) :
/**
 * Register Google fonts for Twenty Sixteen.
 *
 * Create your own twentysixteen_fonts_url() function to override in a child theme.
 *
 * @since Twenty Sixteen 1.0
 *
 * @return string Google fonts URL for the theme.
 */
function twentysixteen_fonts_url() {
	$fonts_url = '';
	$fonts     = array();
	$subsets   = 'latin,latin-ext';

	/* translators: If there are characters in your language that are not supported by Merriweather, translate this to 'off'. Do not translate into your own language. */
	if ( 'off' !== _x( 'on', 'Merriweather font: on or off', 'twentysixteen' ) ) {
		$fonts[] = 'Merriweather:400,700,900,400italic,700italic,900italic';
	}

	/* translators: If there are characters in your language that are not supported by Montserrat, translate this to 'off'. Do not translate into your own language. */
	if ( 'off' !== _x( 'on', 'Montserrat font: on or off', 'twentysixteen' ) ) {
		$fonts[] = 'Montserrat:400,700';
	}

	/* translators: If there are characters in your language that are not supported by Inconsolata, translate this to 'off'. Do not translate into your own language. */
	if ( 'off' !== _x( 'on', 'Inconsolata font: on or off', 'twentysixteen' ) ) {
		$fonts[] = 'Inconsolata:400';
	}

	if ( $fonts ) {
		$fonts_url = add_query_arg( array(
			'family' => urlencode( implode( '|', $fonts ) ),
			'subset' => urlencode( $subsets ),
		), 'https://fonts.googleapis.com/css' );
	}

	return $fonts_url;
}
endif;

/**
 * Handles JavaScript detection.
 *
 * Adds a `js` class to the root `<html>` element when JavaScript is detected.
 *
 * @since Twenty Sixteen 1.0
 */
function twentysixteen_javascript_detection() {
	echo "<script>(function(html){html.className = html.className.replace(/\bno-js\b/,'js')})(document.documentElement);</script>\n";
}
add_action( 'wp_head', 'twentysixteen_javascript_detection', 0 );

/**
 * Enqueues scripts and styles.
 *
 * @since Twenty Sixteen 1.0
 */
function twentysixteen_scripts() {
	// Add custom fonts, used in the main stylesheet.
	wp_enqueue_style( 'twentysixteen-fonts', twentysixteen_fonts_url(), array(), null );

	// Add Genericons, used in the main stylesheet.
	wp_enqueue_style( 'genericons', get_template_directory_uri() . '/genericons/genericons.css', array(), '3.4.1' );

	// Theme stylesheet.
	wp_enqueue_style( 'twentysixteen-style', get_stylesheet_uri() );

	// Load the Internet Explorer specific stylesheet.
	wp_enqueue_style( 'twentysixteen-ie', get_template_directory_uri() . '/css/ie.css', array( 'twentysixteen-style' ), '20160816' );
	wp_style_add_data( 'twentysixteen-ie', 'conditional', 'lt IE 10' );

	// Load the Internet Explorer 8 specific stylesheet.
	wp_enqueue_style( 'twentysixteen-ie8', get_template_directory_uri() . '/css/ie8.css', array( 'twentysixteen-style' ), '20160816' );
	wp_style_add_data( 'twentysixteen-ie8', 'conditional', 'lt IE 9' );

	// Load the Internet Explorer 7 specific stylesheet.
	wp_enqueue_style( 'twentysixteen-ie7', get_template_directory_uri() . '/css/ie7.css', array( 'twentysixteen-style' ), '20160816' );
	wp_style_add_data( 'twentysixteen-ie7', 'conditional', 'lt IE 8' );

	// Load the html5 shiv.
	wp_enqueue_script( 'twentysixteen-html5', get_template_directory_uri() . '/js/html5.js', array(), '3.7.3' );
	wp_script_add_data( 'twentysixteen-html5', 'conditional', 'lt IE 9' );

	wp_enqueue_script( 'twentysixteen-skip-link-focus-fix', get_template_directory_uri() . '/js/skip-link-focus-fix.js', array(), '20160816', true );

	if ( is_singular() && comments_open() && get_option( 'thread_comments' ) ) {
		wp_enqueue_script( 'comment-reply' );
	}

	if ( is_singular() && wp_attachment_is_image() ) {
		wp_enqueue_script( 'twentysixteen-keyboard-image-navigation', get_template_directory_uri() . '/js/keyboard-image-navigation.js', array( 'jquery' ), '20160816' );
	}

	wp_enqueue_script( 'twentysixteen-script', get_template_directory_uri() . '/js/functions.js', array( 'jquery' ), '20160816', true );

	wp_localize_script( 'twentysixteen-script', 'screenReaderText', array(
		'expand'   => __( 'expand child menu', 'twentysixteen' ),
		'collapse' => __( 'collapse child menu', 'twentysixteen' ),
	) );
}
add_action( 'wp_enqueue_scripts', 'twentysixteen_scripts' );

/**
 * Adds custom classes to the array of body classes.
 *
 * @since Twenty Sixteen 1.0
 *
 * @param array $classes Classes for the body element.
 * @return array (Maybe) filtered body classes.
 */
function twentysixteen_body_classes( $classes ) {
	// Adds a class of custom-background-image to sites with a custom background image.
	if ( get_background_image() ) {
		$classes[] = 'custom-background-image';
	}

	// Adds a class of group-blog to sites with more than 1 published author.
	if ( is_multi_author() ) {
		$classes[] = 'group-blog';
	}

	// Adds a class of no-sidebar to sites without active sidebar.
	if ( ! is_active_sidebar( 'sidebar-1' ) ) {
		$classes[] = 'no-sidebar';
	}

	// Adds a class of hfeed to non-singular pages.
	if ( ! is_singular() ) {
		$classes[] = 'hfeed';
	}

	return $classes;
}
add_filter( 'body_class', 'twentysixteen_body_classes' );

/**
 * Converts a HEX value to RGB.
 *
 * @since Twenty Sixteen 1.0
 *
 * @param string $color The original color, in 3- or 6-digit hexadecimal form.
 * @return array Array containing RGB (red, green, and blue) values for the given
 *               HEX code, empty array otherwise.
 */
function twentysixteen_hex2rgb( $color ) {
	$color = trim( $color, '#' );

	if ( strlen( $color ) === 3 ) {
		$r = hexdec( substr( $color, 0, 1 ).substr( $color, 0, 1 ) );
		$g = hexdec( substr( $color, 1, 1 ).substr( $color, 1, 1 ) );
		$b = hexdec( substr( $color, 2, 1 ).substr( $color, 2, 1 ) );
	} else if ( strlen( $color ) === 6 ) {
		$r = hexdec( substr( $color, 0, 2 ) );
		$g = hexdec( substr( $color, 2, 2 ) );
		$b = hexdec( substr( $color, 4, 2 ) );
	} else {
		return array();
	}

	return array( 'red' => $r, 'green' => $g, 'blue' => $b );
}

/**
 * Custom template tags for this theme.
 */
require get_template_directory() . '/inc/template-tags.php';

/**
 * Customizer additions.
 */
require get_template_directory() . '/inc/customizer.php';

/**
 * Add custom image sizes attribute to enhance responsive image functionality
 * for content images
 *
 * @since Twenty Sixteen 1.0
 *
 * @param string $sizes A source size value for use in a 'sizes' attribute.
 * @param array  $size  Image size. Accepts an array of width and height
 *                      values in pixels (in that order).
 * @return string A source size value for use in a content image 'sizes' attribute.
 */
function twentysixteen_content_image_sizes_attr( $sizes, $size ) {
	$width = $size[0];

	if ( 840 <= $width ) {
		$sizes = '(max-width: 709px) 85vw, (max-width: 909px) 67vw, (max-width: 1362px) 62vw, 840px';
	}

	if ( 'page' === get_post_type() ) {
		if ( 840 > $width ) {
			$sizes = '(max-width: ' . $width . 'px) 85vw, ' . $width . 'px';
		}
	} else {
		if ( 840 > $width && 600 <= $width ) {
			$sizes = '(max-width: 709px) 85vw, (max-width: 909px) 67vw, (max-width: 984px) 61vw, (max-width: 1362px) 45vw, 600px';
		} elseif ( 600 > $width ) {
			$sizes = '(max-width: ' . $width . 'px) 85vw, ' . $width . 'px';
		}
	}

	return $sizes;
}
add_filter( 'wp_calculate_image_sizes', 'twentysixteen_content_image_sizes_attr', 10 , 2 );

/**
 * Add custom image sizes attribute to enhance responsive image functionality
 * for post thumbnails
 *
 * @since Twenty Sixteen 1.0
 *
 * @param array $attr Attributes for the image markup.
 * @param int   $attachment Image attachment ID.
 * @param array $size Registered image size or flat array of height and width dimensions.
 * @return array The filtered attributes for the image markup.
 */
function twentysixteen_post_thumbnail_sizes_attr( $attr, $attachment, $size ) {
	if ( 'post-thumbnail' === $size ) {
		if ( is_active_sidebar( 'sidebar-1' ) ) {
			$attr['sizes'] = '(max-width: 709px) 85vw, (max-width: 909px) 67vw, (max-width: 984px) 60vw, (max-width: 1362px) 62vw, 840px';
		} else {
			$attr['sizes'] = '(max-width: 709px) 85vw, (max-width: 909px) 67vw, (max-width: 1362px) 88vw, 1200px';
		}
	}
	return $attr;
}
add_filter( 'wp_get_attachment_image_attributes', 'twentysixteen_post_thumbnail_sizes_attr', 10 , 3 );

/**
 * Modifies tag cloud widget arguments to display all tags in the same font size
 * and use list format for better accessibility.
 *
 * @since Twenty Sixteen 1.1
 *
 * @param array $args Arguments for tag cloud widget.
 * @return array The filtered arguments for tag cloud widget.
 */
function twentysixteen_widget_tag_cloud_args( $args ) {
	$args['largest']  = 1;
	$args['smallest'] = 1;
	$args['unit']     = 'em';
	$args['format']   = 'list'; 

	return $args;
}
add_filter( 'widget_tag_cloud_args', 'twentysixteen_widget_tag_cloud_args' );

// Register Custom Navigation Walker
require_once get_template_directory() . '/wp-bootstrap-navwalker.php';


add_action( 'wp_ajax_nopriv_populate_address', 'populate_address' );
add_action( 'wp_ajax_populate_address', 'populate_address' );

function populate_address(){
$stringss=$_POST['searchstring'];
global $post;
query_posts( array(
'post_type' => 'gymlocation',
'posts_per_page'  => '-1',
's'=>$stringss     
)); 

if( have_posts() ): while ( have_posts() ) : the_post(); 
//var_dump($post);
//echo 'rerereer'.$post->ID;
$feat_image = wp_get_attachment_url( get_post_thumbnail_id($post->ID) );
?>
     <li style="cursor:pointer" data-field="<?php echo get_post_meta($post->ID, 'gim-location', true); ?>"> 
    <?php if($feat_image!=''){ ?>                        
      <img src="<?php echo $feat_image;?>" alt="">
    <?php } else {?>
      <img src="<?php bloginfo('url')?>/wp-content/themes/ikmf/images/gym.jpg" alt=""/>
     <?php } ?>    
      <h3><?php echo get_the_title($post->ID);?></h3>
                             
      <?php echo get_post_meta($post->ID, 'gim-location', true); ?>
                           
       </li>

<?php 

 endwhile;endif;

wp_die();

}

/////////////// This Is For Chinese Website ///////////////////

add_action( 'wp_ajax_nopriv_populate_address_ch', 'populate_address_ch' );
add_action( 'wp_ajax_populate_address_ch', 'populate_address_ch' );

function populate_address_ch(){

$stringss=$_POST['searchstring'];
global $post;
query_posts( array(
'post_type' => 'gymlocation',
'posts_per_page'  => '-1',
's'=>$stringss     
)); 

if( have_posts() ): while ( have_posts() ) : the_post(); 
//var_dump($post);
//echo 'rerereer'.$post->ID;
$feat_image = wp_get_attachment_url( get_post_thumbnail_id($post->ID) );
?>
     <li style="cursor:pointer" data-field="<?php echo get_post_meta($post->ID, 'gim-location', true); ?>"> 
                            
      <?php if($feat_image!=''){ ?>                        
      <img src="<?php echo $feat_image;?>" alt="">
    <?php } else {?>
      <img src="<?php bloginfo('url')?>/wp-content/themes/ikmf/images/gym.jpg" alt=""/>
     <?php } ?>  
      <h3><?php echo get_the_title($post->ID);?></h3>
                             
      <?php echo get_post_meta($post->ID, 'gim-location', true); ?>
                           
       </li>

<?php 

 endwhile;endif;

wp_die();

}


/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// Theme Options -- Set the file path based on whether the Options Framework is in a parent theme or child theme 
////////////////////////////////////////////////////////////////////////////////////////////////////////////////

if ( STYLESHEETPATH == TEMPLATEPATH ) {
	define('OF_FILEPATH', TEMPLATEPATH);
	define('OF_DIRECTORY', get_bloginfo('template_directory'));
} else {
	define('OF_FILEPATH', STYLESHEETPATH);
	define('OF_DIRECTORY', get_bloginfo('stylesheet_directory'));
}

// These files build out the options interface.  Likely won't need to edit these. */

//require_once (OF_FILEPATH . '/admin/admin-functions.php');		// Custom functions and plugins
require_once (OF_FILEPATH . '/admin/admin-interface.php');		// Admin Interfaces (options,framework, seo)

/* These files build out the theme specific options and associated functions. */

require_once (OF_FILEPATH . '/admin/theme-options.php'); 		// Options panel settings and custom settings
require_once (OF_FILEPATH . '/admin/theme-functions.php'); 	// Theme actions based on options settings

add_image_size( 'home-news', 114, 114, true );
add_image_size( 'photo_album', 420, 278, true );
add_image_size( 'inner_banner', 1600, 250, true );

//create a function that will attach our new 'member' taxonomy to the 'post' post type

function add_course_taxonomy_to_post(){

   //set the name of the taxonomy
   $taxonomy = 'courses';
   //set the post types for the taxonomy
   $object_type = 'our_course';
   
   //populate our array of names for our taxonomy
   $labels = array(
       'name'               => 'Courses',
       'singular_name'      => 'Course',
       'search_items'       => 'Search Courses',
       'all_items'          => 'All Courses',
       'parent_item'        => 'Parent 课程',
       'parent_item_colon'  => 'Parent 课程:',
       'update_item'        => 'Update 课程',
       'edit_item'          => 'Edit 课程',
       'add_new_item'       => 'Add New 课程',
       'new_item_name'      => 'New 课程 Name',
       'menu_name'          => '课程'
   );
   
   //define arguments to be used
   $args = array(
       'labels'            => $labels,
       'hierarchical'      => true,
       'show_ui'           => true,
       'how_in_nav_menus'  => true,
       'public'            => true,
       'show_admin_column' => true,
       'query_var'         => true,
       'rewrite'           => array('slug' => 'course')
   );
   
   //call the register_taxonomy function
   register_taxonomy($taxonomy, $object_type, $args);
}
add_action('init','add_course_taxonomy_to_post');

function wpb_move_comment_field_to_bottom( $fields ) {
$comment_field = $fields['comment'];
unset( $fields['comment'] );
$fields['comment'] = $comment_field;
return $fields;
}
 
add_filter( 'comment_form_fields', 'wpb_move_comment_field_to_bottom' );

function add_level_taxonomy_to_post(){

   //set the name of the taxonomy
   $taxonomy = 'level';
   //set the post types for the taxonomy
   $object_type = 'our_team';
   
   //populate our array of names for our taxonomy
   $labels = array(
       'name'               => '水平',
       'singular_name'      => '水平',
       'search_items'       => 'Search 水平',
       'all_items'          => 'All 水平',
       'parent_item'        => 'Parent 水平',
       'parent_item_colon'  => 'Parent 水平:',
       'update_item'        => 'Update 水平',
       'edit_item'          => 'Edit 水平',
       'add_new_item'       => 'Add New 水平',
       'new_item_name'      => 'New 水平 Name',
       'menu_name'          => '水平'
   );
   
   //define arguments to be used
   $args = array(
       'labels'            => $labels,
       'hierarchical'      => true,
       'show_ui'           => true,
       'how_in_nav_menus'  => true,
       'public'            => true,
       'show_admin_column' => true,
       'query_var'         => true,
       'rewrite'           => array('slug' => 'level')
   );
   
   //call the register_taxonomy function
   register_taxonomy($taxonomy, $object_type, $args);
}
add_action('init','add_level_taxonomy_to_post');

function add_state_taxonomy_to_post(){

   //set the name of the taxonomy
   $taxonomy = 'state';
   //set the post types for the taxonomy
   $object_type = 'our_team';
   
   //populate our array of names for our taxonomy
   $labels = array(
       'name'               => '州',
       'singular_name'      => '州',
       'search_items'       => 'Search 州',
       'all_items'          => 'All 州',
       'parent_item'        => 'Parent 州',
       'parent_item_colon'  => 'Parent 州:',
       'update_item'        => 'Update 州',
       'edit_item'          => 'Edit 州',
       'add_new_item'       => 'Add New 州',
       'new_item_name'      => 'New 州 Name',
       'menu_name'          => '州'
   );
   
   //define arguments to be used
   $args = array(
       'labels'            => $labels,
       'hierarchical'      => true,
       'show_ui'           => true,
       'how_in_nav_menus'  => true,
       'public'            => true,
       'show_admin_column' => true,
       'query_var'         => true,
       'rewrite'           => array('slug' => 'state')
   );
   
   //call the register_taxonomy function
   register_taxonomy($taxonomy, array( 'our_team', 'our_course' ), $args);
}
add_action('init','add_state_taxonomy_to_post');

function is_post_type($type){
    global $wp_query;
    if($type == get_post_type($wp_query->post->ID)) return true;
    return false;
}

function get_cat_slug($cat_id) {
	$cat_id = (int) $cat_id;
	$category = &get_category($cat_id);
	return $category->slug;
}


function mylogo() { ?>
    <style type="text/css">
        .login h1 a {
            background-image: url(<?php echo get_stylesheet_directory_uri(); ?>/images/logo.png) !important;
            padding-bottom: 30px !important;
      background-size: 100% auto !important;
      height: 125px !important;
      padding: 0 !important;
      width: 270px !important;
      line-height: normal !important;
        }
    </style>
<?php }
add_action( 'login_enqueue_scripts', 'mylogo' );

function my_login_logo_url() {
    return home_url();
}
add_filter( 'login_headerurl', 'my_login_logo_url' );

function my_login_logo_url_title() {
    return 'IKMF China Krav Maga IKMF China, resilience and self-defense for everyone.';
}
add_filter( 'login_headertitle', 'my_login_logo_url_title');

function getCurrentURL()
{
    $currentURL = (@$_SERVER["HTTPS"] == "on") ? "https://" : "http://";
    $currentURL .= $_SERVER["SERVER_NAME"];
 
    if($_SERVER["SERVER_PORT"] != "80" && $_SERVER["SERVER_PORT"] != "443")
    {
        $currentURL .= ":".$_SERVER["SERVER_PORT"];
    } 
 
        $currentURL .= $_SERVER["REQUEST_URI"];
    return $currentURL;
}




function add_province_taxonomy_to_post(){

   //set the name of the taxonomy
   $taxonomy = 'province';
   //set the post types for the taxonomy
   $object_type = 'gymlocation';
   
   //populate our array of names for our taxonomy
   $labels = array(
       'name'               => '省份',
       'singular_name'      => '省份',
       'search_items'       => 'Search 省份',
       'all_items'          => 'All 省份',
       'parent_item'        => 'Parent 省份',
       'parent_item_colon'  => 'Parent 省份:',
       'update_item'        => 'Update 省份',
       'edit_item'          => 'Edit 省份',
       'add_new_item'       => 'Add New 省份',
       'new_item_name'      => 'New 省份 Name',
       'menu_name'          => '省份'
   );
   
   //define arguments to be used
   $args = array(
       'labels'            => $labels,
       'hierarchical'      => true,
       'show_ui'           => true,
       'how_in_nav_menus'  => true,
       'public'            => true,
       'show_admin_column' => true,
       'query_var'         => true,
       'rewrite'           => array('slug' => 'province')
   );
   
   //call the register_taxonomy function
   register_taxonomy($taxonomy, array( 'gymlocation', 'province' ), $args);
}
add_action('init','add_province_taxonomy_to_post');


function add_city_taxonomy_to_post(){

   //set the name of the taxonomy
   $taxonomy = 'city';
   //set the post types for the taxonomy
   $object_type = 'gymlocation';
   
   //populate our array of names for our taxonomy
   $labels = array(
       'name'               => '城市',
       'singular_name'      => '城市',
       'search_items'       => 'Search 城市',
       'all_items'          => 'All 城市',
       'parent_item'        => 'Parent 城市',
       'parent_item_colon'  => 'Parent 城市:',
       'update_item'        => 'Update 城市',
       'edit_item'          => 'Edit 城市',
       'add_new_item'       => 'Add New 城市',
       'new_item_name'      => 'New 城市 Name',
       'menu_name'          => '城市'
   );
   
   //define arguments to be used
   $args = array(
       'labels'            => $labels,
       'hierarchical'      => true,
       'show_ui'           => true,
       'how_in_nav_menus'  => true,
       'public'            => true,
       'show_admin_column' => true,
       'query_var'         => true,
       'rewrite'           => array('slug' => 'city')
   );
   
   //call the register_taxonomy function
   register_taxonomy($taxonomy, array( 'gymlocation', 'our_team', 'city' ), $args);
   //register_taxonomy( 'product-category', array( 'reviews', 'inspiration', 'manuals' ), $args );
}
add_action('init','add_city_taxonomy_to_post');


function add_cattype_taxonomy_to_post(){

   //set the name of the taxonomy
   $taxonomy = 'cattype';
   //set the post types for the taxonomy
   $object_type = 'upload_document';
   
   //populate our array of names for our taxonomy
   $labels = array(
       'name'               => 'Categort Type',
       'singular_name'      => 'Categort Type',
       'search_items'       => 'Search Categort Type',
       'all_items'          => 'All Categort Type',
       'parent_item'        => 'Parent Categort Type',
       'parent_item_colon'  => 'Parent Categort Type:',
       'update_item'        => 'Update Categort Type',
       'edit_item'          => 'Edit Categort Type',
       'add_new_item'       => 'Add New Categort Type',
       'new_item_name'      => 'New Categort Type Name',
       'menu_name'          => 'Categort Type'
   );
   
   //define arguments to be used
   $args = array(
       'labels'            => $labels,
       'hierarchical'      => true,
       'show_ui'           => true,
       'how_in_nav_menus'  => true,
       'public'            => true,
       'show_admin_column' => true,
       'query_var'         => true,
       'rewrite'           => array('slug' => 'cattype')
   );
   
   //call the register_taxonomy function
   register_taxonomy($taxonomy, array( 'upload_document', 'type' ), $args);
   //register_taxonomy( 'product-category', array( 'reviews', 'inspiration', 'manuals' ), $args );
}
add_action('init','add_cattype_taxonomy_to_post');

add_action('init', 'create_new_user_for_register');
function create_new_user_for_register(){

if ( 
    ! isset( $_POST['admin5678qsdfrs'] ) 
    || ! wp_verify_nonce( $_POST['admin5678qsdfrs'], 'create_new_user_registration') 
    ) {

   echo '';
  

}else{

        $username = sanitize_text_field($_POST['username']);
        $first_name = sanitize_text_field($_POST['first_name']);
        $last_name = sanitize_text_field($_POST['last_name']);
        $confemail = sanitize_text_field($_POST['confemail']);
        $passw1 = sanitize_text_field($_POST['passw1']);
        $phone_number= sanitize_text_field($_POST['phone_number']);
       	$city= sanitize_text_field($_POST['city']);
       	$provincearr= sanitize_text_field($_POST['province']);
        $arrval=explode(" ",$provincearr);
        $province=$arrval[0];
        $gymchoose_location=sanitize_text_field($_POST['gymchoose_location']);
        $gymchoose_level=sanitize_text_field($_POST['gymchoose_level']);
        $position=sanitize_text_field($_POST['position']);
        $select_type_user=sanitize_text_field($_POST['select_type_user']);
        $updatestatus=0;
       
        
        if (email_exists($confemail) == false ) {

            $user_id = wp_create_user($username , $passw1, $confemail );
             $concode=86;
            //echo $arrval[1];
            $gymcode=get_post_meta($gymchoose_location, 'gym_code', true);
            $stcode=str_pad($user_id,4,"0",STR_PAD_LEFT);
            //echo '<br/>';
            $uniuqid=$concode.$arrval[1].$gymcode.$stcode;
           
            update_user_meta($user_id,'first_name', $first_name);            
			update_user_meta($user_id,'last_name', $last_name);
			update_user_meta($user_id,'phone_number',$phone_number);
                        
			update_user_meta($user_id,'city', $city);	
			update_user_meta($user_id,'province', $province);
                        
                        update_user_meta($user_id,'gymchoose_location', $gymchoose_location);
                        update_user_meta($user_id,'gymchoose_level',$gymchoose_level);
            
			update_user_meta($user_id,'position',$position);
                        
			update_user_meta($user_id,'select_type_user',$select_type_user);
                        
                        update_user_meta($user_id,'wp-approve-user',$updatestatus);
                        
                        update_user_meta($user_id,'unique_ID',$uniuqid);
		

			$success=1;

			if($success==1){
                            
                            if($select_type_user=='student')
                            {
				echo "<script type='text/javascript'>window.location.href='".get_the_permalink(1045)."'</script>";  
                            }
                            else{
                                echo "<script type='text/javascript'>window.location.href='".get_the_permalink(1118)."/?mes=`instruct`'</script>";  
                            }
			}
        
                        
        $to  = $confemail;
        $subject = 'Account activation';

                     $message = '<!DOCTYPE HTML>
                    <html>

                    <head>
                        <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
                        <title>Account Activation</title>
                    </head>

                    <style>
                        @import url("https://fonts.googleapis.com/css?family=Roboto:400,500,700");
                    </style>

                    <body style="padding: 0;margin: 0;">

                        <div style="width: 800px; margin: 0 auto; border-top: 2px solid #aa0008; border-bottom:2px solid #aa0008; border-left: 1px solid #eaeaea; border-right: 1px solid #eaeaea; overflow: hidden;">

                            <div style="margin: 0 auto; text-align: center; width: 100%; padding: 30px 0;">
                                <img src="http://lab-1.sketchdemos.com/P1091_IKMF_New/wp-content/themes/ikmf/images/logo.png" alt="">
                            </div>

                            <div style="background: #aa0008; color: #fff; text-align: center; padding: 28px; font-size: 26px; text-transform: uppercase;">
                                New User Registration 
                            </div>

                            <div style="background: url(http://lab-1.sketchdemos.com/P1091_IKMF_New/wp-content/themes/ikmf/images/grilled.png) repeat; float: left; width: 100%; padding: 30px 0; font-size: 18px; line-height: 32px; color: #605e5e; padding: 20px;">
                                <p>
                                  Welcome to join IKMF FAMILY, to activate your user, please click the following link:</p>   
                                  <p><a href="http://lab-1.sketchdemos.com/P1091_IKMF_New/register/?activation_key='.$user_id.'">http://lab-1.sketchdemos.com/P1091_IKMF_New/register/?activation_key='.$user_id.'</a></p>
                                 <p>After you activate it you will receive yet *another email* with your login details.</p>      
                                </div>
                           

                        </div>

                    </body>


                    </html>';







                    // Always set content-type when sending HTML email
                    $headers = "MIME-Version: 1.0" . "\r\n";
                    $headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";
                    $headers .= 'From: <ikmf@lab-1.sketchdemos.com>';
                    @mail($to, $subject, $message, $headers);                
            // first name, last name etc
         } else {

          echo "<script type='text/javascript'>window.location.href='".get_the_permalink(1118)."/?msg=`This given email-id has already been taken.`'</script>";  
        
              exit();
         }
     }
}