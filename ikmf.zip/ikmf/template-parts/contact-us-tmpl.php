<?php /* Template Name: Contact Us Template */
get_header(); ?> 
  <?php   $page_lang = ICL_LANGUAGE_CODE;?>    
 <div class="container inner-cont" id="common">
     <div class="row">
        <div class="col-sm-12 col-xs-12">
            <div class="title ins-detail"><span><?php the_title();?></span></div>
        </div>
    </div>
    <div class="row">
        <div class="col-sm-8 col-xs-12 contact-form">
            <?php if($page_lang=='en') { ?>
            <?php echo do_shortcode('[contact-form-7 id="4" title="Contact form 1"]')?>
            <?php } else { ?>
            <?php echo do_shortcode('[contact-form-7 id="1450" title="Contact form 1_chinese"]')?>
            <?php } ?>
        </div>
        <div class="col-sm-4 col-xs-12 contact-right">
            <div class="qr-code">
                <img src="<?php echo get_option('jetbuzz_weimage');?>" />
            </div>
            <div class="info">               
                <p><?php echo get_option('jetbuzz_desc');?></p>
                <ul>
                    <li><span><i class="fa fa-comments"></i></span><a href="#"><?php echo get_option('jetbuzz_wechat_text');?></a></li>
                    <li><span><i class="fa fa-envelope"></i></span><a href="mailto:<<?php echo get_option('jetbuzz_footemail');?>"><?php echo get_option('jetbuzz_footemail');?></a></li>
                    <li><span><i class="fa fa-mobile"></i></span><a href="<?php echo get_option('jetbuzz_phone1');?>"><?php echo get_option('jetbuzz_phone1');?></a></li>
                    <li><span><i class="fa fa-mobile"></i></span><a href="<?php echo get_option('jetbuzz_phone2');?>"><?php echo get_option('jetbuzz_phone2');?></a></li>                    
                </ul>
            </div>
        </div>
    </div>

    </div>
<!--<div class="contact-map">
    <iframe src="https://j.map.baidu.com/9F7iP" width="600" height="450" frameborder="0" style="border:0" allowfullscreen></iframe>
</div>-->


<div class="contact_map">
        <div style="width:100%;height:450px;border:#ccc solid 1px;float:left;" id="dituContent1"></div>
 
</div>

<script type="text/javascript" src="http://api.map.baidu.com/api?v=2.0&ak=DBa5badfc49c1ce0148b174ae3bdf0ea"></script>
<script src="<?php echo get_template_directory_uri(); ?>/js/jquery.min.js"></script>
<script type="text/javascript">
	$(document).ready(function(){
	
	var address="<?php echo get_option('jetbuzz_address1'); ?>";
	//var city=$('#city').val();
	//alert(address);
	//var lat=$('#lat').val();
	var map = new BMap.Map("dituContent1");
	geocoder = new BMap.Geocoder(); 
	
	geocoder.getPoint(address, function(res){
		console.log(res)
		//console.log(res)
	console.log(res.lat)
		var lng=res.lng;
		var lat=res.lat;
                //alert(lng);
                //alert(lat);
		//alert(res.address);
		//var address=res.address;
		//$('#address').html(address);
		
		var point = new BMap.Point(lng,lat);
		//log(res.lat)
		var sContent =
			"<h4 style='margin:0 0 5px 0;padding:0.2em 0'></h4>" +
			"<p style='margin:0;line-height:1.5;font-size:13px;text-indent:2em'>"+address+"</p></div>";
		var icon = new BMap.Icon('<?php bloginfo('url')?>/wp-content/themes/ikmf/images/map-marker.png', new BMap.Size(50, 62), {
				anchor: new BMap.Size(10, 30),
				infoWindowAnchor: new BMap.Size(10, 0)
		});
		var marker = new BMap.Marker(point, {
				icon: icon,
				title: address
		}); 

		
													
		//var marker = new BMap.Marker(point);
		var infoWindow = new BMap.InfoWindow(sContent);
                 //map.addControl(new BMap.NavigationControl());
		map.centerAndZoom(point, 19);
                //map.enableScrollWheelZoom(); 
		map.addOverlay(marker);
		marker.addEventListener("click", function(){
		this.openInfoWindow(infoWindow);
		document.getElementById('imgDemo').onload = function (){
		infoWindow.redraw();
		}
		});
	}) 

  });
</script>
<?php get_footer(); ?>
