<?php
/**
 * The template for displaying 404 pages (not found)
 *
 * @package WordPress
 * @subpackage Twenty_Sixteen
 * @since Twenty Sixteen 1.0
 */

get_header(); ?>

<div class="container inner-cont cms-page" id="common">

	
    <center><h1 class="page-title">Oops! That page can’t be found.</h1></center>


</div>

<?php get_footer(); ?>
