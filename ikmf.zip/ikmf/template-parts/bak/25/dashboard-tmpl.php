<?php /* Template Name: Dashboard Template */
get_header(); ?> 

<?php 

//echo do_shortcode('[event post_id="135"]My selected event is called #_EVENTNAME #_EVENTTIMES[/event]'); 

$user = wp_get_current_user();
$user_id=$user->ID;
$user_info = get_userdata($user_id);
$firstname = get_user_meta( $user_id, 'first_name', true );
$lastname = get_user_meta( $user_id, 'last_name', true );
$city = get_user_meta( $user_id, 'city', true );
$province = get_user_meta( $user_id, 'province', true );
//echo $province;
$zipcode = get_user_meta( $user_id, 'zipcode', true );
$position = get_user_meta( $user_id, 'position', true );
$avtarimage = get_user_meta( $user_id, 'ravi_image_user', true );
$PACKAGE =  get_user_meta( $user_id,  'package', true );
$gymchoose_location =  get_user_meta( $user_id,  'gymchoose_location', true );
$select_type_user =  get_user_meta( $user_id,  'select_type_user', true );

$gymchoose_level =  get_user_meta( $user_id,  'gymchoose_level', true );



$NAME= $firstname .' '.$lastname;

if($_REQUEST['pac']!='')
{
    $new_value='Free';
    $updated = update_user_meta( $user_id, 'package', $new_value );
    if ( $new_value == get_user_meta( $user_id,  'package', true ) ) 
    { ?>
        <script language="javascript" type="text/javascript">
           
            window.location.href="<?php bloginfo('url')?>/dashboard/?eid=2/#menu2";
        </script>
    
    <?php }
}

/* Update Profile */

if(isset($_REQUEST["updatede"]))
{
  
    $fname      =   $_REQUEST['fname'];
    $lname      =   $_REQUEST['lname'];
    $phone      =   $_REQUEST['phone'];
    $address    =   $_REQUEST['address'];
    $zipcode    =   $_REQUEST['zipcode'];
    $password   =   $_REQUEST['passw'];
    $city   =   $_REQUEST['city'];
    $province   =   $_REQUEST['province'];
    $gymchoose_location   =   $_REQUEST['gymchoose_location'];
    $position   =   $_REQUEST['position'];
    $gymchoose_level   =   $_REQUEST['gymchoose_level'];
    $select_type_user   =   $_REQUEST['select_type_user'];
    
    
    update_user_meta( $user_id, 'first_name', $fname );
    update_user_meta( $user_id, 'last_name', $lname );
    update_user_meta( $user_id, 'dbem_phone', $phone );
    update_user_meta( $user_id, 'city', $city );
    update_user_meta( $user_id, 'province', $province );
    
    update_user_meta($user_id,'gymchoose_location', $gymchoose_location);
    update_user_meta($user_id,'gymchoose_level',$gymchoose_level);
    update_user_meta($user_id,'position',$position);
    update_user_meta($user_id,'select_type_user',$select_type_user);
    
    
    if($password!='') {
    wp_set_password( $password, $user_id );
    }
    
    if($_FILES['my_image_upload']['size'] != '') {
   // These files need to be included as dependencies when on the front end.
	require_once( ABSPATH . 'wp-admin/includes/image.php' );
	require_once( ABSPATH . 'wp-admin/includes/file.php' );
	require_once( ABSPATH . 'wp-admin/includes/media.php' );
	
	// Let WordPress handle the upload.
	// Remember, 'my_image_upload' is the name of our file input in our form above.
	$attachment_id = media_handle_upload( 'my_image_upload' , 0);
        $image_attributes = wp_get_attachment_image_src( $attachment_id );
        //echo $image_attributes[0];
        update_user_meta($user_id, 'ravi_image_user', $image_attributes[0]);
        //exit();
    } ?>
    <script language="javascript" type="text/javascript">
           
            window.location.href="<?php bloginfo('url')?>/dashboard/";
     </script>
<?php    
}

/* Instructors Level */

if(isset($_REQUEST["updatedeInst"]))
{
  
    $categorylevel      =   $_REQUEST['categorylevel'];
    update_user_meta( $user_id, 'Instructors_Level', $categorylevel );
?>
    <script language="javascript" type="text/javascript">
           
            window.location.href="<?php bloginfo('url')?>/dashboard/#menu4";
     </script>
<?php    
}

?>


 <div class="container inner-cont">
    <div class="row">
        <div class="col-sm-12 col-xs-12">
            <div class="title ins-detail" id="common"><span>Welcome, <?php echo ucfirst($NAME);?></span></div>
        </div>
    </div>

 
    <section class="dashboard-section">    
        <div class="row">
            <div class="col-md-3">
                <ul class="nav nav-pills">
                    <li class="active"><a data-toggle="pill" href="#home">View Profile</a></li>
                    <li><a data-toggle="pill" href="#menu1">Edit Profile</a></li>
                    <?php $user_typesel = get_user_meta( $user_id, 'select_type_user', true );?>
                    
                    <?php if($user_typesel=='instructor') { ?>
                    <!--<li><a data-toggle="pill" href="#menu4">Choose Instructors Level</a></li>-->
                    <?php } ?>
                    
                    <li><a data-toggle="pill" href="#menu2">Event Attended</a></li>
                    <?php if($user_typesel!='') { ?>
                    <li><a data-toggle="pill" href="#menu4">Information Center</a></li>
                    <?php } ?>
                    <li><a data-toggle="pill" href="#menu3">Change Package</a></li>
                    
                    
                </ul>
            </div>
            <div class="col-md-9">
                <div class="tab-content">

                    <div id="home" class="tab-pane fade in active">
                      <h3>Personal Info</h3>
                     
                      <img src="<?php if($avtarimage!='') { echo $avtarimage;?> <?php } else { bloginfo('template_url')?>/images/no-image-icon-hi.png <?php } ?>" alt="" class="img-responsive info-img">
                      <div class="p-info">
                          <h4>Name</h4>
                          <p> <?php echo ucfirst($NAME);?></p>
                      </div>
                      <div class="p-info">
                          <h4>Email</h4>
                          <p><?php echo $user_info->user_email;?></p>
                      </div>
                      <div class="p-info">
                          <h4>Phone number</h4>
                          <p><?php echo $user_phone = get_user_meta( $user_id, 'dbem_phone', true );?></p>
                          <p><?php echo $user_phone = get_user_meta( $user_id, 'phone_number', true );?></p>
                      </div>
                      <?php if($address!='') {?>
                      <div class="p-info">
                          <h4>Address</h4>
                          <p><?php echo $address;?></p>
                      </div>
                      <?php } 
                      if($zipcode!='') { ?>
                      <div class="p-info">
                          <h4>Zipcode</h4>
                          <p><?php echo $zipcode;?></p>
                      </div>
                      <?php } ?>
                      <div class="p-info">
                          <h4>PACKAGE</h4>
                          <p style="font-weight: bold; color: red;"><?php $user_package = get_user_meta( $user_id, 'package', true );?>
                          <?php if($user_package!='') { echo $user_package; } else { echo 'Free'; }?>
                          </p>
                      </div>
                      <?php $instype=get_user_meta( $user_id, 'select_type_user', true );
                      if($instype!=''){
                      ?>
                      
                    <div class="p-info">
                          <h4>Type</h4>
                          <p style="font-weight: bold; color: red;"><?php echo ucfirst($instype);?>
                          </p>
                    </div>
                    <?php } ?>
                    <?php $inst_level = get_user_meta( $user_id, 'Instructors_Level', true );
                    if($inst_level!=''){
                    ?>  
                    <div class="p-info">
                          <h4>Instructors Level</h4>
                          <p style="font-weight: bold; color: red;">
                           <?php   
                            $level=get_categories(array('taxonomy' => 'level', 'orderby' => 'ID', 'order' => 'ASC','hide_empty'=>0));
                            foreach($level as $lvalue)
                            {
                               if($inst_level==$lvalue->term_id) { echo $lvalue->name;}
                            }
                            ?>    
                              
                          </p>
                    </div>  
                    <?php } ?>  
                      
                    <?php $gym_name = get_user_meta( $user_id, 'gymchoose_location', true );
                    if($gym_name!=''){
                    ?>  
                    <div class="p-info">
                          <h4>Gym Name</h4>
                          <p style="font-weight: bold; color: red;">
                           <?php   
                            echo get_the_title( $gym_name ); 
                            ?>    
                              
                          </p>
                    </div>  
                    <?php } ?>   
                    </div>

                    <div id="menu1" class="tab-pane fade">
                        <h3>Edit Personal Information</h3>
                        <form name="profileedit" enctype="multipart/form-data" method="post">
                            <div class="form-group">
                                <label for="name">First Name:</label>
                                <input type="text" value="<?php echo $firstname ?>" name="fname" class="form-control" id="fname" required="true">
                            </div>
                            <div class="form-group">
                                <label for="name">Last Name:</label>
                                <input type="text" value="<?php echo $lastname ?>" name="lname" class="form-control" id="lname" required="true">
                            </div>
                            <div class="form-group">
                                <label for="name">Phone:</label>
                                <input type="text" value="<?php echo $user_phone ?>" name="phone" class="form-control" id="phone" required="true">
                            </div>
                            <div class="form-group">
                                <label for="name">Change Password:</label>
                                <input type="text" name="passw" class="form-control" id="pass">
                            </div>
                            <div class="form-group">
                                <label for="name">E-mail:</label>
                                <input type="text" readonly="true" name="email" value="<?php echo $user_info->user_email;?>" class="form-control" id="email">
                            </div>
                            <div class="form-group">
                                <label for="name">City:</label>
                                <input type="text" readonly="true" name="city" value="<?php echo $city;?>" class="form-control" id="city" required="true">
                            </div>
                            <div class="form-group">
                                <label for="name">Province:</label>
                                <!--<input type="text" name="province" value="<?php echo $province;?>" class="form-control" id="province" required="true">-->
                            
                                <select name="province" id="province" disabled="true" class="custom_field_cpt_select ">
                                <option value="">Please Choose</option>
                                 <?php   
                                    $level=get_categories(array('taxonomy' => 'province', 'orderby'=> 'title', 'order' => 'ASC', 'hide_empty'=>0));

                                    foreach($level as $lvalue)
                                    {
                                        $arrval=explode(" ",$lvalue->term_id);
                       
                                        $provinceval=$arrval[0];
                                ?> 
                                <option <?php if($province == $provinceval ) { ?>selected="true"<?php } ?> value="<?php echo $lvalue->term_id;?> <?php echo the_field('province_code', 'province' . '_' . $lvalue->term_id);?>"><?php echo $lvalue->name;?></option>
                                <?php } ?>
                            </select>
                            
                            </div>
                            
                            
                            
                            <!--<div class="form-group">
                                <label for="email">Zip Code:</label>
                                <input type="text" value="<?php echo $zipcode;?>" name="zipcode" class="form-control" id="zipcode" required="true">
                            </div>-->
                            <?php if($select_type_user=='instructor' || $select_type_user=='student') {?>
                            <div class="form-group">
                            <label for="gymchoose_location">Gym Location:</label>
                            
                            <input type="text" readonly="true" name="gymchoose_location" value="<?php echo get_the_title( $gymchoose_location );?>" readonly="true" class="form-control" id="gymchoose_location">
                            </div>
                            
                            
                            <div class="form-group">
                                <label for="name">Position:</label>
                                <input type="text" name="position" value="<?php echo $position;?>" class="form-control" id="position" required="true">
                            </div>
                            <div class="form-group">
                           
                                <label for="select_type_user">Type:</label>
                                
                                
                                <input type="text" readonly="true" name="select_type_user" value="<?php echo $select_type_user;?>" readonly="true" class="form-control" id="select_type_user">
                       
                            </div>
                            <?php } 
                            if($select_type_user=='instructor') { ?>
                            
                            <div class="form-group">
                            <label for="gymchoose_level">Level:</label>
                            <select name="gymchoose_level" id="gymchoose_level" class="custom_field_cpt_select ">
                                <option value="">...Choose</option>
                                <?php   
                                $level=get_categories(array('taxonomy' => 'level', 'orderby' => 'ID', 'order' => 'ASC','hide_empty'=>0));
                                foreach($level as $lvalue)
                                { ?>

                                  <option value="<?php echo $lvalue->term_id; ?>" <?php if($gymchoose_level== $lvalue->term_id ) { ?>selected="true"<?php } ?>><?php echo $lvalue->name; ?></option>  
                                <?php }
                                ?>
                            </select>
                            </div>
                            <?php } ?>
                            <div class="form-group">
                                <label for="pwd">Upload Profile Image:</label>
                                <input type="file" name="my_image_upload" id="my_image_upload"  multiple="false" />
                                <?php wp_nonce_field( 'my_image_upload', 'my_image_upload_nonce' ); ?>
                            </div>                            
                            <button type="submit" name="updatede" class="btn btn-default">Submit</button>
                        </form>
                    </div>
                    
                    
                    <div id="menu2" class="tab-pane fade">
                      <h3>Events Listing</h3>
                        <table>
                            <tr>
                              <th>Event Date</th>
                              <th>Event Name</th>
                              <th>Location</th>
                              <th>Price</th>
                              <th>Pay Now</th>
                            </tr>
                    <?php
                   
                    $wish=$wpdb->get_results("select * from `ik_em_bookings` where person_id='$user_id' order by booking_id desc" );
                    foreach ( $wish as $eventval )
                    {
                        $postID=$wpdb->get_row("select * from `ik_em_events` where event_id='$eventval->event_id'");
                        $getpoid=$postID->post_id;
                     ?>         
                            <tr>
                               <td><?php echo do_shortcode('[event post_id="'.$getpoid.'"]<span><i class="fa fa-calendar"></i></span> #_EVENTDATES <br/><strong> #_EVENTTIMES</strong>[/event]');?></td>
                              <td><?php echo do_shortcode('[event post_id="'.$getpoid.'"]<a href="#_EVENTURL" target="blank;">#_EVENTNAME</a><p>Category: #_CATEGORYNAME</p>[/event]');?></td>
                              <td><?php echo do_shortcode('[event post_id="'.$getpoid.'"]<i class="fa fa-map-marker"></i></span> #_LOCATIONADDRESS[/event]');?></td>
                              <td><i class="fa fa-money" aria-hidden="true"></i><?php if($PACKAGE!='Free') {?> Member:
                                <?php $minprice= do_shortcode('[event post_id="'.$getpoid.'"]#_EVENTPRICEMIN[/event]'); 

                                     $minexploded=explode(".",$minprice); 
                              echo $minexploded[0]; } else {
                                ?> 
                                Non Members: <?php $maxprice= do_shortcode('[event post_id="'.$getpoid.'"]#_EVENTPRICEMAX[/event]');
                            $maxexploded=explode(".",$maxprice); 
                            echo $maxexploded[0];
                              } ?>
                               </td>
                              <td><a href="#" class="btn">Pay Now</a></td>
                            </tr>
                    <?php } ?>        
                        </table>
                    </div>
                    
                    <div id="menu4" class="tab-pane fade">
                      <h3>Information Center</h3>
                        <table>
                            <tr>
                              <th>Name</th>
                              <th>Notice</th>
                              <?php if($instype=='instructors') {?>
                              <th>Download</th> <?php } ?>
                              <th>View</th>
                             
                             
                            </tr>
                    
                                <?php
                             query_posts( array(
                             'post_type' => 'upload_document',
                             'post_per_page' => -1,
                             
                            'tax_query' => array(
                           array(
                              'taxonomy' => 'cattype',
                              'field' => 'name',
                              'terms' =>  $instype,
                              'include_children' => false 

                           )
                            ),
                                
                             )); 
                             
                             if( have_posts() ): while ( have_posts() ) : the_post();
                             
                             $feat_image = wp_get_attachment_url( get_post_thumbnail_id($post->ID) );
                             $content = get_the_content();
                            $content = strip_tags($content);
                            
                           $yesno = get_field('important_documents'); 
                           if($yesno=='yes'){
                           ?>
                                    
                            <tr>
                               <td><?php the_title();?></td>
                               <td><?php echo substr($content, 0, 110);?>
                                   <a style="font-weight: bold; color: #121212;" href="#" data-toggle="modal" data-target="#myModaldata<?php echo $post->ID;?>">Read More...</a>
                               
                               <!-- Modal -->
                                <div class="modal fade pdf-modal" id="myModaldata<?php echo $post->ID;?>" role="dialog">
                                    <div class="modal-dialog" style="width: 80% !important; max-width: 100%;">

                                    <!-- Modal content-->
                                    <div class="modal-content" >
                                      <div class="modal-header">
                                        <button type="button" class="close" data-dismiss="modal">&times;</button>
                                      </div>
                                      <div class="modal-body text-center">
                                       <?php the_content();?>
                                      </div>
                                      <div class="modal-footer">
                                        <!-- <button type="button" class="btn btn-default" data-dismiss="modal">Close</button> -->
                                      </div>
                                    </div>

                                  </div>
                                </div>
                               </td>
                              
                              <td>
                                  <?php if($instype=='student') {?>
                                  <a style="color: green;" href="#" data-toggle="modal" data-target="#myModal<?php echo $post->ID;?>">View</a>
                                  <!-- Modal -->
                                <div class="modal fade pdf-modal" id="myModal<?php echo $post->ID;?>" role="dialog">
                                    <div class="modal-dialog" style="width: 80% !important; max-width: 100%;">

                                    <!-- Modal content-->
                                    <div class="modal-content" >
                                      <div class="modal-header">
                                        <button type="button" class="close" data-dismiss="modal">&times;</button>
                                      </div>
                                      <div class="modal-body text-center">
                                       <embed src="<?php the_field('upload_file/doc/article/etc',$post->ID); ?>#toolbar=0" style="width:98%; height:440px; margin: 0 auto;">
                                      </div>
                                      <div class="modal-footer">
                                        <!-- <button type="button" class="btn btn-default" data-dismiss="modal">Close</button> -->
                                      </div>
                                    </div>

                                  </div>
                                </div>
                                  <?php } else {
                                  if(get_field('upload_file/doc/article/etc',$post->ID)) {   
                                 ?>
                                  <a style="color: green; font-weight: bold;" href="<?php the_field('upload_file/doc/article/etc',$post->ID); ?>" target="_blank" download>Download</a>
                                  <?php } else { ?>
                                  <a style="color: red; font-weight: bold;">Not Available</a> <?php } ?>
                                 
                              <!-- Modal -->
                                <div class="modal fade pdf-modal" id="myModal<?php echo $post->ID;?>" role="dialog">
                                    <div class="modal-dialog" style="width: 80% !important; max-width: 100%;">

                                    <!-- Modal content-->
                                    <div class="modal-content" >
                                      <div class="modal-header">
                                        <button type="button" class="close" data-dismiss="modal">&times;</button>
                                      </div>
                                      <div class="modal-body text-center">
                                       <embed src="<?php the_field('upload_file/doc/article/etc',$post->ID); ?>#toolbar=0" style="width:98%; height:440px; margin: 0 auto;">
                                      </div>
                                      <div class="modal-footer">
                                        <!-- <button type="button" class="btn btn-default" data-dismiss="modal">Close</button> -->
                                      </div>
                                    </div>

                                  </div>
                                </div>
                              </td>
                              <td> 
                                  <?php if(get_field('upload_file/doc/article/etc',$post->ID)) {   ?>
                                  <a style="color: green; font-weight: bold;" href="#" data-toggle="modal" data-target="#myModal<?php echo $post->ID;?>">View</a>
                                  <?php } else {?>
                                  <a style="color: red; font-weight: bold;">Not Available</a><?php } ?>
                              </td>
                                  <?php  } ?>
                            </tr>
                           <?php }  ?>
                            <?php
                            endwhile;
                            endif; 
                            
                             if( have_posts() ): while ( have_posts() ) : the_post();
                             
                             $feat_image = wp_get_attachment_url( get_post_thumbnail_id($post->ID) );
                             $content = get_the_content();
                            $content = strip_tags($content);
                            
                           echo $yesno = get_field('important_documents'); 
                           if($yesno=='no'){
                           ?>
                                    
                            <tr>
                               <td><?php the_title();?></td>
                               <td><?php echo substr($content, 0, 110);?>
                                   <a style="font-weight: bold; color: #121212;" href="#" data-toggle="modal" data-target="#myModaldata<?php echo $post->ID;?>">Read More...</a>
                               
                               <!-- Modal -->
                                <div class="modal fade pdf-modal" id="myModaldata<?php echo $post->ID;?>" role="dialog">
                                    <div class="modal-dialog" style="width: 80% !important; max-width: 100%;">

                                    <!-- Modal content-->
                                    <div class="modal-content" >
                                      <div class="modal-header">
                                        <button type="button" class="close" data-dismiss="modal">&times;</button>
                                      </div>
                                      <div class="modal-body text-center">
                                       <?php the_content();?>
                                      </div>
                                      <div class="modal-footer">
                                        <!-- <button type="button" class="btn btn-default" data-dismiss="modal">Close</button> -->
                                      </div>
                                    </div>

                                  </div>
                                </div>
                               </td>
                              
                              <td>
                                  <?php if($instype=='student') {?>
                                  <a style="color: green;" href="#" data-toggle="modal" data-target="#myModal<?php echo $post->ID;?>">View</a>
                                  <!-- Modal -->
                                <div class="modal fade pdf-modal" id="myModal<?php echo $post->ID;?>" role="dialog">
                                    <div class="modal-dialog" style="width: 80% !important; max-width: 100%;">

                                    <!-- Modal content-->
                                    <div class="modal-content" >
                                      <div class="modal-header">
                                        <button type="button" class="close" data-dismiss="modal">&times;</button>
                                      </div>
                                      <div class="modal-body text-center">
                                       <embed src="<?php the_field('upload_file/doc/article/etc',$post->ID); ?>#toolbar=0" style="width:98%; height:440px; margin: 0 auto;">
                                      </div>
                                      <div class="modal-footer">
                                        <!-- <button type="button" class="btn btn-default" data-dismiss="modal">Close</button> -->
                                      </div>
                                    </div>

                                  </div>
                                </div>
                                  <?php } else {
                                  if(get_field('upload_file/doc/article/etc',$post->ID)) {   
                                 ?>
                                  <a style="color: green; font-weight: bold;" href="<?php the_field('upload_file/doc/article/etc',$post->ID); ?>" target="_blank" download>Download</a>
                                  <?php } else { ?>
                                  <a style="color: red; font-weight: bold;">Not Available</a> <?php } ?>
                                 
                              <!-- Modal -->
                                <div class="modal fade pdf-modal" id="myModal<?php echo $post->ID;?>" role="dialog">
                                    <div class="modal-dialog" style="width: 80% !important; max-width: 100%;">

                                    <!-- Modal content-->
                                    <div class="modal-content" >
                                      <div class="modal-header">
                                        <button type="button" class="close" data-dismiss="modal">&times;</button>
                                      </div>
                                      <div class="modal-body text-center">
                                       <embed src="<?php the_field('upload_file/doc/article/etc',$post->ID); ?>#toolbar=0" style="width:98%; height:440px; margin: 0 auto;">
                                      </div>
                                      <div class="modal-footer">
                                        <!-- <button type="button" class="btn btn-default" data-dismiss="modal">Close</button> -->
                                      </div>
                                    </div>

                                  </div>
                                </div>
                              </td>
                              <td> 
                                  <?php if(get_field('upload_file/doc/article/etc',$post->ID)) {   ?>
                                  <a style="color: green; font-weight: bold;" href="#" data-toggle="modal" data-target="#myModal<?php echo $post->ID;?>">View</a>
                                  <?php } else {?>
                                  <a style="color: red; font-weight: bold;">Not Available</a><?php } ?>
                              </td>
                                  <?php  } ?>
                            </tr>
                           <?php } ?>
                            <?php
                            endwhile;
                            endif; 
                            
                            ?>      
                        </table>
                    </div>

                    <div id="menu3" class="tab-pane fade">
                      <h3>Change Package</h3>
                      <section class="package-section">
    
        <div class="row">
            <div class="col-md-4 col-sm-6 col-xs-12 pack-container">
                <div class="package-div">
                    <ul>
                        <li class="p-heading"><h3>Platinum</h3></li>
                        <li class="p-price"><h4>$ 9.99 / year</h4></li>
                        <li class="p-text"><p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s</p></li>
                        <li class="p-btn"><a href="#" class="btn">Buy Now</a></li>
                    </ul>
                </div>
            </div>

            <div class="col-md-4 col-sm-6 col-xs-12 pack-container">
                <div class="package-div">
                    <ul>
                        <li class="p-heading"><h3>Gold</h3></li>
                        <li class="p-price"><h4>$ 7.99 / year</h4></li>
                        <li class="p-text"><p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s</p></li>
                        <li class="p-btn"><a href="#" class="btn">Buy Now</a></li>
                    </ul>
                </div>
            </div>

            <div class="col-md-4 col-sm-6 col-xs-12 pack-container">
                <div class="package-div">
                    <ul>
                        <li class="p-heading"><h3>Silver</h3></li>
                        <li class="p-price"><h4>$ 3.99 / year</h4></li>
                        <li class="p-text"><p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s</p></li>
                        <li class="p-btn"><a href="#" class="btn">Buy Now</a></li>
                    </ul>
                </div>
            </div>

            
        </div>
     
</section>
                    </div>

                    <!--<div id="menu4" class="tab-pane fade">
                        <h3>Choose Instructors Level</h3>
                        <?php $inst_level = get_user_meta( $user_id, 'Instructors_Level', true );?>
                        <form name="inslevel" enctype="multipart/form-data" method="post">
                            <div class="form-group">
                                <label for="name">Choose Instructors Level:</label>
                                <select name="categorylevel" class="em-events-search-category">
                                    <option value="" selected="selected">Please Choose Level</option>
                                   <?php   
                                   $level=get_categories(array('taxonomy' => 'level', 'orderby' => 'ID', 'order' => 'ASC','hide_empty'=>0));
                                   foreach($level as $lvalue)
                                      {
                                   ?> 
                                    <option value="<?php echo $lvalue->term_id;?>"  <?php if($inst_level== $lvalue->term_id ) { ?>selected="true"<?php } ?>><?php echo $lvalue->name;?></option>
                                      <?php } ?>    
                               </select>
                            </div>
                            
                                                     
                            <button type="submit" name="updatedeInst" class="btn btn-default">Submit</button>
                        </form>
                    </div>-->
                   


                  </div>
            </div>
        </div>
    </section>



    </div>


    
<?php get_footer(); ?>
