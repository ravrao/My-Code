function initMap()
{  var address="北京市朝阳区麦子店西街39号B2";
   var Name= "IKMF马伽术北京训练馆（燕莎)";
    map=new BMap.Map('map');
    geocoder=new BMap.Geocoder();
    geocoder.getPoint(address,function(res)
    { var lng=res.lng;
      var lat=res.lat;
      var sContent =
			"<h4 style='margin:0 0 5px 0;padding:0.2em 0'></h4>" +
			"<p style='margin:0;line-height:1.5;font-size:13px;text-indent:2em;font-weight:bold;'>"+Name+"</p>"+
                         "<p style='margin:0;line-height:1.5;font-size:13px;text-indent:2em'>"+address+"</p></div>";
                
      var icon = new BMap.Icon('http://lab-1.sketchdemos.com/P1091_IKMF/wp-content/themes/ikmf/images/map-marker.png', new BMap.Size(50, 62), 
    {
    anchor: new BMap.Size(10, 30),
    infoWindowAnchor: new BMap.Size(10, 0)
    });
        point=new BMap.Point(lng,lat);
        var infoWindow = new BMap.InfoWindow(sContent);
        map.centerAndZoom(point,19);
        var marker=new BMap.Marker(point,{
				icon: icon,
                                title: Name,
                                
				
		}); 
map.addOverlay(marker);
marker.setAnimation(BMAP_ANIMATION_DROP)
marker.addEventListener("click", function(){
		this.openInfoWindow(infoWindow);
		document.getElementById('imgDemo').onload = function (){
		infoWindow.redraw();
		}
		});
    })
}


$(".searhLocation").keyup(function()
{
    $searchstring=$('.searhLocation').val();
    $.ajax({type:"POST",url:admin_ajax,data:{"action":"populate_address_ch","searchstring":$searchstring},success:function(result){$(".autoPopulate").html(result)}})});
$(".serach-location").on('click','.autoPopulate li',function()
{
var address=$(this).data("field");
var title =$(this).find('h3').text(); //alert(title);
var phno =$(this).find('#phoneno').val(); //alert(phno);
//var phno =$(this).find('#phoneno').val();
geocoder=new BMap.Geocoder();
geocoder.getPoint(address,function(res){console.log(res)
var lng=res.lng;var lat=res.lat;
var point=new BMap.Point(lng,lat);
var sContent =
        "<h4 style='margin:0 0 5px 0;padding:0.2em 0'></h4>" +
        "<p style='margin:0;line-height:1.5;font-size:13px;text-indent:2em;font-weight:bold;'>"+title+"</p>"+
         "<p style='margin:0;line-height:1.5;font-size:13px;text-indent:2em'>"+address+"</p>"+
         "<p style='margin:0;line-height:1.5;font-size:13px;text-indent:2em'>电话: "+phno+"</p></div>";
var icon = new BMap.Icon('http://lab-1.sketchdemos.com/P1091_IKMF/wp-content/themes/ikmf/images/map-marker.png', new BMap.Size(50, 62), 
{
				anchor: new BMap.Size(10, 30),
				infoWindowAnchor: new BMap.Size(10, 0)
});   
var infoWindow = new BMap.InfoWindow(sContent);
map.centerAndZoom(point,19);
var marker=new BMap.Marker(point,{
				icon: icon
				
		}); 
map.addOverlay(marker);
marker.setAnimation(BMAP_ANIMATION_DROP)
marker.addEventListener("click", function(){
		this.openInfoWindow(infoWindow);
		document.getElementById('imgDemo').onload = function (){
		infoWindow.redraw();
		}
		});
})})