<?php /* Template Name: Instructors Template */

get_header(); ?> 
    
    <div class="container inner-cont Instructors-page">
  
	  	<div class="ins-top-sec">
	  		<div class="Instructor-des">
	  			<img src="http://lab-1.sketchdemos.com/P1091_IKMF/wp-content/uploads/2018/05/1.jpg" alt="" class="img-responsive ins-img">
	  			<h3>Tang Fangyong</h3>
	  			<h5>Margaret Head of Israeli Martial Arts China</h5>
	  			<div class="ins-contact">
	  				<a href="tel: 185-0130-8157"><span><i class="fa fa-phone" aria-hidden="true"></i></span>185-0130-8157</a>
	  				<a href="mailto: info@ikmfchina.com"><span><i class="fa fa-envelope"></i></span>info@ikmfchina.com</a>
	  			</div>
	  		</div>
	  			

	  		<div class="level-search">	  			
				<label>		
					<select name="category" id="category" class="em-events-search-category">
						<option value="0" selected="selected">Level</option>
						<option class="level-0" value="18">Level E1</option>
						<option class="level-0" value="17">Level G5</option>
						<option class="level-0" value="16">Level G4</option>
						<option class="level-0" value="16">Level G3</option>
						<option class="level-0" value="16">Level G2</option>
						<option class="level-0" value="16">Level G1</option>
					</select>
				</label>
				<input type="submit" value="Search" class="ins-submit btn">
	  		</div>
	  		<div class="clearfix"></div>
	  	</div>

 		<div class="clearfix"></div>

 		<div class="instructor-div">
 			<div class="ins-head">
 				<h4><span>Level</span> : E1</h4>
 				<a href=#>View All</a>
 			</div>
 			<ul class="ins-ul">
 				<li>
 					<div class="inst-inr-div">
	 					<img src="http://lab-1.sketchdemos.com/P1091_IKMF/wp-content/uploads/2018/05/2.jpg" alt="" class="img-responsive ins-img">
	 					<h5 class="name">Wang Yanlin</h5>
	 					<h6 class="add">Beijing, <span>Jilin</span></h6>
 					</div>
 				</li>
 				<li>
 					<div class="inst-inr-div">
	 					<img src="http://lab-1.sketchdemos.com/P1091_IKMF/wp-content/uploads/2018/05/3.jpg" alt="" class="img-responsive ins-img">
	 					<h5 class="name">Liu Xlaoxu</h5>
	 					<h6 class="add">Beijing, <span>Jilin</span></h6>
 					</div>
 				</li>
 				<li>
 					<div class="inst-inr-div">
	 					<img src="http://lab-1.sketchdemos.com/P1091_IKMF/wp-content/uploads/2018/05/4.jpg" alt="" class="img-responsive ins-img">
	 					<h5 class="name">Xue Zhlgang</h5>
	 					<h6 class="add">Beijing, <span>Jilin</span></h6>
 					</div>
 				</li>
 				<li>
 					<div class="inst-inr-div">
	 					<img src="http://lab-1.sketchdemos.com/P1091_IKMF/wp-content/uploads/2018/05/5.jpg" alt="" class="img-responsive ins-img">
	 					<h5 class="name">Xlao Ylfu</h5>
	 					<h6 class="add">Beijing, <span>Jilin</span></h6>
 					</div>
 				</li>
 				<li>
 					<div class="inst-inr-div">
	 					<img src="http://lab-1.sketchdemos.com/P1091_IKMF/wp-content/uploads/2018/05/6.jpg" alt="" class="img-responsive ins-img">
	 					<h5 class="name">Hu Lihua</h5>
	 					<h6 class="add">Beijing, <span>Jilin</span></h6>
 					</div>
 				</li>
 			</ul>
 		</div>


 		<div class="clearfix"></div>

 		<div class="instructor-div">
 			<div class="ins-head">
 				<h4><span>Level</span> : G5</h4>
 				<a href=#>View All</a>
 			</div>
 			<ul class="ins-ul">
 				<li>
 					<div class="inst-inr-div">
	 					<img src="http://lab-1.sketchdemos.com/P1091_IKMF/wp-content/uploads/2018/05/2.jpg" alt="" class="img-responsive ins-img">
	 					<h5 class="name">Wang Yanlin</h5>
	 					<h6 class="add">Beijing, <span>Jilin</span></h6>
 					</div>
 				</li>
 				<li>
 					<div class="inst-inr-div">
	 					<img src="http://lab-1.sketchdemos.com/P1091_IKMF/wp-content/uploads/2018/05/3.jpg" alt="" class="img-responsive ins-img">
	 					<h5 class="name">Liu Xlaoxu</h5>
	 					<h6 class="add">Beijing, <span>Jilin</span></h6>
 					</div>
 				</li>
 				<li>
 					<div class="inst-inr-div">
	 					<img src="http://lab-1.sketchdemos.com/P1091_IKMF/wp-content/uploads/2018/05/4.jpg" alt="" class="img-responsive ins-img">
	 					<h5 class="name">Xue Zhlgang</h5>
	 					<h6 class="add">Beijing, <span>Jilin</span></h6>
 					</div>
 				</li>
 				<li>
 					<div class="inst-inr-div">
	 					<img src="http://lab-1.sketchdemos.com/P1091_IKMF/wp-content/uploads/2018/05/5.jpg" alt="" class="img-responsive ins-img">
	 					<h5 class="name">Xlao Ylfu</h5>
	 					<h6 class="add">Beijing, <span>Jilin</span></h6>
 					</div>
 				</li>
 				<li>
 					<div class="inst-inr-div">
	 					<img src="http://lab-1.sketchdemos.com/P1091_IKMF/wp-content/uploads/2018/05/6.jpg" alt="" class="img-responsive ins-img">
	 					<h5 class="name">Hu Lihua</h5>
	 					<h6 class="add">Beijing, <span>Jilin</span></h6>
 					</div>
 				</li>
 			</ul>
 		</div>


 		<div class="clearfix"></div>

 		<div class="instructor-div">
 			<div class="ins-head">
 				<h4><span>Level</span> : G4</h4>
 				<a href=#>View All</a>
 			</div>
 			<ul class="ins-ul">
 				<li>
 					<div class="inst-inr-div">
	 					<img src="http://lab-1.sketchdemos.com/P1091_IKMF/wp-content/uploads/2018/05/2.jpg" alt="" class="img-responsive ins-img">
	 					<h5 class="name">Wang Yanlin</h5>
	 					<h6 class="add">Beijing, <span>Jilin</span></h6>
 					</div>
 				</li>
 				<li>
 					<div class="inst-inr-div">
	 					<img src="http://lab-1.sketchdemos.com/P1091_IKMF/wp-content/uploads/2018/05/3.jpg" alt="" class="img-responsive ins-img">
	 					<h5 class="name">Liu Xlaoxu</h5>
	 					<h6 class="add">Beijing, <span>Jilin</span></h6>
 					</div>
 				</li>
 				<li>
 					<div class="inst-inr-div">
	 					<img src="http://lab-1.sketchdemos.com/P1091_IKMF/wp-content/uploads/2018/05/4.jpg" alt="" class="img-responsive ins-img">
	 					<h5 class="name">Xue Zhlgang</h5>
	 					<h6 class="add">Beijing, <span>Jilin</span></h6>
 					</div>
 				</li>
 				<li>
 					<div class="inst-inr-div">
	 					<img src="http://lab-1.sketchdemos.com/P1091_IKMF/wp-content/uploads/2018/05/5.jpg" alt="" class="img-responsive ins-img">
	 					<h5 class="name">Xlao Ylfu</h5>
	 					<h6 class="add">Beijing, <span>Jilin</span></h6>
 					</div>
 				</li>
 				<li>
 					<div class="inst-inr-div">
	 					<img src="http://lab-1.sketchdemos.com/P1091_IKMF/wp-content/uploads/2018/05/6.jpg" alt="" class="img-responsive ins-img">
	 					<h5 class="name">Hu Lihua</h5>
	 					<h6 class="add">Beijing, <span>Jilin</span></h6>
 					</div>
 				</li>
 			</ul>
 		</div>

 		<div class="clearfix"></div>

 		<div class="instructor-div">
 			<div class="ins-head">
 				<h4><span>Level</span> : G3</h4>
 				<a href=#>View All</a>
 			</div>
 			<ul class="ins-ul">
 				<li>
 					<div class="inst-inr-div">
	 					<img src="http://lab-1.sketchdemos.com/P1091_IKMF/wp-content/uploads/2018/05/2.jpg" alt="" class="img-responsive ins-img">
	 					<h5 class="name">Wang Yanlin</h5>
	 					<h6 class="add">Beijing, <span>Jilin</span></h6>
 					</div>
 				</li>
 				<li>
 					<div class="inst-inr-div">
	 					<img src="http://lab-1.sketchdemos.com/P1091_IKMF/wp-content/uploads/2018/05/3.jpg" alt="" class="img-responsive ins-img">
	 					<h5 class="name">Liu Xlaoxu</h5>
	 					<h6 class="add">Beijing, <span>Jilin</span></h6>
 					</div>
 				</li>
 				<li>
 					<div class="inst-inr-div">
	 					<img src="http://lab-1.sketchdemos.com/P1091_IKMF/wp-content/uploads/2018/05/4.jpg" alt="" class="img-responsive ins-img">
	 					<h5 class="name">Xue Zhlgang</h5>
	 					<h6 class="add">Beijing, <span>Jilin</span></h6>
 					</div>
 				</li>
 				<li>
 					<div class="inst-inr-div">
	 					<img src="http://lab-1.sketchdemos.com/P1091_IKMF/wp-content/uploads/2018/05/5.jpg" alt="" class="img-responsive ins-img">
	 					<h5 class="name">Xlao Ylfu</h5>
	 					<h6 class="add">Beijing, <span>Jilin</span></h6>
 					</div>
 				</li>
 				<li>
 					<div class="inst-inr-div">
	 					<img src="http://lab-1.sketchdemos.com/P1091_IKMF/wp-content/uploads/2018/05/6.jpg" alt="" class="img-responsive ins-img">
	 					<h5 class="name">Hu Lihua</h5>
	 					<h6 class="add">Beijing, <span>Jilin</span></h6>
 					</div>
 				</li>
 			</ul>
 		</div>

 		<div class="clearfix"></div>

 		<div class="instructor-div">
 			<div class="ins-head">
 				<h4><span>Level</span> : G2</h4>
 				<a href=#>View All</a>
 			</div>
 			<ul class="ins-ul">
 				<li>
 					<div class="inst-inr-div">
	 					<img src="http://lab-1.sketchdemos.com/P1091_IKMF/wp-content/uploads/2018/05/2.jpg" alt="" class="img-responsive ins-img">
	 					<h5 class="name">Wang Yanlin</h5>
	 					<h6 class="add">Beijing, <span>Jilin</span></h6>
 					</div>
 				</li>
 				<li>
 					<div class="inst-inr-div">
	 					<img src="http://lab-1.sketchdemos.com/P1091_IKMF/wp-content/uploads/2018/05/3.jpg" alt="" class="img-responsive ins-img">
	 					<h5 class="name">Liu Xlaoxu</h5>
	 					<h6 class="add">Beijing, <span>Jilin</span></h6>
 					</div>
 				</li>
 				<li>
 					<div class="inst-inr-div">
	 					<img src="http://lab-1.sketchdemos.com/P1091_IKMF/wp-content/uploads/2018/05/4.jpg" alt="" class="img-responsive ins-img">
	 					<h5 class="name">Xue Zhlgang</h5>
	 					<h6 class="add">Beijing, <span>Jilin</span></h6>
 					</div>
 				</li>
 				<li>
 					<div class="inst-inr-div">
	 					<img src="http://lab-1.sketchdemos.com/P1091_IKMF/wp-content/uploads/2018/05/5.jpg" alt="" class="img-responsive ins-img">
	 					<h5 class="name">Xlao Ylfu</h5>
	 					<h6 class="add">Beijing, <span>Jilin</span></h6>
 					</div>
 				</li>
 				<li>
 					<div class="inst-inr-div">
	 					<img src="http://lab-1.sketchdemos.com/P1091_IKMF/wp-content/uploads/2018/05/6.jpg" alt="" class="img-responsive ins-img">
	 					<h5 class="name">Hu Lihua</h5>
	 					<h6 class="add">Beijing, <span>Jilin</span></h6>
 					</div>
 				</li>
 			</ul>
 		</div>

 		<div class="clearfix"></div>

 		<div class="instructor-div">
 			<div class="ins-head">
 				<h4><span>Level</span> : G1</h4>
 				<a href=#>View All</a>
 			</div>
 			<ul class="ins-ul">
 				<li>
 					<div class="inst-inr-div">
	 					<img src="http://lab-1.sketchdemos.com/P1091_IKMF/wp-content/uploads/2018/05/2.jpg" alt="" class="img-responsive ins-img">
	 					<h5 class="name">Wang Yanlin</h5>
	 					<h6 class="add">Beijing, <span>Jilin</span></h6>
 					</div>
 				</li>
 				<li>
 					<div class="inst-inr-div">
	 					<img src="http://lab-1.sketchdemos.com/P1091_IKMF/wp-content/uploads/2018/05/3.jpg" alt="" class="img-responsive ins-img">
	 					<h5 class="name">Liu Xlaoxu</h5>
	 					<h6 class="add">Beijing, <span>Jilin</span></h6>
 					</div>
 				</li>
 				<li>
 					<div class="inst-inr-div">
	 					<img src="http://lab-1.sketchdemos.com/P1091_IKMF/wp-content/uploads/2018/05/4.jpg" alt="" class="img-responsive ins-img">
	 					<h5 class="name">Xue Zhlgang</h5>
	 					<h6 class="add">Beijing, <span>Jilin</span></h6>
 					</div>
 				</li>
 				<li>
 					<div class="inst-inr-div">
	 					<img src="http://lab-1.sketchdemos.com/P1091_IKMF/wp-content/uploads/2018/05/5.jpg" alt="" class="img-responsive ins-img">
	 					<h5 class="name">Xlao Ylfu</h5>
	 					<h6 class="add">Beijing, <span>Jilin</span></h6>
 					</div>
 				</li>
 				<li>
 					<div class="inst-inr-div">
	 					<img src="http://lab-1.sketchdemos.com/P1091_IKMF/wp-content/uploads/2018/05/6.jpg" alt="" class="img-responsive ins-img">
	 					<h5 class="name">Hu Lihua</h5>
	 					<h6 class="add">Beijing, <span>Jilin</span></h6>
 					</div>
 				</li>
 			</ul>
 		</div>



    </div>




    
<?php get_footer(); ?>
