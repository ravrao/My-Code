<?php /* Template Name: Event Booking Template */
get_header(); ?> 
    
    <div class="container inner-cont">
  <div class="row">
        <div class="col-sm-12 col-xs-12">
            <div class="title"><span><?php the_title();?></span></div>
        </div>
    </div>

 <?php echo do_shortcode('[event]#_BOOKINGFORM[/event]'); ?>
<section class="faq-section">
    <div class="container">
        <div class="row">
        <div class="col-md-12 col-sm-12 col-xs-12">
         
        </div>
        </div>
        
      
    </div>
</section>



    </div>




    
<?php get_footer(); ?>
