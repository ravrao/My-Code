<?php
/**
 * The template for displaying all single posts and attachments
 *
 * @package WordPress
 * @subpackage Twenty_Sixteen
 * @since Twenty Sixteen 1.0
 */
get_header(); ?>
<?php  $rs=$post->ID;?>
<?php
$terms = get_the_terms( get_the_ID(), 'courses' );
$catname = $terms[0]->name;
?>
 <div class="container inner-cont">

<?php
// Start the loop.
while ( have_posts() ) : the_post(); ?>
    <div class="row">
        <div class="col-sm-12 col-xs-12">
            <div class="title ins-detail"><?php the_title();?></div>
        </div>
    </div>
     <!--<div class="catname"><h3>Courses Name: <?php //echo $catname;?></h3></div>-->
<?php		
        the_content();

    endwhile;
    ?>

<?php  $page_lang = ICL_LANGUAGE_CODE;?>
  
<?php $postchecks =get_field('our_team_listing', false, false);  ?>
<?php if($postchecks!=''){?>      
<div id="common">
    <?php   $page_lang = ICL_LANGUAGE_CODE;?>
   <?php if($page_lang=='en') { ?>
    <h3>Our Instructors</h3>
   <?php } else {?>
    <h3>教官</h3>
   <?php } ?>     
  

<?php //$posts = $ids = get_field('our_team_listing', false, false); ?>
<?php $posts = get_field('our_team_listing',$post->ID, false, false); //var_dump($posts); ?> 
<?php $arrangedPosts = array(); $combinedPosts = array(); ?>
<?php 
foreach($posts as $instrId){ 
	$instrLevel = get_the_terms($instrId, 'level'); 
	$ordr = get_field('custom_order', 'level'.'_'.$instrLevel[0]->term_id); //var_dump($ordr); 
	if( $arrangedPosts[$ordr] == NULL ){ 
	   $arrangedPosts[$ordr] = array(); array_push($arrangedPosts[$ordr], $instrId); 
	} else { array_push($arrangedPosts[$ordr], $instrId); }
}   
$keys = array_keys($arrangedPosts); sort($keys, SORT_NUMERIC); //var_dump($keys);
foreach($keys as $key){ $narray = $arrangedPosts[$key]; $combinedPosts = array_merge($combinedPosts, $narray); } ?>
<?php $course_instructors = array(); ?>
<?php //foreach($posts as $instrId){ 
	foreach($combinedPosts as $instrId){ 
	$instrLevel = get_the_terms($instrId, 'level'); //var_dump($instrLevel);
	if(!array_key_exists($instrLevel[0]->name, $course_instructors)){
            $course_instructors[$instrLevel[0]->name] = $instrId;
        } else {
	    $values = $course_instructors[$instrLevel[0]->name]; 
	    $values .= ','.$instrId;
	    $course_instructors[$instrLevel[0]->name] = $values;
        }} ?>

<ul class="inner-ul gym-locate">
<?php foreach($course_instructors as $key => $values){ ?>
 <?php if($page_lang=='en'){?>
    <h4 class="sub-heading"><span><?php echo 'Level: '. $key; ?></span></h4>
 <?php } else {?>
    <h4 class="sub-heading"><span><?php echo '级别: '. $key; ?></span></h4>
 <?php } ?>
 <?php $valArr = explode(',',$values);
 foreach($valArr as $valId){ $instrpost = get_post($valId); ?>
 <li><a href="<?php echo $instrpost->guid;?>"><?php echo $instrpost->post_title;?></a></li>
 <?php } ?>
<?php } ?>
</ul>
</div>  

 <?php } ?>
     
</div>
<?php get_footer(); ?>
