<?php /* Template Name: Show All Template */

get_header(); ?> 
    
<div id="common" class="container inner-cont Instructors-page">
  
	  	<div class="row">
        <div class="col-sm-12 col-xs-12">
            <div class="title ins-detail"><span><?php the_title();?></span></div>
        </div>
    </div>

 		<div class="clearfix"></div>
                
               <?php
                $level=get_categories(array('taxonomy' => 'level', 'orderby' => 'ID', 'order' => 'ASC','hide_empty'=>0));
                foreach($level as $lvalue)
                {
                ?> 
              
 		<div class="instructor-div">
 			<div class="ins-head_inst">
 				<h4><span>Level</span> : <?php echo $lvalue->name;?></h4>
 				
 			</div>
 			<ul class="inner-ul">
                       
                            <?php
                            $args= array(
                            'post_type' => 'our_team', 
                            'posts_per_page'   => -1,
                            'orderby'          => 'post_date',
                            'order'            => 'DESC',
                            'post_status'      => 'publish',
                            'tax_query' => array(
                                array(
                                   'taxonomy' => 'level',
                                   'field' => 'term_id',
                                   'terms' =>  $lvalue->term_id,
                                   'include_children' => false 

                                )
                            )
                            );
                        
                           $query=new WP_Query($args); 
                            if( $query->have_posts() ): while ( $query->have_posts() ) : $query->the_post(); 
                             $feat_image = wp_get_attachment_url( get_post_thumbnail_id($post->ID) );
                              $state = get_the_terms( $post->ID, 'state');  //var_dump($categories);
                              $sname= $state[0]->name;
                   
                    ?> 
                            <li>
                                
                                    
                                    <a href="<?php the_permalink(); ?>"> <?php the_title();?></a>
                                      
                               
                            </li>
                            <?php endwhile; endif;?> 
 				
 			</ul>
 		</div>
                <div class="clearfix"></div>
                   <?php };
             
                ?>

 		

 		


    </div>




    
<?php get_footer(); ?>
