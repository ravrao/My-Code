<?php /* Template Name: faqs Template */
get_header(); ?> 
    
    <div class="container inner-cont">
  <div class="row">
        <div class="col-sm-12 col-xs-12">
            <div class="title ins-detail"><span><?php the_title();?></span></div>
        </div>
    </div>

 
<section class="faq-section">
    <div class="container">
        <div class="row">
        <div class="col-md-12 col-sm-12 col-xs-12">
        <div class="panel-group" id="accordion" role="tablist" aria-multiselectable="true">
          
        <?php
           query_posts( array(
           'post_type' => 'faqe', 
           'posts_per_page' => 20,   
           )); 
           $k=1;
           if( have_posts() ): while ( have_posts() ) : the_post(); 
            $testi_feat_image = wp_get_attachment_url( get_post_thumbnail_id($post->ID) ); 
        ?> 
            <div class="panel panel-default">
                <div class="panel-heading" role="tab" id="heading<?php echo $k;?>">
                     <h4 class="panel-title">
                <a class="collapsed" data-toggle="collapse" data-parent="#accordion" href="#collapse<?php echo $k;?>" aria-expanded="true" aria-controls="collapse<?php echo $k;?>">
                 <?php the_title();?>
                </a>
              </h4>

                </div>
                <div id="collapse<?php echo $k;?>" class="panel-collapse collapse <?php if($k==1) { ?>in<?php } ?>" role="tabpanel" aria-labelledby="heading<?php echo $k;?>">
                    <div class="panel-body">
                        <?php the_content();?>
                    </div>
                </div>
            </div>
            
        <?php
        $k++;
           endwhile; ?>
           <?php endif; 
        ?>     
            
           
            
        </div>
        </div>
        </div>
        
      
    </div>
</section>



    </div>




    
<?php get_footer(); ?>
