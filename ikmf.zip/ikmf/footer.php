

 <!-- FOOTER SECTION START-->
    <footer>
        <div class="container">
            <div class="row">
                <?php  $page_lang = ICL_LANGUAGE_CODE;?>
                 <?php $the_query = new WP_Query( 'page_id=588' ); ?>
                <?php while ($the_query -> have_posts()) : $the_query -> the_post();  
                $content = get_the_content();
                $about_feat_image = wp_get_attachment_url( get_post_thumbnail_id($post->ID) ); 
                ?>
                <div class="col-sm-3 col-xs-12">
                    <a href="<?php echo get_page_link(588); ?>#common"><h4> <?php echo get_post_meta($post->ID, 'footer_title', true); ?></h4></a>
                    <p> <?php echo get_post_meta($post->ID, 'footer_content', true); ?></p>
                </div>
                <?php endwhile; ?>
                <div class="col-sm-3 col-xs-12">
                    <a href="<?php echo get_page_link(27); ?>#common"><h4>  <?php if($page_lang=='en') { ?>Contact us<?php } else { ?> 联系我们 <?php } ?></h4></a>
                    <?php if($page_lang=='en'){ ?>
                    <p><?php echo get_option('jetbuzz_desc');?></p>
                    <?php } else {?>
                    <p><?php echo get_option('jetbuzz_desc_ch');?></p>
                    <?php } ?>
                    <ul>
                        <li><span><i class="fa fa-comments"></i></span><a href="#"><?php echo get_option('jetbuzz_wechat_text');?></a></li>
                        <li><span><i class="fa fa-envelope"></i></span><a href="mailto:<<?php echo get_option('jetbuzz_footemail');?>"><?php echo get_option('jetbuzz_footemail');?></a></li>
                        <li><span><i class="fa fa-mobile"></i></span><a href="tel:<?php echo get_option('jetbuzz_phone1');?>"><?php echo get_option('jetbuzz_phone1');?></a></li>
                        <li><span><i class="fa fa-mobile"></i></span><a href="tel:<?php echo get_option('jetbuzz_phone2');?>"><?php echo get_option('jetbuzz_phone2');?></a></li>                    
                    </ul>
                </div>
                <div class="col-sm-3 col-xs-12">
                    <?php if($page_lang=='en') { ?>
                    <h4>Wechat QR code</h4>
                    <?php } else {?>
                    <h4>微信二维码</h4>
                    <?php } ?>
                    <div class="qr-code">
                        <img src="<?php echo get_option('jetbuzz_weimage');?>" />
                    </div>
                    <p><a href="https://ikmfchina.world.taobao.com/" target="_blank;"><img src="<?php echo get_template_directory_uri(); ?>/images/game-logo.png" class="game-logo" /></a>
                    <?php if($page_lang=='en'){ ?>
                        <?php echo get_option('jetbuzz_wedesc');?>
                    <?php } else {?>
                    <?php echo get_option('jetbuzz_wedesc_ch');?>
                    <?php } ?></p>
                </div>
                
                 <div class="col-sm-3 col-xs-12">
                     <?php if($page_lang=='en') { ?>
                    <h4>Get in Touch</h4>
                    <div class="get-form">
                        <?php echo do_shortcode('[contact-form-7 id="96" title="Get in Touch"]')?>
                    </div>
                     <?php } 
                     else { ?>
                    <h4>保持联系</h4>
                    <div class="get-form">
                        <?php echo do_shortcode('[contact-form-7 id="1446" title="Get in Touch"]')?>
                    </div>
                      <?php } ?>
                </div>
            </div>
        </div>
    </footer>
    <!-- FOOTER SECTION END-->
    
    <!-- BOTTOM SECTION END-->
    <section class="bottom-section text-center">
        <div class="container">
            <div class="row">
                <div class="col-sm-12 col-xs-12">
                   
                    <?php
                $Footer = array(
                'theme_location'  => '',
                'menu'            => 'Footer',
                'container'       => '',
                'container_class' => '',
                'container_id'    => '',
                'menu_class'      => '',
                'menu_id'         => '',
                'echo'            => true,
                'fallback_cb'     => 'wp_page_menu',
                'before'          => '',
                 'after'           => '',
                'link_before'     => '',
                'link_after'      => '',
                'items_wrap'      => '<ul class="">%3$s</ul>',
                'depth'           => 0,
                'walker'          => ''
                );

                wp_nav_menu( $Footer );
                ?>
                </div>
                <div class="col-sm-12 col-xs-12">
                    <?php if($page_lang=='en'){ ?>
                    <p><?php echo get_option('jetbuzz_copyright');?></p>
                    <p><?php echo get_option('jetbuzz_fotdesc');?></p>
                    <?php } else {?>
                    <p><?php echo get_option('jetbuzz_copyright_ch');?></p>
                    <p><?php echo get_option('jetbuzz_fotdesc_ch');?></p>
                    <?php } ?>
                </div>
                <div class="col-sm-12 col-xs-12">
                    <div class="browser-section">
                        <a href="<?php echo get_option('jetbuzz_weibo');?>" target="_blank;"><img src="<?php echo get_template_directory_uri(); ?>/images/browse-logo1.png" alt=""></a>
                        <a href="<?php echo get_option('jetbuzz_iconlink1');?>" target="_blank;"><img src="<?php echo get_template_directory_uri(); ?>/images/browse-logo2.png" alt=""></a>
                        <a href="<?php echo get_option('jetbuzz_iconlink2');?>" target="_blank;"><img src="<?php echo get_template_directory_uri(); ?>/images/browse-logo3.png" alt=""></a>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- BOTTOM SECTION END-->
<!-- jQuery -->
    <script src="<?php echo get_template_directory_uri(); ?>/js/jquery.min.js"></script>    <!-- Bootstrap Core JavaScript -->
    <script src="<?php echo get_template_directory_uri(); ?>/js/bootstrap.min.js"></script>    
   
<!--    <script src='js/slim.min.js'></script>-->


        <!-- FOR GALLERY -->

     
    <script src="<?php echo get_template_directory_uri(); ?>/js/owl.carousel.js"></script>
    <script src="<?php echo get_template_directory_uri(); ?>/js/wow.js"></script>
    <script src="<?php echo get_template_directory_uri(); ?>/js/main.js"></script>
    <script src="<?php echo get_template_directory_uri(); ?>/js/jQuery.verticalCarousel.js"></script>
    <script src="<?php echo get_template_directory_uri(); ?>/js/slick.js"></script>
  
<!--Lateste news slider -->
<script>
    $(".recentArticles").verticalCarousel({
        currentItem: 1,
        showItems: 2,
    });

    window.setInterval(function(){
    if ( $('.vc_goDown').hasClass('isDisabled') ) {
         $('.vc_goUp').trigger('click');
    } else {
         $('.vc_goDown').trigger('click');
    }
     }, 5000);


</script>   
    <script>

 admin_ajax="<?php echo admin_url( 'admin-ajax.php' ); ?>";
 
         $('.owlOne').owlCarousel({
            loop:true,
            margin:20,
            autoplay: true,
             dots: false,
            nav:true,
            navText : ['<i class="fa fa-chevron-left" aria-hidden="true"></i>','<i class="fa fa-chevron-right" aria-hidden="true"></i>'], 
            responsive:{
                0:{
                    items:1
                },
                600:{
                    items:1
                },
                1000:{
                    items:1
                }
            }
        });
        
        $('.owlTwo').owlCarousel({
            loop:true,
            margin:20,
            autoplay: true,
             dots: false,
            nav:true,
            navText : ['<i class="fa fa-chevron-left" aria-hidden="true"></i>','<i class="fa fa-chevron-right" aria-hidden="true"></i>'], 
            responsive:{
                0:{
                    items:1
                },
                600:{
                    items:2
                },
                1000:{
                    items:3
                }
            }
        });
        $('.owlThree').owlCarousel({
            loop:false,
            margin:20,
            autoplay: true,
             dots: false,
            nav:true,
            navText : ['<i class="fa fa-chevron-left" aria-hidden="true"></i>','<i class="fa fa-chevron-right" aria-hidden="true"></i>'], 
            responsive:{
                0:{
                    items:1
                },
                600:{
                    items:2
                },
                1000:{
                    items:3
                }
            }
        });
        
        $('html, body').hide();

                if (window.location.hash) {
                    setTimeout(function() {
                        $('html, body').scrollTop(0).show();
                        $('html, body').animate({
                            scrollTop: $(window.location.hash).offset().top - hdheight
                            }, 1000)
                    }, 0);
                }
                else {
                    $('html, body').show();
                }
        
        var hdheight = $('.top-section').height();
 
                var common = $('#common');
                if(common.length){
                   
                    $(".top-section a").on('click', function(event) {
                         //if (this.hash !== "") {
                        var toppos = common.offset().top - hdheight;
                        $('html,body').animate({
                            scrollTop:toppos
                        },'slow');
                        //}
                    });
       
                }
    </script>

<script>
$(document).ready(function() {
   var owl = $('.owl-carousel-news');
   owl.owlCarousel({
     autoplay: true,
     items: 1,
     nav: true,
      navText: ["<span class='icon fa fa-angle-left'></span>","<span class='icon fa fa-angle-right'></span>"],
     loop: true,
     autoplayHoverPause: true,
     animateOut: 'slideOutUp',
     animateIn: 'slideInUp',
     autoplayTimeout: 5000,
     autoplayHoverPause: false,
   });
 
 
$(function(){
  var hash = window.location.hash;
  hash && $('ul.nav a[href="' + hash + '"]').tab('show');

  $('.nav-pills a').click(function (e) {
    $(this).tab('show');
    var scrollmem = $('body').scrollTop();
    window.location.hash = this.hash;
    $('html,body').scrollTop(scrollmem);
  });
});
       
$(".login-btn").appendTo(".main-menu .navbar-nav");

var urlstr = window.location.href;
if(urlstr.indexOf("?login=failed") > 0){ 
    $('#bookingModal').css('z-index', '999999999');
    $(".event-detail-btn a.poupopen").trigger('click');
}

 $(".vertical").slick({
        dots: true,
        vertical: true,
        slidesToShow: 2,
        slidesToScroll: 2,
        dots: false,
        autoplay: true,
        infinite: true,
        speed: 4000,
      });
      
 ///////// Search gym location //////////
 
    $("#provincserch").change(function(){ 
       
     var allgymnamesearch = $(this).val(); 
     //alert(allgymnamesearch);
      var dataString = "allgymnamesearch="+allgymnamesearch; 
     
       $.ajax({
        type:"POST",
        url:admin_ajax,
        data:{"action":"showsearch_gymname","allgymnamesearch":allgymnamesearch},
        success:function(result){
            //$(".autoPopulate").html(result)
             $("#1stload").hide();
        setTimeout(function () {    
          $("#resultgetgym").html(result); 
      });
        }
    });

    });
    
   
});

</script> 
<?php 
$page_lang = ICL_LANGUAGE_CODE;
if($page_lang=='en') {?>   
<script src="<?php echo get_template_directory_uri(); ?>/js/autocomplete.js"></script> 
<?php } else {?>
<script src="<?php echo get_template_directory_uri(); ?>/js/autocomplete_ch.js"></script> 
<?php } ?>
    
    
<!-- Modal -->
<div class="modal fade" id="calendarModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document" style="width:1100px;">
    <div class="modal-content">
     
      <div class="modal-body">
      <?php echo do_shortcode('[events_calendar long_events=1 full=1]');?>
      </div>
      
    </div>
  </div>
</div>       
<!-- End Model -->


<!-- Login Modal -->
<div class="modal fade" id="LoginModel" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document" style="width:1100px;">
    <div class="modal-content">
     
      <div class="modal-body">
      <?php echo do_shortcode('[simple-login-form]')?>
      </div>
      
    </div>
  </div>
</div> 
<!-- Login End Model -->
<?php wp_footer(); ?>
</body>
</html>
