<?php
/**
 * The template for displaying all single posts and attachments
 *
 * @package WordPress
 * @subpackage Twenty_Sixteen
 * @since Twenty Sixteen 1.0
 */

get_header(); ?>



 <div class="container inner-cont instructor-detail">

		<?php
		// Start the loop.
		while ( have_posts() ) : the_post();
                $feat_image = wp_get_attachment_url( get_post_thumbnail_id($post->ID) ); 
                ?>
    <div class="row">
        <div class="col-sm-12 col-xs-12">
            <div class="title ins-detail"><?php the_title();?>
            <?php
            $state = get_the_terms( $post->ID, 'state');  //var_dump($categories);
            $sname= $state[0]->name;    
            ?>
            
            </div>
        </div>
    </div>

<div class="row">
  <div class="col-md-3 col-sm-5 col-xs-12">
     <div class="Instructor-des innerteam">
            <img src="<?php echo $feat_image;?>" alt="" class="img-responsive ins-img">
             
            <h4 class="text-center"><?php echo $sname;?>: <?php echo get_post_meta($post->ID, 'position', true); ?></h4>

                <div class="ins-head">
                    <h4><span>Level</span> :  <?php $categories = get_the_terms( $post->ID, 'level'); echo $taxnam = $categories[0]->name; ?></h4>
                </div>
            <div class="ins-contact text-center">
                    <a href="tel: <?php echo get_post_meta($post->ID, 'phone', true); ?>"><span><i class="fa fa-phone" aria-hidden="true"></i></span><?php echo get_post_meta($post->ID, 'phone', true); ?></a>
                    <a href="mailto: <?php echo get_post_meta($post->ID, 'email', true); ?>"><span><i class="fa fa-envelope"></i></span><?php echo get_post_meta($post->ID, 'email', true); ?></a>
            </div>
    </div>
  </div>

  <div class="col-md-9 col-sm-7 col-xs-12">
    <?php		
        the_content();

    endwhile;
    ?>
 </div>
  
</div>

<!-- <div id="common" class="container inner-cont">
   <?php $the_query = new WP_Query( 'page_id=17' ); ?>
    <?php while ($the_query -> have_posts()) : $the_query -> the_post();  
       ?>     
  <div class="row">
        <div class="col-sm-12 col-xs-12">
            <div class="title"><span><?php echo get_post_meta($post->ID, 'big_title', true); ?></span></div>
        </div>
    </div>
 <?php endwhile;?> 
     
     
<?php 

 $posts = $ids = get_field('our_team_listing', false, false);

//var_dump($posts);?>
   
     
 
<section class="faq-section">
    <div class="container">
        <div class="row">
        <div class="col-md-12 col-sm-12 col-xs-12 courseTab">
        <div class="panel-group" id="accordion" role="tablist" aria-multiselectable="true">
          <div class="row">
        <?php
           query_posts( array(
           'post_type' => 'our_course', 
           'posts_per_page' => 9,   
           )); 
           $k=1;
           if( have_posts() ): while ( have_posts() ) : the_post(); 
            $testi_feat_image = wp_get_attachment_url( get_post_thumbnail_id($post->ID) ); 
            $categories = get_the_terms( $post->ID, 'courses');
        ?> 
        
            <div class="item col-md-4">
                <div class="img-box">

                    <img src="<?php echo $testi_feat_image;?>" alt="" class="img-responsive">
                </div>
                <div class="info">
                    <a href="<?php the_permalink(); ?>"><div class="heading"><?php the_title();?></div></a>
                    <a href="<?php echo bloginfo('url')?>/course/<?php echo $categories[0]->slug;?>"><div class="catname">Category: <?php echo $categories[0]->name;?></div></a>
                   <?php the_excerpt();?>                              
                </div>                         
            </div>
           
        <?php
        $k++;
           endwhile; ?>
           <?php endif; 
        ?>     
             </div>
           
            
        </div>
        </div>
        </div>
        
      
    </div>
</section>



    </div>-->

    
     
     
     
     
</div>

<?php get_footer(); ?>
