<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

    <title><?php bloginfo(''); ?></title>

    <!-- Favicon placement -->

<!--    <link rel="icon" href="<?//php echo get_field('favicon',65); ?>" type="image/x-icon"/>-->

    <!-- Bootstrap Core CSS -->
    <link href="<?php echo get_template_directory_uri(); ?>/css/bootstrap.min.css" rel="stylesheet">

    <!-- Custom CSS -->
    <link href="<?php echo get_template_directory_uri(); ?>/css/style.css" rel="stylesheet">
    <link href="<?php echo get_template_directory_uri(); ?>/css/responsive.css" rel="stylesheet">    
    <link href="<?php echo get_template_directory_uri(); ?>/css/animate.min.css" rel="stylesheet">
    <link rel="stylesheet" href="<?php echo get_template_directory_uri(); ?>/css/owl.carousel.min.css">
    <link rel="stylesheet" href="<?php echo get_template_directory_uri(); ?>/css/owl.theme.default.min.css">
    
    <!-- GALLERY CSS -->
  
    
   

    <!-- Custom Fonts -->
    <link href="<?php echo get_template_directory_uri(); ?>/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">    
    <link href="https://fonts.googleapis.com/css?family=Raleway:300,400,500,600,700,800,900" rel="stylesheet">

    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
        <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->
    <?php wp_head(); ?>
</head>

<body <?php body_class(); ?>>
    
    
    <section class="top-section">
        <div class="container">
            <div class="row">
                <div class="col-sm-6 col-xs-6">
                    <p><i class="fa fa-envelope"></i><a href="#">ikmfinfo@gmail.com</a></p>
                </div>
                <div class="col-sm-6 col-xs-6 text-right">
                    <div class="lang">
                        <img src="<?php echo get_template_directory_uri(); ?>/images/language.jpg" alt="">
                    </div>
                    <div class="browser-section">
                        <a href="#"><img src="<?php echo get_template_directory_uri(); ?>/images/browse-logo1.png" alt=""></a>
                        <a href="#"><img src="<?php echo get_template_directory_uri(); ?>/images/browse-logo2.png" alt=""></a>
                        <a href="#"><img src="<?php echo get_template_directory_uri(); ?>/images/browse-logo3.png" alt=""></a>
                    </div>
                    
                </div>
            </div>
        </div>
    </section>

 <!-- HEADER SECTION END -->
 <nav class="navbar navbar-default main-menu wow fadeInDown">
            <div class="container">
              <!-- Brand and toggle get grouped for better mobile display -->
                <div class="navbar-header">
                    <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" aria-expanded="false">
                      <span class="sr-only">Toggle navigation</span>
                      <span class="icon-bar"></span>
                      <span class="icon-bar"></span>
                      <span class="icon-bar"></span>
                    </button>
                      <a class="navbar-brand" href="#"><img src="<?php echo get_template_directory_uri(); ?>/images/logo.png" alt=""></a>
                </div>
              
              
                <div class="header-rht"> 
                    <!-- Collect the nav links, forms, and other content for toggling -->
                    <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
                      <ul class="nav navbar-nav navbar-right">                       
                       
                        <li class="active dropdown dropdown-submenu">
                            <a href="#" class="dropdown-toggle" data-toggle="dropdown">KRAV MAGA  <b class="caret"></b></a>
                            <ul class="dropdown-menu">
                                    <li><a href="#">Demo-1</a></li>
                                    <li><a href="#">Demo-2</a></li>
                                    <li><a href="#">Demo-3</a></li>
                                    <li><a href="#">Demo-4</a></li>
                            </ul>
                        </li>
                        <li class="dropdown dropdown-submenu">
                            <a href="#" class="dropdown-toggle" data-toggle="dropdown">IKMF <b class="caret"></b></a>
                            <ul class="dropdown-menu">
                                    <li><a href="#">Demo-1</a></li>
                                    <li><a href="#">Demo-2</a></li>
                                    <li><a href="#">Demo-3</a></li>
                                    <li><a href="#">Demo-4</a></li>
                            </ul>
                        </li>
                        <li class="dropdown dropdown-submenu">
                            <a href="#" class="dropdown-toggle" data-toggle="dropdown">Courses <b class="caret"></b></a>
                            <ul class="dropdown-menu">
                                    <li><a href="#">Demo-1</a></li>
                                    <li><a href="#">Demo-2</a></li>
                                    <li><a href="#">Demo-3</a></li>
                                    <li><a href="#">Demo-4</a></li>
                            </ul>
                        </li>
                         <li class="dropdown dropdown-submenu">
                            <a href="#" class="dropdown-toggle" data-toggle="dropdown">Locations <b class="caret"></b></a>
                            <ul class="dropdown-menu">
                                    <li><a href="#">Demo-1</a></li>
                                    <li><a href="#">Demo-2</a></li>
                                    <li><a href="#">Demo-3</a></li>
                                    <li><a href="#">Demo-4</a></li>
                            </ul>
                        </li>
                        <li><a href="#">Our Team</a></li>
                        <li class="dropdown dropdown-submenu">
                            <a href="#" class="dropdown-toggle" data-toggle="dropdown">Events <b class="caret"></b></a>
                            <ul class="dropdown-menu">
                                    <li><a href="#">Demo-1</a></li>
                                    <li><a href="#">Demo-2</a></li>
                                    <li><a href="#">Demo-3</a></li>
                                    <li><a href="#">Demo-4</a></li>
                            </ul>
                        </li>
                        <li><a href="#">News &amp; Media</a></li>
                        <li><a href="#">Contact Us</a></li>
                        <li><a href="#" class="login-btn"> Login</a></li>
                        
                      </ul>
                    </div><!-- /.navbar-collapse -->
                </div>    
                
            </div><!-- /.container-fluid -->
        </nav>
        
    <!-- HEADER SECTION START -->     
    
    
    
    