<!DOCTYPE html>
<html lang="en">

<head>

    <meta http-equiv="content-type" content="text/html;charset=utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

    <title><?php bloginfo(''); ?></title>

    <!-- Favicon placement -->

<!--    <link rel="icon" href="<?//php echo get_field('favicon',65); ?>" type="image/x-icon"/>-->

    <!-- Bootstrap Core CSS -->
    <link href="<?php echo get_template_directory_uri(); ?>/css/bootstrap.min.css" rel="stylesheet">

    <!-- Custom CSS -->
    <link href="<?php echo get_template_directory_uri(); ?>/css/style.css" rel="stylesheet">
    <link href="<?php echo get_template_directory_uri(); ?>/css/responsive.css" rel="stylesheet">    
    <link href="<?php echo get_template_directory_uri(); ?>/css/animate.min.css" rel="stylesheet">
    <link rel="stylesheet" href="<?php echo get_template_directory_uri(); ?>/css/owl.carousel.min.css">
    <link rel="stylesheet" href="<?php echo get_template_directory_uri(); ?>/css/owl.theme.default.min.css">
    <link rel="stylesheet" href="<?php echo get_template_directory_uri(); ?>/css/jQuery.verticalCarousel.css">
    <link rel="stylesheet" href="<?php echo get_template_directory_uri(); ?>/css/vertical-style.css">
    <link rel="stylesheet" href="<?php echo get_template_directory_uri(); ?>/css/lightgallery.css">
    
    <!-- GALLERY CSS -->
  
    
   

    <!-- Custom Fonts -->
    <link href="<?php echo get_template_directory_uri(); ?>/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">    
<!--    <link href="https://fonts.googleapis.com/css?family=Raleway:300,400,500,600,700,800,900" rel="stylesheet">-->
    <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,400,600,700,800" rel="stylesheet">

    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
        <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->
    <?php wp_head(); ?>
</head>

<body <?php body_class(); ?>>
 
 <script type="text/javascript">
 
//check if hash tag exists in the URL
if(window.location.hash) {
 
 //set the value as a variable, and remove the #
 var hash_value = window.location.hash.replace('#', '');
 
 //show the value with an alert pop-up
 //alert(hash_value);
 if(hash_value=='em-bookingsucess')
 {
     window.location.href="<?php bloginfo('url')?>/dashboard/#menu2";
 }
}

</script>
<?php   $page_lang = ICL_LANGUAGE_CODE;?>
    <section class="top-section">
        <div class="container">
            <div class="row">
                <div class="col-sm-6 col-xs-12">
                    <p><i class="fa fa-envelope"></i><a href="mailto:<?php echo get_option('jetbuzz_email');?>"><?php echo get_option('jetbuzz_email');?></a></p>
                </div>
                <div class="col-sm-6 col-xs-12 text-right">
                     <?php if($page_lang=='en') { ?>
                    
                     <?php if ( is_user_logged_in() ) { ?> 
                    <div class="mylogout">
                    <div class="lang myacc">
                        <a href="<?php bloginfo('url')?>/dashboard/">My Account</a>
                    </div>
                    <div class="lang myacc">
                       <a title="Login" href="<?php echo wp_logout_url( home_url() ); ?>" >Logout</a>
                    </div>
                    </div>
                     <?php } else {?>
                     <div class="mylogout">
                    <div class="lang myacc">
                        <a href="<?php bloginfo('url')?>/register/">Register</a>
                    </div>
                    <div class="lang myacc">
                       <a title="Login" href="#" data-toggle="modal" data-target="#LoginModel">Login</a>
                    </div>
                     </div>
                     <?php } ?>
                    
                     <?php }else { ?>
                    <?php if ( is_user_logged_in() ) { ?> 
                    <div class="mylogout">
                    <div class="lang myacc">
                        <a href="<?php bloginfo('url')?>/dashboard/">我的账户</a>
                    </div>
                    <div class="lang myacc">
                       <a title="Login" href="<?php echo wp_logout_url( home_url() ); ?>" >退出登录</a>
                    </div>
                    </div>
                     <?php } else {?>
                     <div class="mylogout">
                    <div class="lang myacc">
                        <a href="<?php echo get_page_link(1118); ?>/">注册</a>
                    </div>
                    <div class="lang myacc">
                       <a title="Login" href="#" data-toggle="modal" data-target="#LoginModel">登录</a>
                    </div>
                     </div>
                     <?php } ?>
                     <?php } ?>
                    
                    
                    <div class="lang">
                        <!--<img src="<?php echo get_template_directory_uri(); ?>/images/language.jpg" alt="">-->
                        
                        <?php do_action('wpml_add_language_selector'); ?>
                    </div>
                    <div class="browser-section">
                        <a href="<?php echo get_option('jetbuzz_weibo');?>" target="_blank;"><img src="<?php echo get_template_directory_uri(); ?>/images/browse-logo1.png" alt=""></a>
                        <a href="<?php echo get_option('jetbuzz_iconlink1');?>" target="_blank;"><img src="<?php echo get_template_directory_uri(); ?>/images/browse-logo2.png" alt=""></a>
                        <a href="<?php echo get_option('jetbuzz_iconlink2');?>" target="_blank;"><img src="<?php echo get_template_directory_uri(); ?>/images/browse-logo3.png" alt=""></a>
                    </div>
                    
                </div>
            </div>
        </div>
    </section>

 <!-- HEADER SECTION END -->
 <nav class="navbar navbar-default main-menu wow fadeInDown">
            <div class="container">
              <!-- Brand and toggle get grouped for better mobile display -->
                <div class="navbar-header">
                    <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" aria-expanded="false">
                      <span class="sr-only">Toggle navigation</span>
                      <span class="icon-bar"></span>
                      <span class="icon-bar"></span>
                      <span class="icon-bar"></span>
                    </button>
                      <a class="navbar-brand" href="<?php bloginfo('url')?>"><img src="<?php echo get_option('jetbuzz_logo');?>" alt=""></a>
                </div>
              
              
                <div class="header-rht"> 
                    <!-- Collect the nav links, forms, and other content for toggling -->
                    
                    
                      <?php
                    wp_nav_menu( array(
                        'theme_location'    => 'primary',
                        'depth'             => 2,
                        'container'         => 'div',
                        'container_class'   => 'collapse navbar-collapse',
                        'container_id'      => 'bs-example-navbar-collapse-1',
                        'menu_class'        => 'nav navbar-nav navbar-right',
                        'fallback_cb'       => 'WP_Bootstrap_Navwalker::fallback',
                        'walker'            => new WP_Bootstrap_Navwalker(),
                    ) ); ?>
                    <!--<ul class="lomenu">
                    <?php if ( !is_user_logged_in() ) { ?>  
                    <li itemscope="itemscope" class="login-btn"><a title="Login" href="#" data-toggle="modal" data-target="#LoginModel">Login</a></li>
                    <?php } else { ?>
                    <li itemscope="itemscope" class="login-btn"><a title="Login" href="<?php echo wp_logout_url( home_url() ); ?>" >Logout</a></li>
                    <?php } ?>
                    </ul>-->
                </div>       
                
            </div><!-- /.container-fluid -->
        </nav>
        
    <!-- HEADER SECTION START -->     
<?php if(!is_front_page() && !is_single() && !is_archive() && !is_404()) {
      $id = get_the_ID(); 
      //$imgav=get_field('inner_banner', $id);
   
?>
   <div class="inner-banner banner-slider">
    <?php if(get_field('inner_banner', $id)!='') {?>
    <img src="<?php echo get_field('inner_banner', $id);?>" class="img-responsive"/>
    <div class="inner-banner-txt caption">
          
            <div class="container">
             <?php the_field('inner_page_content'); ?>
               
            </div>
       
    </div>
    <?php } else {?> 
     <img src="<?php echo get_option('home')?>/wp-content/themes/ikmf/images/no-img1.jpg" class="img-responsive"/>
    <?php } ?> 
   </div>    
   <div class="clearfix"></div>    
    <?php } 
  else if(is_single() && is_post_type('post')) {
 $id = get_the_ID();
 $valget=get_field('inner_banner', $id);
  ?>
   <div class="inner-banner">
     <?php if($valget!='') { ?>   
    <img src="<?php echo get_field('inner_banner', $id);?>" class="img-responsive"/>
     <?php } else{?>
     <img src="<?php echo get_option('home')?>/wp-content/themes/ikmf/images/no-img1.jpg" class="img-responsive"/>
     <?php } ?>
 </div>    
 <?php  }
 
  else if(is_post_type('event')) {
  $id = get_the_ID();
  $post_feat_image = wp_get_attachment_url( get_post_thumbnail_id($id) );
 
  ?>
   
   <div class="inner-banner">
    <?php if(get_field('big_image_for_banner', $id)!='') { ?>
    <img src="<?php echo get_field('big_image_for_banner', $id);?>" class="img-responsive"/>
    <?php } else {?>
   <img src="<?php echo get_option('home')?>/wp-content/themes/ikmf/images/no-img1.jpg" class="img-responsive"/>
    <?php } ?>
    </div>    
 <?php  }
 
  else if(is_post_type('gymlocation')) {
  $id = get_the_ID();
  $post_feat_image = wp_get_attachment_url( get_post_thumbnail_id($id) );
  ?>
   
   <div class="inner-banner">
    <?php if($post_feat_image=='') {?>
    <img src="<?php echo get_option('home')?>/wp-content/themes/ikmf/images/no-img1.jpg" class="img-responsive"/>
    <?php } else {?>
    <img src="<?php echo $post_feat_image;?>" class="img-responsive"/>
    <?php } ?>
    </div>    
 <?php  }
 
   else if ( is_singular('our_course')) {
  $id = get_the_ID();
  $post_feat_image = wp_get_attachment_url( get_post_thumbnail_id($id) );
  ?>
   
   <div class="inner-banner">
    <?php if($post_feat_image!='') {?>
    <img src="<?php echo $post_feat_image;?>" class="img-responsive"/>
    <?php } else {?>
     <img src="<?php echo get_option('home')?>/wp-content/themes/ikmf/images/no-img1.jpg" class="img-responsive"/>
    <?php } ?>
    </div>    
 <?php  }
      
  //else if(is_post_type('our_team')) {
 else if ( is_singular('our_team')) {
 $id = get_the_ID();
  ?>
   <div class="inner-banner">
   <?php if(get_field('inner_banner', $id!='')) { ?>    
    <img src="<?php echo get_field('inner_banner', $id);?>" class="img-responsive"/>
   <?php } else { ?>
    <img src="<?php echo get_option('home')?>/wp-content/themes/ikmf/images/no-img1.jpg" class="img-responsive"/>
   <?php } ?> 
   </div>    
 <?php  }
 
  
  else if(is_archive()) {
  $category = get_queried_object();
  $id=$category->term_id;

?>

   
   <div class="inner-banner">
    <?php if(z_taxonomy_image_url($id)!=''){ ?>
    <img src="<?php echo z_taxonomy_image_url($id); ?>" class="img-responsive"/>
    <?php } else {?>
    <img src="<?php echo get_option('home')?>/wp-content/themes/ikmf/images/no-img1.jpg" class="img-responsive"/>
    <?php } ?>
    </div>    
  <?php } 
  
else if(is_404()) {
?>
<div class="inner-banner">
   <img src="<?php echo get_option('home')?>/wp-content/themes/ikmf/images/no-img1.jpg" class="img-responsive"/>
</div>    
  <?php } ?>