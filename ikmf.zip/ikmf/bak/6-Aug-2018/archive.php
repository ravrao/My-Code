<?php
/**
 * The template for displaying archive pages
 *
 * Used to display archive-type pages if nothing more specific matches a query.
 * For example, puts together date-based pages if no date.php file exists.
 *
 * If you'd like to further customize these archive views, you may create a
 * new template file for each one. For example, tag.php (Tag archives),
 * category.php (Category archives), author.php (Author archives), etc.
 *
 * @link https://codex.wordpress.org/Template_Hierarchy
 *
 * @package WordPress
 * @subpackage Twenty_Sixteen
 * @since Twenty Sixteen 1.0
 */

get_header(); ?>

<div id="common" class="container inner-cont">
     
  <div class="row">
        <div class="col-sm-12 col-xs-12">
            <div class="title ins-detail"><span><?php the_archive_title() ?></span></div>
        </div>
    </div>
 
 
<section class="faq-section">
    
        <div class="row">
        <div class="courseTab">
        <div class="panel-group" id="accordion" role="tablist" aria-multiselectable="true">
          
        <?php
           
           if( have_posts() ): while ( have_posts() ) : the_post(); 
            $testi_feat_image = wp_get_attachment_url( get_post_thumbnail_id($post->ID) ); 
            $categoriesco = get_the_terms( $post->ID, 'courses');
            $categories = get_the_category( $post->ID );
            //var_dump( $categories );
            
            $content = get_the_title();
            $content = strip_tags($content);
            
    
        ?> 
            <div class="item col-md-4">
                <a href="<?php echo get_permalink( $post->ID ); ?>"> 
                <div class="img-box">

                    <img src="<?php echo $testi_feat_image;?>" alt="" class="img-responsive">
                    <div class="event-overlay"></div>
                </div></a>
                <div class="info">
                    <a href="<?php echo get_permalink( $post->ID ); ?>"><div class="heading"><?php echo substr($content, 0, 22);?></div></a>
                    <?php if(is_tax( 'level' )) {
                    $state = get_the_terms( $post->ID, 'state');  //var_dump($categories);
                    $sname= $state[0]->name;    
                    ?>
                    <div class="catname"><?php echo $sname;?>: 
                        <?php
                         $city = get_the_terms( $post->ID, 'city');  //var_dump($categories);
                         $scity= $city[0]->name;
                         ?>
                        
                        <?php echo $scity; ?></div>
                    <?php } 
                    
                    else if(is_tax( 'courses' )){?>
                     <div class="catname">Category: <?php echo $categoriesco[0]->name;?></div>
                    <?php } 
                    else { ?>
                     <div class="catname">Category: <?php echo $categories[0]->name;?></div>   
                    <?php }?>
                    
                     <a href="<?php echo get_permalink( $post->ID ); ?>"><?php the_excerpt();?>   </a>                           
                </div>                         
            </div>
        <?php
       
           endwhile; ?>
           <?php endif; 
        ?>     
            
        <?php wp_pagenavi(); ?>
            
        </div>
        </div>
        </div>
        
      
   
</section>



    </div>
<?php get_footer(); ?>
