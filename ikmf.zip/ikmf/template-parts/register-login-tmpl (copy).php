<?php /* Template Name: Register Template */
get_header();
?> 

<div id="common" class="container inner-cont">

    <div class="row">
        <div class="col-sm-12 col-xs-12">
            <div class="title ins-detail"><?php the_title(); ?></div>
        </div>
    </div>


<section class="find-section">

<div class="container">
<div class="row">

<form action="#"  method="post" id="material_form" class="wppb-user-forms wppb-register-user wppb-user-logged-out" action="">
    <ul>
        <!--<li class="wppb-form-field wppb-default-name-heading" id="wppb-form-element-1">
            <h4>Name</h4><span class="wppb-description-delimiter"></span>
        </li>-->
        <li class="wppb-form-field wppb-default-username" id="wppb-form-element-2">
            <label for="username">Username<span class="wppb-required" title="This field is required">*</span></label>
            <input class="text-input default_field_username" name="username"  id="username" value="" required="" type="text">
            <span class="wppb-description-delimiter">Usernames cannot be changed.</span>
        </li>
        
        <li class="wppb-form-field wppb-default-first-name" id="wppb-form-element-3">
            <label for="first_name">First Name<span class="wppb-required" title="This field is required">*</span></label>
            <input class="text-input default_field_firstname" name="first_name"  id="first_name" value="" type="text">
        </li>
        
        <li class="wppb-form-field wppb-default-last-name" id="wppb-form-element-4">
            <label for="last_name">Last Name</label>
            <input class="text-input default_field_lastname" name="last_name"  id="last_name" value="" type="text">
        </li>
        
         <li class="wppb-form-field wppb-default-e-mail" id="wppb-form-element-8">
            <label for="email">E-mail<span class="wppb-required" title="This field is required">*</span></label>
            <input class="text-input default_field_email" name="email"  id="email" value="" required="" type="email">
        </li>
        
         <li class="wppb-form-field wppb-default-password" id="wppb-form-element-15">
            <label for="passw1">Password<span class="wppb-required" title="This field is required">*</span></label>
            <input class="text-input" name="passw1"  id="passw1" value="" autocomplete="off" required="" type="password">
            <span class="wppb-description-delimiter">Type your password. </span>
        </li>
        
        <li class="wppb-form-field wppb-default-repeat-password" id="wppb-form-element-16">
            <label for="passw2">Repeat Password<span class="wppb-required" title="This field is required">*</span></label>
            <input class="text-input" name="passw2"  id="passw2" value="" autocomplete="off" required="" type="password">
            <span class="wppb-description-delimiter">Type your password again. </span>
        </li>
       
        <li class="wppb-form-field wppb-input" id="wppb-form-element-17">
            <label for="phone_number">Phone Number<span class="wppb-required" title="This field is required">*</span></label>
            <input class="extra_field_input " name="phone_number"  id="phone_number" value="" required="" type="text">
        </li>
        
        <li class="wppb-form-field wppb-input" id="wppb-form-element-17">
            <label for="city">City<span class="wppb-required" title="This field is required">*</span></label>
            <input class="extra_field_input " name="city"  id="city" value="" required="" type="text">
        </li>
        
         <li class="wppb-form-field wppb-input" id="wppb-form-element-17">
            <label for="province">Province<span class="wppb-required" title="This field is required">*</span></label>
            <input class="extra_field_input " name="province"  id="province" value="" required="" type="text">
        </li>
       
        <li class="wppb-form-field wppb-select-cpt" id="wppb-form-element-18">
        <label for="gymchoose_location">Gym Location</label>
        <select name="gymchoose_location" id="gymchoose_location" class="custom_field_cpt_select ">
            <option value="">...Choose</option>
            <?php
                query_posts( array(
                'post_type' => 'gymlocation',
                'posts_per_page'  => '-1'  
                )); 

                if( have_posts() ): while ( have_posts() ) : the_post(); 
               
            ?>     
             <option value="<?php echo $post->ID; ?>"><?php the_title();?></option>
           <?php endwhile; 
           endif;?>
        </select>
        </li>
       
        <li class="wppb-form-field wppb-select-cpt" id="wppb-form-element-18">
        <label for="gymchoose_level">Level</label>
        <select name="gymchoose_level" id="gymchoose_level" class="custom_field_cpt_select ">
            <option value="">...Choose</option>
            <?php   
            $level=get_categories(array('taxonomy' => 'level', 'orderby' => 'ID', 'order' => 'ASC','hide_empty'=>0));
            foreach($level as $lvalue)
            { ?>
                
              <option value="<?php echo $lvalue->term_id; ?>"><?php echo $lvalue->name; ?></option>  
            <?php }
            ?>
        </select>
        </li>
        
        <li class="wppb-form-field wppb-select-cpt" id="wppb-form-element-18">
        <label for="gymchoose_position">Position</label>
        <input class="extra_field_input " name="position"  id="position" value="" required="" type="text">
        </li>
        
        <li class="wppb-form-field wppb-select" id="wppb-form-element-19">
            <label for="select_type_user">Type</label>
            <select name="select_type_user" id="select_type_user" class="custom_field_select">
                <option value="choose an option" class="custom_field_select_option " selected="">Choose an option</option>
                <option value="student" class="custom_field_select_option ">Student</option>
                <option value="instructor" class="custom_field_select_option ">Instructor</option>
            </select>
        </li>
        
        
        
    </ul>
    			
    <p class="form-submit">
        <input name="register" id="register" class="submit button" value="Register" type="submit">
        
    </p><!-- .form-submit -->

</form>

</div>
</div>

</section>



</div>

<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-validate/1.16.0/jquery.validate.min.js"></script>
<script type="text/javascript">

    jQuery(document).ready(function($) {


     $(".material_form").validate({
        alert('hi');
    });
});


</script>
<style type="text/css">  
input.error {
    border: 1px dotted red;
}    
</style>
<?php get_footer(); ?>
