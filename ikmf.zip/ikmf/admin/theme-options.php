<?php

add_action('init','of_options');

if (!function_exists('of_options')) {
function of_options(){
	
// VARIABLES
$themename = get_theme_data(STYLESHEETPATH . '/style.css');
$themename = $themename['Name'];
$shortname = "lp";

// Populate OptionsFramework option in array for use in theme
global $of_options;
$of_options = get_option('of_options');

$GLOBALS['template_path'] = OF_DIRECTORY;

//Access the WordPress Categories via an Array
$of_categories = array();  
$of_categories_obj = get_categories('hide_empty=0');
foreach ($of_categories_obj as $of_cat) {
    $of_categories[$of_cat->cat_ID] = $of_cat->cat_name;}
$categories_tmp = array_unshift($of_categories, "Select a category:");    
       
//Access the WordPress Pages via an Array
$of_pages = array();
$of_pages_obj = get_pages('sort_column=post_parent,menu_order');    
foreach ($of_pages_obj as $of_page) {
    $of_pages[$of_page->ID] = $of_page->post_name; }
$of_pages_tmp = array_unshift($of_pages, "Select a page:");       

// Image Alignment radio box
$options_thumb_align = array("alignleft" => "Left","alignright" => "Right","aligncenter" => "Center"); 

// Image Links to Options
$options_image_link_to = array("image" => "The Image","post" => "The Post"); 

//Testing 
$options_select = array("one","two","three","four","five"); 
$options_radio = array("one" => "One","two" => "Two","three" => "Three","four" => "Four","five" => "Five"); 

//Stylesheets Reader
$alt_stylesheet_path = OF_FILEPATH . '/styles/';
$alt_stylesheets = array();

if ( is_dir($alt_stylesheet_path) ) {
    if ($alt_stylesheet_dir = opendir($alt_stylesheet_path) ) { 
        while ( ($alt_stylesheet_file = readdir($alt_stylesheet_dir)) !== false ) {
            if(stristr($alt_stylesheet_file, ".css") !== false) {
                $alt_stylesheets[] = $alt_stylesheet_file;
            }
        }    
    }
}

//More Options
$uploads_arr = wp_upload_dir();
$all_uploads_path = $uploads_arr['path'];
$all_uploads = get_option('of_uploads');
$other_entries = array("Select a number:","1","2","3","4","5","6","7","8","9","10","11","12","13","14","15","16","17","18","19");
$body_repeat = array("no-repeat","repeat-x","repeat-y","repeat");
$body_pos = array("top left","top center","top right","center left","center center","center right","bottom left","bottom center","bottom right");

// Set the Options Array
$options = array();

/*$options[] = array( "name" => "General Settings",
                    "type" => "heading");

$options[] = array( "name" => "Logo",
					"desc" => "Upload Your Logo",
					"id" => "jetbuzz_logo",
					"std" => "",
					"type" => "upload");


$options[] = array( "name" => "Map",
					"desc" => "Here you can add your map ",
					"id" => "jetbuzz_map",
					"std" => "",
					"type" => "textarea");

/*$options[] = array( "name" => "Header Another Text",
					"desc" => "Here you can enter any text you want",
					"id" => "jetbuzz_text1",
					"std" => "",
					"type" => "text");*/
	
/*$options[] = array( "name" => "Favicon",
					"desc" => "Upload favicon images.",
					"id" => "jetbuzz_favicon",
					"std" => "",
					"type" => "upload"); */
					

/* For Header Option */

$options[] = array( "name" => "Header",
                    "type" => "heading");

$options[] = array( "name" => "Logo",
					"desc" => "Upload Your Logo",
					"id" => "jetbuzz_logo",
					"std" => "",
					"type" => "upload");

$options[] = array( "name" => "E-mail",
					"desc" => "Enter E-mail",
					"id" => "jetbuzz_email",
					"std" => "",
					"type" => "text");

$options[] = array( "name" => "Weibo Link",
					"desc" => "Enter Your Weibo Link",
					"id" => "jetbuzz_weibo",
					"std" => "",
					"type" => "text");


$options[] = array( "name" => "2nd Icon Link",
					"desc" => "Enter Your 2nd Logo Link",
					"id" => "jetbuzz_iconlink1",
					"std" => "",
					"type" => "text");

$options[] = array( "name" => "3rd Icon Link",
					"desc" => "Enter Your 3rd Logo Link",
					"id" => "jetbuzz_iconlink2",
					"std" => "",
					"type" => "text");

/* End Header Option */


					
$options[] = array( "name" => "Social Media Options",
					"type" => "heading");


$options[] = array( "name" => "Facebook",
					"desc" => "Enter your Facebook link here.",
					"id" => "jetbuzz_facebook",
					"std" => "",
					"type" => "text");

$options[] = array( "name" => "Linkedin",
					"desc" => "Enter your linkedin link here.",
					"id" => "jetbuzz_linkedin",
					"std" => "",
					"type" => "text");

$options[] = array( "name" => "Weibo Link",
					"desc" => "Enter your Weibo link here.",
					"id" => "jetbuzz_weibo_link",
					"std" => "",
					"type" => "text");

///////

$options[] = array( "name" => "Contact Us",
					"type" => "heading");

$options[] = array( "name" => "Description",
					"desc" => "Enter Description.",
					"id" => "jetbuzz_desc",
					"std" => "",
					"type" => "textarea");

$options[] = array( "name" => "Chinese Description",
					"desc" => "Enter Chinese Description.",
					"id" => "jetbuzz_desc_ch",
					"std" => "",
					"type" => "textarea");

$options[] = array( "name" => "Wechat Text",
					"desc" => "Enter Wechat Text.",
					"id" => "jetbuzz_wechat_text",
					"std" => "",
					"type" => "text");

$options[] = array( "name" => "Email",
					"desc" => "Enter email.",
					"id" => "jetbuzz_footemail",
					"std" => "",
					"type" => "text");

$options[] = array( "name" => "Phone-1",
					"desc" => "Enter Phone-1.",
					"id" => "jetbuzz_phone1",
					"std" => "",
					"type" => "text");

$options[] = array( "name" => "Phone-2",
					"desc" => "Enter Phone-2.",
					"id" => "jetbuzz_phone2",
					"std" => "",
					"type" => "text");

$options[] = array( "name" => "Address-1",
					"desc" => "Enter Address-1.",
					"id" => "jetbuzz_address1",
					"std" => "",
					"type" => "text");

$options[] = array( "name" => "Address-2",
					"desc" => "Enter Address-2.",
					"id" => "jetbuzz_address2",
					"std" => "",
					"type" => "text");




$options[] = array( "name" => "Wechat QR code",
					"type" => "heading");					
				
$options[] = array( "name" => "Wechat Image",
					"desc" => "Enter Wechat Image",
					"id" => "jetbuzz_weimage",
					"std" => "",
					"type" => "upload");

$options[] = array( "name" => "Wechat Description",
					"desc" => "Enter Wechat description",
					"id" => "jetbuzz_wedesc",
					"std" => "",
					"type" => "textarea");

$options[] = array( "name" => "Wechat Chinese Description",
					"desc" => "Enter Wechat Chinese Description",
					"id" => "jetbuzz_wedesc_ch",
					"std" => "",
					"type" => "textarea");

					
$options[] = array( "name" => "Footer",
					"type" => "heading");					
				
$options[] = array( "name" => "Copyright",
					"desc" => "Copyright",
					"id" => "jetbuzz_copyright",
					"std" => "",
					"type" => "textarea");

$options[] = array( "name" => "Chinese Copyright",
					"desc" => "Copyright Chinese",
					"id" => "jetbuzz_copyright_ch",
					"std" => "",
					"type" => "textarea");

$options[] = array( "name" => "Footer Description",
					"desc" => "Footer Description",
					"id" => "jetbuzz_fotdesc",
					"std" => "",
					"type" => "textarea");

$options[] = array( "name" => "Footer Description Chinese",
					"desc" => "Footer Description Chinese",
					"id" => "jetbuzz_fotdesc_ch",
					"std" => "",
					"type" => "textarea");
update_option('of_template',$options); 					  
update_option('of_themename',$themename);   
update_option('of_shortname',$shortname);

}
}
?>
