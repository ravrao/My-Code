<?php /* Template Name: News & Media Template */

get_header(); ?> 
    
    <div class="container inner-cont news-media-page"> 
    	<div class="news-section">
    		<div class="title"><span>Latest news</span></div>    			
            	<div class="news-cont row">  
                    <div class="col-md-6">   
	                    <div class="news-box">
	                        <div class="news-img">
	                        	<img width="114" height="114" src="http://lab-1.sketchdemos.com/P1091_IKMF/wp-content/uploads/2018/04/news-1.jpg">
	                        </div>
	                        <h4>Lorem Ipsum is simply dummy text</h4>
	                        <p>of the printing and typesetting industry. Lorem Ipsum has been the industry’s standard dummy text ever since the 1500s,</p>
	                        <div class="info-desc">
	                            <div class="date">28 Apr. 2018</div>
	                            <a class="reply" href="http://lab-1.sketchdemos.com/P1091_IKMF/lorem-ipsum-is-simply-dummy-text/"><span><!--<i class="fa fa-reply"></i>--></span>Read more</a>
	                        </div>
	                    </div>
                    </div>
                     
                    <div class="col-md-6">
	                    <div class="news-box">
	                        <div class="news-img">
	                        	<img width="114" height="114" src="http://lab-1.sketchdemos.com/P1091_IKMF/wp-content/uploads/2018/04/news-1.jpg">
	                        </div>
	                        <h4>Lorem Ipsum is simply dummy text</h4>
	                        <p>of the printing and typesetting industry. Lorem Ipsum has been the industry’s standard dummy text ever since the 1500s,</p>
	                        <div class="info-desc">
	                            <div class="date">02 May. 2018</div>
	                            <a class="reply" href="http://lab-1.sketchdemos.com/P1091_IKMF/latest-news-lorem-ipsum-is-simply-dummy-text/"><span><!--<i class="fa fa-reply"></i>--></span>Read more</a>
	                        </div>
	                    </div>
                    </div>

                    <div class="col-md-6">   
	                    <div class="news-box">
	                        <div class="news-img">
	                        	<img width="114" height="114" src="http://lab-1.sketchdemos.com/P1091_IKMF/wp-content/uploads/2018/04/news-2.jpg">
	                        </div>
	                        <h4>Lorem Ipsum is simply dummy text</h4>
	                        <p>of the printing and typesetting industry. Lorem Ipsum has been the industry’s standard dummy text ever since the 1500s,</p>
	                        <div class="info-desc">
	                            <div class="date">28 Apr. 2018</div>
	                            <a class="reply" href="http://lab-1.sketchdemos.com/P1091_IKMF/lorem-ipsum-is-simply-dummy-text/"><span><!--<i class="fa fa-reply"></i>--></span>Read more</a>
	                        </div>
	                    </div>
                    </div>
                     
                    <div class="col-md-6">
	                    <div class="news-box">
	                        <div class="news-img">
	                        	<img width="114" height="114" src="http://lab-1.sketchdemos.com/P1091_IKMF/wp-content/uploads/2018/04/news-2.jpg">
	                        </div>
	                        <h4>Lorem Ipsum is simply dummy text</h4>
	                        <p>of the printing and typesetting industry. Lorem Ipsum has been the industry’s standard dummy text ever since the 1500s,</p>
	                        <div class="info-desc">
	                            <div class="date">02 May. 2018</div>
	                            <a class="reply" href="http://lab-1.sketchdemos.com/P1091_IKMF/latest-news-lorem-ipsum-is-simply-dummy-text/"><span><!--<i class="fa fa-reply"></i>--></span>Read more</a>
	                        </div>
	                    </div>
                    </div>                   
                </div> 
                <div class="view-btn"><a class="btn" href="#">view all</a></div>     
         </div>
        
         <div class="clearfix"></div>

         <div class="media-section">
         	<div class="title"><span>MEDIA UPDATES</span></div>

         	<div class="media-select-div">
         		<div class="selec-div">
         			<select name="category" id="media-select" class="media-select-cat">
						<option value="0" selected="selected">Photo Album</option>
						<option class="level-0" value="18">Photo Album 1</option>
						<option class="level-0" value="17">Photo Album 2</option>
						<option class="level-0" value="16">Photo Album 3</option>
					</select>
         		</div>
         		<div class="selec-div">
         			<select name="category" id="media-select" class="media-select-cat">
						<option value="0" selected="selected">Video</option>
						<option class="level-0" value="18">Video 1</option>
						<option class="level-0" value="17">Video 2</option>
						<option class="level-0" value="16">Video 3</option>
					</select>
         		</div>
         		<div class="selec-div">
         			<select name="category" id="media-select" class="media-select-cat">
						<option value="0" selected="selected">Article</option>
						<option class="level-0" value="18">Article 1</option>
						<option class="level-0" value="17">Article 2</option>
						<option class="level-0" value="16">Article 3</option>
					</select>
         		</div>
         	</div>

         	<div class="row">
	         	<div class="col-md-4 col-sm-6 col-xs-12">
	         		<div class="media-box">
		         		<img src="http://lab-1.sketchdemos.com/P1091_IKMF/wp-content/uploads/2018/04/event-1.jpg" alt="" class="img-responsive">
		         		<h4>Title</h4>
		         		<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown</p>
	         		</div>
	         	</div>

	         	<div class="col-md-4 col-sm-6 col-xs-12">
	         		<div class="media-box">
		         		<img src="http://lab-1.sketchdemos.com/P1091_IKMF/wp-content/uploads/2018/04/event-2.jpg" alt="" class="img-responsive">
		         		<h4>Title</h4>
		         		<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown</p>
	         		</div>
	         	</div>

	         	<div class="col-md-4 col-sm-6 col-xs-12">
	         		<div class="media-box">
		         		<img src="http://lab-1.sketchdemos.com/P1091_IKMF/wp-content/uploads/2018/04/event-3.jpg" alt="" class="img-responsive">
		         		<h4>Title</h4>
		         		<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown</p>
	         		</div>
	         	</div>

	         	<div class="col-md-4 col-sm-6 col-xs-12">
	         		<div class="media-box">
		         		<img src="http://lab-1.sketchdemos.com/P1091_IKMF/wp-content/uploads/2018/04/course-1-1.jpg" alt="" class="img-responsive">
		         		<h4>Title</h4>
		         		<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown</p>
	         		</div>
	         	</div>

	         	<div class="col-md-4 col-sm-6 col-xs-12">
	         		<div class="media-box">
		         		<img src="http://lab-1.sketchdemos.com/P1091_IKMF/wp-content/uploads/2018/04/course-2.jpg" alt="" class="img-responsive">
		         		<h4>Title</h4>
		         		<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown</p>
	         		</div>
	         	</div>

	         	<div class="col-md-4 col-sm-6 col-xs-12">
	         		<div class="media-box">
		         		<img src="http://lab-1.sketchdemos.com/P1091_IKMF/wp-content/uploads/2018/04/course-3.jpg" alt="" class="img-responsive">
		         		<h4>Title</h4>
		         		<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown</p>
	         		</div>
	         	</div>
         	</div>

         	<div class="view-btn"><a class="btn" href="#">view all</a></div> 

         </div>

    </div>




    
<?php get_footer(); ?>
