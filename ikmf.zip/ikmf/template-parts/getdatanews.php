<?php
$POST_ID =  $_REQUEST['allmediasel'];
//echo $_SERVER['HTTPS'];
require_once ("../../../wp-config.php");

$catslug=get_cat_slug($POST_ID); ?>
 <?php   $page_lang = $_REQUEST['lang'];?> 
<div class="row">

 <?php
    query_posts( array(
    'post_type' => 'post',
    'cat'       => $POST_ID,    
    'posts_per_page'   => 6,
    'orderby'          => 'post_date',
    'order'            => 'DESC',
    'post_status'      => 'publish',
    )); 

    if( have_posts() ): while ( have_posts() ) : the_post(); 
    $post_feat_image = wp_get_attachment_url( get_post_thumbnail_id($post->ID) );
    $title_t = get_the_title();
    $titshort = strip_tags($title_t)


?>       
<div class="col-md-4 col-sm-6 col-xs-12">
    <div class="media-box">
        <a href="<?php the_permalink()?>"> 
            <div class="img-box">
                <?php echo get_the_post_thumbnail($post->ID,'photo_album',array('class' => 'img-responsive')); ?>
                <div class="event-overlay"></div>                
            </div></a>
        <a href="<?php the_permalink()?>"> <h4><?php echo substr($titshort, 0, 22);?></h4></a>
        <a href="<?php the_permalink()?>"><?php the_excerpt();?></a>
    </div>
</div>
<?php endwhile; endif;?>

</div>

<div class="view-btn"><a class="btn" href="<?php bloginfo('url')?>/category/<?php echo $catslug;?>/#common">view all</a></div> 



