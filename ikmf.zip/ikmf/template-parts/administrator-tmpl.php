<?php /* Template Name: Administrator Template */
get_header(); ?> 
    
    <div id="common" class="container inner-cont administration-page">
  <?php while ( have_posts() ) : the_post(); ?>    
    <div class="row">
        <div class="col-sm-12 col-xs-12">           
            <div class="admincont"><?php the_content()?></div>
        </div>
    </div>
 <?php endwhile;?> 
 
<section class="faq-section">
    <div class="container">
        <div class="row">
        <div class="col-md-12 col-sm-12 col-xs-12 courseTab">
        <div class="panel-group" id="accordion" role="tablist" aria-multiselectable="true">
          <div class="row">


        <?php
           query_posts( array(
           'post_type' => 'admin', 
           'posts_per_page' => 20,   
           )); 
           $k=1;
           if( have_posts() ): while ( have_posts() ) : the_post(); 
            $testi_feat_image = wp_get_attachment_url( get_post_thumbnail_id($post->ID) ); 
            $categories = get_the_terms( $post->ID, 'courses');
        ?> 
        
            <div class="item">
                <div class="img-box">
                    <img src="<?php echo $testi_feat_image;?>" alt="" class="img-responsive">
                </div>
                <div class="info">
                    <div class="heading"><?php the_title();?> <span class="subheading"><?php echo get_post_meta($post->ID, 'designation', true); ?></span></div>                   
                  
                   <?php the_content();?>                              
                </div>                         
            </div>
           
        <?php
        $k++;
           endwhile; ?>
           <?php endif; 
        ?>   

             </div>
           
            
        </div>
        </div>
        </div>
        
      
    </div>
</section>



    </div>




    
<?php get_footer(); ?>
